# emacs-mode: -*- python-*-
TITLE.debugOut(('begin:%s' % __file__))

def cfgInit(m, BGName):
    import vram
    BGTone = 192
    if (BGName == None):
        m.drawImg(vram.IMG_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        m.drawTile((BGTone << 24), (-400,
         -300,
         800,
         600))
        m.moveImg(vram.TMP_PAGE, (0,
         0,
         800,
         600), 0, (0,
         0))
    elif (BGName == 0):
        m.clear(vram.TMP_PAGE, -16777216, (0,
         0,
         800,
         600))
    else:
        m.loadImg(vram.TMP_PAGE, (0,
         0), BGName)
    startTime = m.getTime()
    while 1:
        passTime = (m.getTime() - startTime)
        if (passTime >= 300):
            m.drawImg(vram.TMP_PAGE, 255, (-400,
             -300,
             800,
             600), (0,
             0))
            m.swap()
            break
        else:
            alpha = (255 - ((255 * passTime) / 300))
            if (BGName == None):
                m.drawImg(vram.TMP_PAGE, 255, (-400,
                 -300,
                 800,
                 600), (0,
                 0))
                m.drawImg(vram.IMG_PAGE, alpha, (-400,
                 -300,
                 800,
                 600), (0,
                 0))
            else:
                m.drawImg(vram.TMP_PAGE, 255, (-400,
                 -300,
                 800,
                 600), (0,
                 0))
                m.drawTile((alpha << 24), (-400,
                 -300,
                 800,
                 600))
            m.swap()




def baseDraw(mod):
    import vram
    import cfgAni
    import cfgvalue
    mod.drawImg(vram.TMP_PAGE, 255, (-400,
     -300,
     800,
     600), (0,
     0))
    cfgAni.cfgBaseDraw()
    for i in range(cfgAni.getVoiceNum()):
        if cfgvalue.isVoiceCut(i):
            cfgAni.cfgVoiceOffDraw(i)
        else:
            cfgAni.cfgVoiceOnDraw(i)

    if cfgvalue.isEffectCut():
        cfgAni.cfgEffectOffDraw()
    else:
        cfgAni.cfgEffectOnDraw()
    if cfgvalue.isVoiceSync():
        cfgAni.cfgSyncOnDraw()
    else:
        cfgAni.cfgSyncOffDraw()
    cfgAni.cfgBGMDraw((cfgvalue.getBGMVolume() / 255.0))
    cfgAni.cfgSEDraw((cfgvalue.getSEVolume() / 255.0))
    cfgAni.cfgAutoDraw(((cfgvalue.MAX_AUTO_SPEED - cfgvalue.getAutoSpeed()) / float(cfgvalue.MAX_AUTO_SPEED)))
    cfgAni.cfgMsgDraw(((cfgvalue.MAX_MSG_SPEED - cfgvalue.getMsgSpeed()) / float(cfgvalue.MAX_MSG_SPEED)))
    cfgAni.cfgVoiceDraw((cfgvalue.getVoiceVolume() / 255.0))



def checkVoiceButton(mod):
    import cfgAni
    import key
    import cfgvalue
    import scene
    m = key.getPos(mod)
    for i in range(cfgAni.getVoiceNum()):
        r = cfgAni.getVoiceBounds(i)
        if (r[0] < m[0] < (r[0] + r[2]) and r[1] < m[1] < (r[1] + r[3])):
            cfgAni.cfgVoiceSelDraw(i)
            if key.isTrg(mod):
                scene.playSE('\x8c\x88\x92\xe8')
                cfgvalue.setVoiceCut(i, (not cfgvalue.isVoiceCut(i)))




def checkEffectButton(mod):
    import cfgAni
    import key
    import cfgvalue
    import scene
    m = key.getPos(mod)
    r = cfgAni.getEffectBounds()
    if (r[0] < m[0] < (r[0] + r[2]) and r[1] < m[1] < (r[1] + r[3])):
        cfgAni.cfgEffectSelDraw()
        if key.isTrg(mod):
            scene.playSE('\x8c\x88\x92\xe8')
            cfgvalue.setEffectCut((not cfgvalue.isEffectCut()))



def checkSyncButton(mod):
    import cfgAni
    import key
    import cfgvalue
    import scene
    m = key.getPos(mod)
    r = cfgAni.getSyncBounds()
    if (r[0] < m[0] < (r[0] + r[2]) and r[1] < m[1] < (r[1] + r[3])):
        cfgAni.cfgSyncSelDraw()
        if key.isTrg(mod):
            scene.playSE('\x8c\x88\x92\xe8')
            cfgvalue.setVoiceSync((not cfgvalue.isVoiceSync()))



def checkReturnButton(mod):
    import cfgAni
    import key
    import scene
    m = key.getPos(mod)
    r = cfgAni.getReturnBounds()
    if (r[0] < m[0] < (r[0] + r[2]) and r[1] < m[1] < (r[1] + r[3])):
        cfgAni.cfgReturnSelDraw()
        if key.isTrg(mod):
            scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
            cfgAni.cfgReturnWait(mod, baseDraw)
            return 1
    return 0



def getBarValue(r, m):
    if ((r[0] - 6) < m[0] < ((r[0] + r[2]) + 6) and r[1] < m[1] < (r[1] + r[3])):
        if (r[0] > m[0]):
            left = 0
        elif ((r[0] + r[2]) < m[0]):
            left = r[2]
        else:
            left = (m[0] - r[0])
        return left
    else:
        return None



def checkAutoSpeed(mod):
    import cfgAni
    import cfgvalue
    import key
    r = cfgAni.getAutoBarBounds()
    left = getBarValue(r, key.getPos(mod))
    if (left != None):
        cfgvalue.setAutoSpeed(((cfgvalue.MAX_AUTO_SPEED * (r[2] - left)) / r[2]))



def checkMsgSpeed(mod):
    import cfgAni
    import cfgvalue
    import key
    r = cfgAni.getMsgBarBounds()
    left = getBarValue(r, key.getPos(mod))
    if (left != None):
        cfgvalue.setMsgSpeed(((cfgvalue.MAX_MSG_SPEED * (r[2] - left)) / r[2]))



def checkVoiceVolume(mod):
    import cfgAni
    import cfgvalue
    import key
    old = cfgvalue.getVoiceVolume()
    r = cfgAni.getVoiceBarBounds()
    left = getBarValue(r, key.getPos(mod))
    if (left != None):
        cfgvalue.setVoiceVolume(((255 * left) / r[2]))
    if (old != cfgvalue.getVoiceVolume()):
        mod.setVoiceVolume(mod.SOUND, cfgvalue.getVoiceVolume())



def checkBGMVolume(mod):
    import cfgAni
    import cfgvalue
    import key
    old = cfgvalue.getBGMVolume()
    r = cfgAni.getBGMBarBounds()
    left = getBarValue(r, key.getPos(mod))
    if (left != None):
        cfgvalue.setBGMVolume(((255 * left) / r[2]))
    if (old != cfgvalue.getBGMVolume()):
        mod.setBGMVolume(mod.SOUND, cfgvalue.getBGMVolume())



def checkSEVolume(mod):
    import cfgAni
    import cfgvalue
    import key
    old = cfgvalue.getSEVolume()
    r = cfgAni.getSEBarBounds()
    left = getBarValue(r, key.getPos(mod))
    if (left != None):
        cfgvalue.setSEVolume(((255 * left) / r[2]))
    if (old != cfgvalue.getSEVolume()):
        mod.setSEVolume(mod.SOUND, cfgvalue.getSEVolume())



def start(m, BGName):
    import vram
    import key
    import cfgAni
    import cfgvalue
    import scene
    import cfgAni
    cfgAni.init()
    cfgInit(m, BGName)
    m.updateInput(m.INPUT)
    while 1:
        m.drawImg(vram.TMP_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        baseDraw(m)
        if key.isInput(m):
            checkBGMVolume(m)
            checkSEVolume(m)
            checkAutoSpeed(m)
            if (not cfgvalue.isVoiceSync()):
                checkMsgSpeed(m)
            checkVoiceVolume(m)
        checkVoiceButton(m)
        checkEffectButton(m)
        checkSyncButton(m)
        if checkReturnButton(m):
            break
        m.swap()
        m.updateInput(m.INPUT)
        if key.isCansel(m):
            scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
            cfgAni.cfgReturnWait(m, baseDraw)
            break

    import effect
    effect.fadeOutWait(TITLE)
    import load
    f = open(('%s/0.dat' % load.getDataPath(TITLE)), 'wb')
    buf = KADV.getFlagData(KADV.FLAG)
    f.write(buf)
    f.close()


TITLE.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
