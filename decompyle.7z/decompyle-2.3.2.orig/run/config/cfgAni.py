# emacs-mode: -*- python-*-
TITLE.debugOut(('begin:%s' % __file__))
CFG_BASE_NO = (10,
 TITLE.ANIOP_63)
CFG_BGM_NO = (11,
 TITLE.ANIOP_62)
CFG_SE_NO = (11,
 TITLE.ANIOP_61)
CFG_AUTO_NO = (11,
 TITLE.ANIOP_60)
CFG_MSG_NO = (11,
 TITLE.ANIOP_59)
CFG_VOICE_NO = (11,
 TITLE.ANIOP_58)
CFG_RETURN_SEL_NO = (14,
 TITLE.ANIOP_57)
CFG_RETURN_NO = (15,
 TITLE.ANIOP_56)
CFG_EFFECT_ON_NO = (22,
 TITLE.ANIOP_55)
CFG_EFFECT_OFF_NO = (23,
 TITLE.ANIOP_54)
CFG_VOICE_SEL_NO = (17,
 TITLE.ANIOP_53)
CFG_EFFECT_SEL_NO = (19,
 TITLE.ANIOP_52)
CFG_SYNC_SEL_NO = (25,
 TITLE.ANIOP_51)
CFG_SYNC_ON_NO = (27,
 TITLE.ANIOP_50)
CFG_SYNC_OFF_NO = (28,
 TITLE.ANIOP_49)
CFG_MSG_HIDE_NO = (26,
 TITLE.ANIOP_48)
BOUNDS_VOICE_NUM_NO = (45,
 0)
BOUNDS_RETURN_NO = (16,
 0)
BOUNDS_VOICE_NO = (18,
 0)
BOUNDS_EFFECT_NO = (18,
 10)
BOUNDS_SYNC_NO = (18,
 11)
BOUNDS_BGM_BAR_NO = (12,
 0)
BOUNDS_SE_BAR_NO = (12,
 1)
BOUNDS_AUTO_BAR_NO = (12,
 2)
BOUNDS_MSG_BAR_NO = (12,
 3)
BOUNDS_VOICE_BAR_NO = (12,
 4)
CFG_VOICE_ON_NO = 20
CFG_VOICE_OFF_NO = 21

def init():
    TITLE.loadAni(TITLE.ANI_0, 'config/copts.abb')
    nos = [CFG_BASE_NO,
     CFG_BGM_NO,
     CFG_SE_NO,
     CFG_AUTO_NO,
     CFG_MSG_NO,
     CFG_VOICE_NO,
     CFG_RETURN_SEL_NO,
     CFG_RETURN_NO,
     CFG_EFFECT_ON_NO,
     CFG_EFFECT_OFF_NO,
     CFG_VOICE_SEL_NO,
     CFG_EFFECT_SEL_NO,
     CFG_MSG_HIDE_NO,
     CFG_SYNC_SEL_NO,
     CFG_SYNC_ON_NO,
     CFG_SYNC_OFF_NO]
    for i in nos:
        TITLE.setAniop(i[1], TITLE.ANI_0, i[0])




def getVoiceNum():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_VOICE_NUM_NO[0], BOUNDS_VOICE_NUM_NO[1])[3]



def getEffectBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_EFFECT_NO[0], BOUNDS_EFFECT_NO[1])



def getVoiceBounds(no):
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_VOICE_NO[0], (BOUNDS_VOICE_NO[1] + no))



def getReturnBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_RETURN_NO[0], BOUNDS_RETURN_NO[1])



def getSyncBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_SYNC_NO[0], BOUNDS_SYNC_NO[1])



def getBGMBarPos(alpha):
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_BGM_BAR_NO[0], BOUNDS_BGM_BAR_NO[1])
    return ((pos[0] + int((alpha * pos[2]))),
     (pos[1] + (pos[3] / 2)))



def getSEBarPos(alpha):
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_SE_BAR_NO[0], BOUNDS_SE_BAR_NO[1])
    return ((pos[0] + int((alpha * pos[2]))),
     (pos[1] + (pos[3] / 2)))



def getAutoBarPos(alpha):
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_AUTO_BAR_NO[0], BOUNDS_AUTO_BAR_NO[1])
    return ((pos[0] + int((alpha * pos[2]))),
     (pos[1] + (pos[3] / 2)))



def getMsgBarPos(alpha):
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_MSG_BAR_NO[0], BOUNDS_MSG_BAR_NO[1])
    return ((pos[0] + int((alpha * pos[2]))),
     (pos[1] + (pos[3] / 2)))



def getVoiceBarPos(alpha):
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_VOICE_BAR_NO[0], BOUNDS_VOICE_BAR_NO[1])
    return ((pos[0] + int((alpha * pos[2]))),
     (pos[1] + (pos[3] / 2)))



def getBGMBarBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_BGM_BAR_NO[0], BOUNDS_BGM_BAR_NO[1])



def getSEBarBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_SE_BAR_NO[0], BOUNDS_SE_BAR_NO[1])



def getAutoBarBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_AUTO_BAR_NO[0], BOUNDS_AUTO_BAR_NO[1])



def getMsgBarBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_MSG_BAR_NO[0], BOUNDS_MSG_BAR_NO[1])



def getVoiceBarBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_VOICE_BAR_NO[0], BOUNDS_VOICE_BAR_NO[1])



def cfgBaseDraw():
    TITLE.drawAniop(CFG_BASE_NO[1])
    return TITLE.isLoopAniop(CFG_BASE_NO[1])



def cfgBGMDraw(alpha):
    TITLE.drawAniop(CFG_BGM_NO[1], getBGMBarPos(alpha))



def cfgSEDraw(alpha):
    TITLE.drawAniop(CFG_SE_NO[1], getSEBarPos(alpha))



def cfgAutoDraw(alpha):
    TITLE.drawAniop(CFG_AUTO_NO[1], getAutoBarPos(alpha))



def cfgMsgDraw(alpha):
    import cfgvalue
    if cfgvalue.isVoiceSync():
        TITLE.drawAniop(CFG_MSG_HIDE_NO[1])
    TITLE.drawAniop(CFG_MSG_NO[1], getMsgBarPos(alpha))



def cfgVoiceDraw(alpha):
    TITLE.drawAniop(CFG_VOICE_NO[1], getVoiceBarPos(alpha))



def cfgVoiceOnDraw(no):
    TITLE.drawAni(TITLE.ANI_0, CFG_VOICE_ON_NO, no)



def cfgVoiceOffDraw(no):
    TITLE.drawAni(TITLE.ANI_0, CFG_VOICE_OFF_NO, no)



def cfgEffectOnDraw():
    TITLE.drawAniop(CFG_EFFECT_ON_NO[1])



def cfgEffectOffDraw():
    TITLE.drawAniop(CFG_EFFECT_OFF_NO[1])



def cfgSyncOnDraw():
    TITLE.drawAniop(CFG_SYNC_ON_NO[1])



def cfgSyncOffDraw():
    TITLE.drawAniop(CFG_SYNC_OFF_NO[1])



def cfgVoiceSelDraw(no):
    pos = getVoiceBounds(no)
    TITLE.drawAniop(CFG_VOICE_SEL_NO[1], (pos[0],
     pos[1]))



def cfgEffectSelDraw():
    TITLE.drawAniop(CFG_EFFECT_SEL_NO[1])



def cfgSyncSelDraw():
    TITLE.drawAniop(CFG_SYNC_SEL_NO[1])



def cfgReturnSelDraw():
    TITLE.drawAniop(CFG_RETURN_SEL_NO[1])



def waitDraw(m, drawFunc, a):
    m.setAniop(a[1], TITLE.ANI_0, a[0])
    while 1:
        drawFunc(m)
        m.drawAniop(a[1])
        m.swap()
        if m.isFinishAniop(a[1]):
            break




def cfgReturnWait(m, drawFunc):
    waitDraw(m, drawFunc, CFG_RETURN_NO)


TITLE.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
