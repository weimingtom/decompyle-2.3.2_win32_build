# emacs-mode: -*- python-*-
TITLE.debugOut(('begin:%s' % __file__))
CG_BASE_NO = (10,
 TITLE.ANIOP_31)
CG_NEXT_ON_NO = (11,
 TITLE.ANIOP_29)
CG_BACK_ON_NO = (12,
 TITLE.ANIOP_28)
CG_NEXT_NO = (13,
 TITLE.ANIOP_26)
CG_BACK_NO = (14,
 TITLE.ANIOP_25)
CG_RETURN_ON_NO = (15,
 TITLE.ANIOP_27)
CG_RETURN_NO = (16,
 TITLE.ANIOP_24)
CG_THUMB_ON_NO = (17,
 TITLE.ANIOP_23)
CG_THUMB_NO = (18,
 TITLE.ANIOP_22)
CG_THUMB_BASE_NO = (19,
 TITLE.ANIOP_30)
CG_THUMB_NONE_NO = (25,
 TITLE.ANIOP_21)
BOUNDS_NUM_NO = (20,
 0)
BOUNDS_THUMB_WH_NO = (20,
 1)
BOUNDS_THUMB_NO = (21,
 0)
BOUNDS_PAGE_NO = (22,
 0)
BOUNDS_NEXT_NO = (22,
 1)
BOUNDS_BACK_NO = (22,
 2)
BOUNDS_RETURN_NO = (22,
 3)

def init():
    TITLE.loadAni(TITLE.ANI_0, 'cgview/cgpts.abb')
    nos = [CG_BASE_NO,
     CG_THUMB_NONE_NO,
     CG_THUMB_BASE_NO,
     CG_THUMB_ON_NO,
     CG_NEXT_ON_NO,
     CG_BACK_ON_NO,
     CG_RETURN_ON_NO,
     CG_THUMB_NO,
     CG_NEXT_NO,
     CG_BACK_NO,
     CG_RETURN_NO]
    for i in nos:
        TITLE.setAniop(i[1], TITLE.ANI_0, i[0])




def getThumbNum():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_NUM_NO[0], BOUNDS_NUM_NO[1])[1]



def getThumbPos(no):
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_THUMB_NO[0], no)
    return (pos[0],
     pos[1])



def getThumbBounds(no):
    xy = getThumbPos(no)
    wh = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_THUMB_WH_NO[0], BOUNDS_THUMB_WH_NO[1])
    return (xy[0],
     xy[1],
     wh[2],
     wh[3])



def getPageBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_PAGE_NO[0], BOUNDS_PAGE_NO[1])



def getNextBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_NEXT_NO[0], BOUNDS_NEXT_NO[1])



def getBackBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_BACK_NO[0], BOUNDS_BACK_NO[1])



def getReturnBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_RETURN_NO[0], BOUNDS_RETURN_NO[1])



def cgBaseDraw():
    TITLE.drawAniop(CG_BASE_NO[1])
    return TITLE.isLoopAniop(CG_BASE_NO[1])



def thumbBaseDraw(no):
    TITLE.drawAniop(CG_THUMB_BASE_NO[1], getThumbPos(no))



def thumbNoneDraw(no):
    TITLE.drawAniop(CG_THUMB_NONE_NO[1], getThumbPos(no))



def cgThumbOnDraw(no):
    TITLE.drawAniop(CG_THUMB_ON_NO[1], getThumbPos(no))



def cgNextOnDraw():
    TITLE.drawAniop(CG_NEXT_ON_NO[1])



def cgBackOnDraw():
    TITLE.drawAniop(CG_BACK_ON_NO[1])



def cgReturnOnDraw():
    TITLE.drawAniop(CG_RETURN_ON_NO[1])



def waitDraw(drawFunc, page, a, pos = (0,
 0)):
    TITLE.setAniop(a[1], TITLE.ANI_0, a[0])
    while 1:
        drawFunc(page)
        TITLE.drawAniop(a[1], pos)
        TITLE.swap()
        if TITLE.isFinishAniop(a[1]):
            break




def cgThumbWait(drawFunc, page, no):
    waitDraw(drawFunc, page, CG_THUMB_NO, getThumbPos(no))



def cgReturnWait(drawFunc, page):
    waitDraw(drawFunc, page, CG_RETURN_NO)



def cgNextWait(drawFunc, page):
    waitDraw(drawFunc, page, CG_NEXT_NO)



def cgBackWait(drawFunc, page):
    waitDraw(drawFunc, page, CG_BACK_NO)


TITLE.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
