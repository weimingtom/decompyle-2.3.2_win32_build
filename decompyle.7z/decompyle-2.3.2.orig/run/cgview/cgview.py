# emacs-mode: -*- python-*-
TITLE.debugOut(('begin:%s' % __file__))

def isVisibleEvent(num):
    import cfgvalue
    return cfgvalue.getCGViewFlag(num)



def getThumbNum(page):
    import cgviewAni
    import scene
    thumbNum = cgviewAni.getThumbNum()
    totalNum = len(scene.eventList)
    if (((page + 1) * thumbNum) > totalNum):
        return (totalNum % thumbNum)
    else:
        return thumbNum



def baseDraw(page):
    import cgviewAni
    import vram
    import scene
    thumbNum = cgviewAni.getThumbNum()
    totalNum = len(scene.eventList)
    TITLE.drawImg(vram.IMG_PAGE, 255, (-400,
     -300,
     800,
     600), (0,
     0))
    cgviewAni.cgBaseDraw()
    pos = cgviewAni.getPageBounds()
    TITLE.textOut(((pos[0] + 400),
     (pos[1] + 300)), pos[3], -1, ('%d/%d' % ((page + 1),
     (((totalNum + thumbNum) - 1) / thumbNum))))
    base = (thumbNum * page)
    drawNum = getThumbNum(page)
    for i in range(drawNum):
        if (not isVisibleEvent((base + i))):
            cgviewAni.thumbBaseDraw(i)

    for i in range((i + 1), thumbNum):
        cgviewAni.thumbNoneDraw(i)




def onCheck(page):
    import cgviewAni
    import key
    thumbNum = getThumbNum(page)
    (mx, my, mz,) = key.getPos(TITLE)
    base = (page * cgviewAni.getThumbNum())
    for i in range(thumbNum):
        if isVisibleEvent((base + i)):
            pos = cgviewAni.getThumbBounds(i)
            if (pos[0] < mx < (pos[0] + pos[2]) and pos[1] < my < (pos[1] + pos[3])):
                cgviewAni.cgThumbOnDraw(i)
                return (i + 1)

    pos = cgviewAni.getReturnBounds()
    if (pos[0] < mx < (pos[0] + pos[2]) and pos[1] < my < (pos[1] + pos[3])):
        cgviewAni.cgReturnOnDraw()
        return 100
    pos = cgviewAni.getNextBounds()
    if (pos[0] < mx < (pos[0] + pos[2]) and pos[1] < my < (pos[1] + pos[3])):
        cgviewAni.cgNextOnDraw()
        return 101
    pos = cgviewAni.getBackBounds()
    if (pos[0] < mx < (pos[0] + pos[2]) and pos[1] < my < (pos[1] + pos[3])):
        cgviewAni.cgBackOnDraw()
        return 102
    return 0



def loadPageThumb(page):
    import cgviewAni
    import vram
    base = (cgviewAni.getThumbNum() * page)
    for i in range(getThumbNum(page)):
        if isVisibleEvent((base + i)):
            pos = cgviewAni.getThumbPos(i)
            TITLE.loadImg(vram.IMG_PAGE, ((pos[0] + 400),
             (pos[1] + 300)), 'cgview/s_event.bin', (base + i))
            baseDraw(page)
            TITLE.swap()

    i += 1
    if (i < (cgviewAni.getThumbNum() - 1)):
        for i in range(i, cgviewAni.getThumbNum()):
            pos = cgviewAni.getThumbBounds(i)
            TITLE.clear(vram.IMG_PAGE, 0, ((pos[0] + 400),
             (pos[1] + 300),
             pos[2],
             pos[3]))

    TITLE.swap()
    TITLE.updateInput(TITLE.INPUT)



def viewFlowCrossIn(no, isBaseDraw):
    import cgviewAni
    import vram
    page = (no / cgviewAni.getThumbNum())
    TITLE.loadImg(vram.TMP_PAGE, (0,
     0), 'kadv/data/event.bin', no)
    startTime = TITLE.getTime()
    while 1:
        passTime = (TITLE.getTime() - startTime)
        if (passTime > 500):
            break
        if isBaseDraw:
            baseDraw(page)
        else:
            TITLE.drawImg(vram.IMG_PAGE, 255, (-400,
             -300,
             800,
             600), (0,
             0))
        alpha = ((255 * passTime) / 500)
        TITLE.drawImg(vram.TMP_PAGE, alpha, (-400,
         -300,
         800,
         600), (0,
         0))
        TITLE.swap()

    TITLE.moveImg(vram.IMG_PAGE, (0,
     0,
     800,
     600), vram.TMP_PAGE, (0,
     0))



def viewFlow(no, page):
    import cgviewAni
    import vram
    import key
    import cfgvalue
    import scene
    no += (page * cgviewAni.getThumbNum())
    viewFlowCrossIn(no, 1)
    while 1:
        TITLE.drawImg(vram.IMG_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        TITLE.swap()
        TITLE.updateInput(TITLE.INPUT)
        k = key.get(TITLE)
        if key.isCansel(TITLE):
            break
        if (key.isTrg(TITLE) or (k[key.K_DOWN][1] or k[key.K_PDOWN][1])):
            no = (no + 1)
            while (no < len(scene.eventList)):
                if isVisibleEvent(no):
                    break
                no = (no + 1)

            if (no >= len(scene.eventList)):
                no = (len(scene.eventList) - 1)
                break
            viewFlowCrossIn(no, 0)
        if (k[key.K_UP][1] or k[key.K_PUP][1]):
            no = (no - 1)
            while (no >= 0):
                if isVisibleEvent(no):
                    break
                no = (no - 1)

            if (no < 0):
                no = 0
                break
            viewFlowCrossIn(no, 0)

    page = (no / cgviewAni.getThumbNum())
    TITLE.loadImg(vram.IMG_PAGE, (0,
     0), 'cgview/cgview.png')
    startTime = TITLE.getTime()
    while 1:
        passTime = (TITLE.getTime() - startTime)
        if (passTime > 500):
            break
        baseDraw(page)
        alpha = (255 - ((255 * passTime) / 500))
        TITLE.drawImg(vram.TMP_PAGE, alpha, (-400,
         -300,
         800,
         600), (0,
         0))
        TITLE.swap()

    loadPageThumb(page)
    return page



def start():
    import cgviewAni
    import vram
    import key
    import scene
    cgviewAni.init()
    scene.playBGM('15\x81E\x82t\x81E\x82q\x82t\x81E\x82r\x82g\x82h\x81Q\x82a')
    TITLE.loadImg(vram.IMG_PAGE, (0,
     0), 'cgview/cgview.png')
    startTime = TITLE.getTime()
    while (TITLE.getTime() < (startTime + 500)):
        alpha = ((255 * (TITLE.getTime() - startTime)) / 500)
        TITLE.clear(0, 0, (0,
         0,
         800,
         600))
        TITLE.drawImg(vram.IMG_PAGE, alpha, (-400,
         -300,
         800,
         600), (0,
         0))
        TITLE.swap()

    totalNum = len(scene.eventList)
    thumbNum = cgviewAni.getThumbNum()
    pageMax = (((totalNum + thumbNum) - 1) / thumbNum)
    while 1:
        TITLE.drawImg(vram.IMG_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        if cgviewAni.cgBaseDraw():
            break
        TITLE.swap()
        TITLE.updateInput(TITLE.INPUT)

    page = 0
    loadPageThumb(page)
    while 1:
        baseDraw(page)
        isOn = onCheck(page)
        TITLE.swap()
        TITLE.updateInput(TITLE.INPUT)
        if (isOn and key.isTrg(TITLE)):
            if (isOn == 100):
                scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
                cgviewAni.cgReturnWait(baseDraw, page)
                break
            elif (isOn == 101):
                scene.playSE('\x8c\x88\x92\xe8')
                cgviewAni.cgNextWait(baseDraw, page)
                page = ((page + 1) % pageMax)
                loadPageThumb(page)
            elif (isOn == 102):
                scene.playSE('\x8c\x88\x92\xe8')
                cgviewAni.cgBackWait(baseDraw, page)
                page = (((page + pageMax) - 1) % pageMax)
                loadPageThumb(page)
            else:
                scene.playSE('\x91I\x91\xf0\x83J\x81[\x83\\\x83\x8b')
                cgviewAni.cgThumbWait(baseDraw, page, (isOn - 1))
                page = viewFlow((isOn - 1), page)
        if key.isCansel(TITLE):
            scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
            cgviewAni.cgReturnWait(baseDraw, page)
            break
        input = key.get(KADV)
        if input[key.K_PUP][2]:
            scene.playSE('\x8c\x88\x92\xe8')
            cgviewAni.cgBackWait(baseDraw, page)
            page = (((page + pageMax) - 1) % pageMax)
            loadPageThumb(page)
        if input[key.K_PDOWN][2]:
            scene.playSE('\x8c\x88\x92\xe8')
            cgviewAni.cgNextWait(baseDraw, page)
            page = ((page + 1) % pageMax)
            loadPageThumb(page)
        for i in range(len(key.DIK)):
            if (i >= getThumbNum(page)):
                break
            if TITLE.isPressKey(TITLE.INPUT, key.DIK[i]):
                scene.playSE('\x91I\x91\xf0\x83J\x81[\x83\\\x83\x8b')
                cgviewAni.cgThumbWait(baseDraw, page, i)
                page = viewFlow(i, page)
                break


    import effect
    effect.fadeOutWait(TITLE)
    KADV.stopBGM(KADV.SOUND)


TITLE.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
