# emacs-mode: -*- python-*-
TITLE.debugOut(('begin:%s' % __file__))
MP_BASE_NO = (10,
 TITLE.ANIOP_31)
MP_NEXT_ON_NO = (14,
 TITLE.ANIOP_29)
MP_BACK_ON_NO = (11,
 TITLE.ANIOP_28)
MP_NEXT_NO = (18,
 TITLE.ANIOP_26)
MP_BACK_NO = (15,
 TITLE.ANIOP_25)
MP_STOP_NO = (16,
 TITLE.ANIOP_20)
MP_STOP_ON_NO = (12,
 TITLE.ANIOP_19)
MP_PLAY_ON_NO = (13,
 TITLE.ANIOP_18)
MP_RETURN_ON_NO = (39,
 TITLE.ANIOP_27)
MP_RETURN_NO = (40,
 TITLE.ANIOP_24)
MP_THUMB_ON_NO = (20,
 TITLE.ANIOP_23)
MP_THUMB_NO = (41,
 TITLE.ANIOP_22)
MP_THUMB_PLAY_NO = (42,
 TITLE.ANIOP_21)
BOUNDS_NUM_NO = (52,
 0)
BOUNDS_THUMB_NO = (50,
 0)
BOUNDS_NEXT_NO = (51,
 3)
BOUNDS_BACK_NO = (51,
 0)
BOUNDS_STOP_NO = (51,
 1)
BOUNDS_RETURN_NO = (51,
 4)

def init():
    TITLE.loadAni(TITLE.ANI_0, 'mplay/sdpts.abb')
    nos = [MP_BASE_NO,
     MP_NEXT_ON_NO,
     MP_BACK_ON_NO,
     MP_RETURN_ON_NO,
     MP_THUMB_NO,
     MP_THUMB_PLAY_NO,
     MP_NEXT_NO,
     MP_BACK_NO,
     MP_RETURN_NO,
     MP_PLAY_ON_NO,
     MP_STOP_NO,
     MP_STOP_ON_NO]
    for i in nos:
        TITLE.setAniop(i[1], TITLE.ANI_0, i[0])




def getThumbNum():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_NUM_NO[0], BOUNDS_NUM_NO[1])[3]



def getThumbPos(no):
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_THUMB_NO[0], no)
    return (pos[0],
     pos[1])



def getThumbBounds(no):
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_THUMB_NO[0], no)



def getNextBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_NEXT_NO[0], BOUNDS_NEXT_NO[1])



def getBackBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_BACK_NO[0], BOUNDS_BACK_NO[1])



def getReturnBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_RETURN_NO[0], BOUNDS_RETURN_NO[1])



def getStopBounds():
    return TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_STOP_NO[0], BOUNDS_STOP_NO[1])



def mpBaseDraw():
    TITLE.drawAniop(MP_BASE_NO[1])
    return TITLE.isLoopAniop(MP_BASE_NO[1])



def mpThumbPlayDraw(no):
    TITLE.drawAniop(MP_THUMB_PLAY_NO[1], getThumbPos(no))



def mpThumbOnDraw(no):
    TITLE.drawAni(TITLE.ANI_0, MP_THUMB_ON_NO[0], no)



def mpNextOnDraw():
    TITLE.drawAniop(MP_NEXT_ON_NO[1])



def mpBackOnDraw():
    TITLE.drawAniop(MP_BACK_ON_NO[1])



def mpStopOnDraw():
    TITLE.drawAniop(MP_STOP_ON_NO[1])



def mpPlayOnDraw():
    TITLE.drawAniop(MP_PLAY_ON_NO[1])



def mpReturnOnDraw():
    TITLE.drawAniop(MP_RETURN_ON_NO[1])



def waitDraw(drawFunc, a, pos = (0,
 0)):
    TITLE.setAniop(a[1], TITLE.ANI_0, a[0])
    while 1:
        drawFunc()
        TITLE.drawAniop(a[1], pos)
        TITLE.swap()
        if TITLE.isFinishAniop(a[1]):
            break




def mpThumbWait(drawFunc, no):
    waitDraw(drawFunc, MP_THUMB_NO, getThumbPos(no))



def mpReturnWait(drawFunc):
    waitDraw(drawFunc, MP_RETURN_NO)



def mpNextWait(drawFunc):
    waitDraw(drawFunc, MP_NEXT_NO)



def mpBackWait(drawFunc):
    waitDraw(drawFunc, MP_BACK_NO)



def mpStopWait(drawFunc):
    waitDraw(drawFunc, MP_STOP_NO)



def initPlayingAniop():
    TITLE.setAniop(MP_THUMB_PLAY_NO[1], TITLE.ANI_0, MP_THUMB_PLAY_NO[0])



def isFinishThumbWaitPlay():
    return TITLE.isFinishAniop(MP_THUMB_NO[1])


TITLE.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
