# emacs-mode: -*- python-*-
TITLE.debugOut(('begin:%s' % __file__))
selected = 0
selectedBackup = 0
BGMS = ['01\x81E\x96\xb2\x8c\xa9\x90l\x8c`\x81QB',
 '02\x81E\x8b\xf3\x90F\x81Q\x82`',
 '03\x81E\x82t\x81E\x82q\x82t\x81E\x82r\x82g\x82h\x81Q\x82`',
 '04\x81E\x8e\xa9\x90M\x82\xaa\x82\xc8\x82\xad\x82\xc4\x81Q\x82`',
 '05\x81E\x83R\x83R\x83\x8d\x82\xcf\x82\xb7\x82\xc4\x82\xe9\x81QA',
 '06\x81E\x82\xe4\x82\xe9\x82\xe2\x82\xa9\x82\xc8\x82\xc6\x82\xab',
 '07\x81E\x83}\x83C\x83i\x83X\x83V\x83O\x83i\x83\x8b',
 '08\x81E\x83A\x83J\x83f\x83~\x83b\x83N\x81E\x83^\x83E\x83\x93\x81E\x83r\x81[\x83g',
 '09\x81E\x82\xcf\x82\xc9\x82\xcf\x82\xc9',
 '10\x81E\x94\xdf\x82\xb5\x82\xdd\x81A\x8e\xb8\x88\xd3',
 "11\x81EDevil's\x81@confident",
 '12\x81E\x90\xed\x8em\x82\xcd\x83q\x83\x8d\x83C\x83\x93',
 '13\x81E\x96\xb2\x8c\xa9\x90l\x8c`\x81Q\x82`',
 '14\x81E\x8b\xf3\x90F\x81Q\x82a',
 '15\x81E\x82t\x81E\x82q\x82t\x81E\x82r\x82g\x82h\x81Q\x82a',
 '16\x81E\x8e\xa9\x90M\x82\xaa\x82\xc8\x82\xad\x82\xc4\x81Q\x82a',
 '17\x81E\x83R\x83R\x83\x8d\x82\xcf\x82\xb7\x82\xc4\x82\xe9\x81Q\x82a',
 '18\x81E\x90\xc3\x82\xa9\x82\xc8\x96\xe9(introduce)',
 '19\x81E\x90\xc3\x82\xa9\x82\xc8\x96\xe9']

def baseDraw():
    import mplayAni
    import vram
    import scene
    TITLE.drawImg(vram.IMG_PAGE, 255, (-400,
     -300,
     800,
     600), (0,
     0))
    mplayAni.mpBaseDraw()
    ret = onCheck()
    if (selected > 0):
        mplayAni.mpPlayOnDraw()
        if mplayAni.isFinishThumbWaitPlay():
            mplayAni.mpThumbPlayDraw((selected - 1))
    return ret



def onCheck():
    import mplayAni
    import key
    thumbNum = mplayAni.getThumbNum()
    (mx, my, mz,) = key.getPos(TITLE)
    for i in range(thumbNum):
        pos = mplayAni.getThumbBounds(i)
        if (pos[0] < mx < (pos[0] + pos[2]) and pos[1] < my < (pos[1] + pos[3])):
            mplayAni.mpThumbOnDraw(i)
            return (i + 1)

    pos = mplayAni.getReturnBounds()
    if (pos[0] < mx < (pos[0] + pos[2]) and pos[1] < my < (pos[1] + pos[3])):
        mplayAni.mpReturnOnDraw()
        return 100
    pos = mplayAni.getNextBounds()
    if (pos[0] < mx < (pos[0] + pos[2]) and pos[1] < my < (pos[1] + pos[3])):
        mplayAni.mpNextOnDraw()
        return 101
    pos = mplayAni.getBackBounds()
    if (pos[0] < mx < (pos[0] + pos[2]) and pos[1] < my < (pos[1] + pos[3])):
        mplayAni.mpBackOnDraw()
        return 102
    pos = mplayAni.getStopBounds()
    if (pos[0] < mx < (pos[0] + pos[2]) and pos[1] < my < (pos[1] + pos[3])):
        mplayAni.mpStopOnDraw()
        return 103
    return 0



def start():
    global selected
    global selectedBackup
    import mplayAni
    import key
    import vram
    import scene
    mplayAni.init()
    thumbNum = mplayAni.getThumbNum()
    selected = 0
    selectedBackup = 0
    TITLE.loadImg(vram.IMG_PAGE, (0,
     0), 'mplay/sdview.png')
    startTime = TITLE.getTime()
    while (TITLE.getTime() < (startTime + 500)):
        alpha = ((255 * (TITLE.getTime() - startTime)) / 500)
        TITLE.clear(0, 0, (0,
         0,
         800,
         600))
        TITLE.drawImg(vram.IMG_PAGE, alpha, (-400,
         -300,
         800,
         600), (0,
         0))
        TITLE.swap()

    while 1:
        TITLE.drawImg(vram.IMG_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        if mplayAni.mpBaseDraw():
            break
        TITLE.swap()
        TITLE.updateInput(TITLE.INPUT)

    while 1:
        isOn = baseDraw()
        TITLE.swap()
        TITLE.updateInput(TITLE.INPUT)
        if (isOn and key.isTrg(TITLE)):
            if (isOn == 100):
                scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
                mplayAni.mpReturnWait(baseDraw)
                break
            elif (isOn == 101):
                scene.playSE('\x8c\x88\x92\xe8')
                if (selected == 0):
                    selected = selectedBackup
                selected = ((selected + 1) % (thumbNum + 1))
                if (selected == 0):
                    selected = 1
                mplayAni.mpNextWait(baseDraw)
                mplayAni.mpThumbWait(baseDraw, (selected - 1))
                mplayAni.initPlayingAniop()
                scene.playBGM(BGMS[(selected - 1)])
            elif (isOn == 102):
                scene.playSE('\x8c\x88\x92\xe8')
                if (selected == 0):
                    selected = selectedBackup
                selected = ((selected + thumbNum) % (thumbNum + 1))
                if (selected == 0):
                    selected = thumbNum
                mplayAni.mpBackWait(baseDraw)
                mplayAni.mpThumbWait(baseDraw, (selected - 1))
                mplayAni.initPlayingAniop()
                scene.playBGM(BGMS[(selected - 1)])
            elif (isOn == 103):
                scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
                mplayAni.mpStopWait(baseDraw)
                if (selected > 0):
                    selectedBackup = selected
                    selected = 0
                    KADV.stopBGM(KADV.SOUND)
            else:
                scene.playSE('\x8c\x88\x92\xe8')
                selected = isOn
                mplayAni.mpThumbWait(baseDraw, (isOn - 1))
                mplayAni.initPlayingAniop()
                scene.playBGM(BGMS[(selected - 1)])
        if key.isCansel(TITLE):
            scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
            mplayAni.mpReturnWait(baseDraw)
            break
        input = key.get(KADV)
        if input[key.K_PUP][2]:
            scene.playSE('\x8c\x88\x92\xe8')
            if (selected == 0):
                selected = selectedBackup
            selected = ((selected + thumbNum) % (thumbNum + 1))
            if (selected == 0):
                selected = thumbNum
            mplayAni.mpBackWait(baseDraw)
            mplayAni.mpThumbWait(baseDraw, (selected - 1))
            mplayAni.initPlayingAniop()
            scene.playBGM(BGMS[(selected - 1)])
        if input[key.K_PDOWN][2]:
            scene.playSE('\x8c\x88\x92\xe8')
            if (selected == 0):
                selected = selectedBackup
            selected = ((selected + 1) % (thumbNum + 1))
            if (selected == 0):
                selected = 1
            mplayAni.mpNextWait(baseDraw)
            mplayAni.mpThumbWait(baseDraw, (selected - 1))
            mplayAni.initPlayingAniop()
            scene.playBGM(BGMS[(selected - 1)])
        if input[key.K_HIDE][1]:
            scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
            mplayAni.mpStopWait(baseDraw)
            if (selected > 0):
                selectedBackup = selected
                selected = 0
                KADV.stopBGM(KADV.SOUND)
        for i in range(len(key.DIK)):
            if (i >= mplayAni.getThumbNum()):
                break
            if TITLE.isPressKey(TITLE.INPUT, key.DIK[i]):
                scene.playSE('\x8c\x88\x92\xe8')
                selected = (i + 1)
                mplayAni.mpThumbWait(baseDraw, i)
                mplayAni.initPlayingAniop()
                scene.playBGM(BGMS[(selected - 1)])
                break


    import effect
    effect.fadeOutWait(TITLE)
    KADV.stopBGM(KADV.SOUND)


TITLE.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
