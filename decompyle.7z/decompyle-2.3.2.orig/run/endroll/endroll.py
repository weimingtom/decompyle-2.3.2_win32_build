# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))

def fadeOutWait(m):
    import vram
    m.moveImg(vram.TMP_PAGE, (0,
     0,
     800,
     600), 0, (0,
     0))
    startTime = m.getTime()
    while 1:
        passTime = (m.getTime() - startTime)
        if (passTime > 300):
            break
        alpha = ((255 * passTime) / 300)
        m.drawImg(vram.TMP_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        m.drawTile(((alpha << 24) | 16777215), (-400,
         -300,
         800,
         600))
        vram.swap(m)

    m.drawTile(-1, (-400,
     -300,
     800,
     600))
    vram.swap(m)



def endrollInit(name):
    fadeOutWait(KADV)
    if (name == '\x82\xcd\x82\xc2\x82\xdd'):
        KADV.loadAni(KADV.ANI_0, 'endroll/hat_end.abb')
    elif (name == '\x97[\x95P'):
        KADV.loadAni(KADV.ANI_0, 'endroll/yuk_end.abb')
    elif (name == '\x8a\xcf\x8c\x8e'):
        KADV.loadAni(KADV.ANI_0, 'endroll/mit_end.abb')
    elif (name == '\x83T\x83L'):
        KADV.loadAni(KADV.ANI_0, 'endroll/sak_end.abb')
    else:
        KADV.loadAni(KADV.ANI_0, 'endroll/kur_end.abb')



def start(name):
    import scene
    import key
    endrollInit(name)
    KADV.updateInput(KADV.INPUT)
    KADV.setAniop(KADV.ANIOP_0, KADV.ANI_0, 0)
    scene.playBGM('19\x81E\x90\xc3\x82\xa9\x82\xc8\x96\xe9', 0)
    count = 0
    while 1:
        KADV.drawAniop(KADV.ANIOP_0)
        if KADV.isFinishAniop(KADV.ANIOP_0):
            count += 1
            if (count >= 12):
                while KADV.isPlayBGM(KADV.SOUND):
                    KADV.swap()
                    KADV.updateInput(KADV.INPUT)
                    if key.isCansel(KADV):
                        break

                break
            else:
                KADV.setAniop(KADV.ANIOP_0, KADV.ANI_0, count)
        KADV.swap()
        KADV.updateInput(KADV.INPUT)
        if key.isCansel(KADV):
            import effect
            effect.fadeOutWait(KADV)
            raise 'kadvBreakException', 'title'

    while 1:
        if key.isTrg(KADV):
            break
        KADV.swap()
        KADV.updateInput(KADV.INPUT)

    import effect
    effect.fadeOutWait(KADV)
    raise 'kadvBreakException', 'title'


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
