# emacs-mode: -*- python-*-
class ozipRead:
    __module__ = __name__
    file = None
    size = 0
    offsets = []

    def __init__(self, fname, indexs = None):
        self.open(fname, indexs)



    def __del__(self):
        self.close()



    def open(self, fname, indexs = None):
        import struct
        self.close()
        self.file = open(fname, 'rb')
        head = self.file.read(4)
        forcc = self.file.read(4)
        self.size = struct.unpack('i', self.file.read(4))[0]
        self.offsets = struct.unpack(('%di' % (self.size / 4)), self.file.read(self.size))
        if (indexs != None):
            for index in indexs:
                base = self.offsets[index]
                self.file.seek(base)
                chunk_head = self.file.read(4)
                chunk_size = self.file.read(4)
                head = self.file.read(4)
                forcc = self.file.read(4)
                self.size = struct.unpack('i', self.file.read(4))[0]
                self.offsets = struct.unpack(('%di' % (self.size / 4)), self.file.read(self.size))
                self.offsets = map(lambda x:(base + x)
, self.offsets)




    def close(self):
        if (self.file != None):
            self.file.close()
        size = 0
        offsets = []



    def getArciveNum(self):
        return len(self.offsets)



    def read(self, index):
        import struct
        self.file.seek(self.offsets[index])
        forcc = self.file.read(4)
        size = struct.unpack('i', self.file.read(4))[0]
        if (forcc == 'DFLT'):
            def_size = struct.unpack('i', self.file.read(4))[0]
            import zlib
            return zlib.decompress(self.file.read(size))
        else:
            return self.file.read(size)



if (__name__ == '__main__'):
    indexs = [0]
    o = ozipRead('kadv/data/bg.bin')
    print len(o.read(2))

# local variables:
# tab-width: 4
