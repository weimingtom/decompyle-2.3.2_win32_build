# emacs-mode: -*- python-*-

def play(m, fname, (x, y,) = (0,
 0)):
    m.openMovie(m.MOVIE, fname)
    startTime = m.getTime()
    count = 0
    import key
    while (m.isEndMovie(m.MOVIE) == 0):
        m.updateMovie(m.MOVIE, 0, (x,
         y))
        m.swap()
        m.updateInput(m.INPUT)
        if key.isCansel(m):
            m.closeMovie(m.MOVIE)
        if (m.getTime() > (startTime + 1000)):
            m.debugOut(('AVI: %d FPS' % count))
            startTime = m.getTime()
            count = 0
        else:
            count += 1




def playFull(m, fname):
    m.openMovie(m.MOVIE, fname, 1)
    import key
    while (m.isEndMovie(m.MOVIE) == 0):
        m.peekMsg()
        m.updateInput(m.INPUT)
        if key.isCansel(m):
            m.closeMovie(m.MOVIE)




# local variables:
# tab-width: 4
