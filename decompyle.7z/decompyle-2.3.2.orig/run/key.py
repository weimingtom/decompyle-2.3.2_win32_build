# emacs-mode: -*- python-*-
MOUSE_POS = 0
K_ENTER = 1
K_SKIP = 2
K_HIDE = 3
K_CANSEL = 4
K_UP = 5
K_DOWN = 6
K_PUP = 7
K_PDOWN = 8
K_1 = 9
K_2 = 10
K_3 = 11
K_4 = 12
K_5 = 13
K_6 = 14
K_7 = 15
K_8 = 16
K_9 = 17
K_0 = 18
K_F1 = 19
K_F2 = 20
K_F3 = 21
K_F4 = 22
K_F5 = 23
K_A = 24
K_S = 25
DIK = [30,
 48,
 46,
 32,
 18,
 33,
 34,
 35,
 23,
 36,
 37,
 38,
 50,
 49,
 24,
 25,
 16,
 19,
 31,
 20,
 22,
 47,
 17,
 45,
 21,
 44]

def get(m):
    return m.getInput(m.INPUT)



def getPos(m):
    return m.getInput(m.INPUT)[MOUSE_POS]



def isInput(m):
    input = m.getInput(m.INPUT)
    if input[K_ENTER][0]:
        return 1
    return 0



def isTrg(m):
    input = m.getInput(m.INPUT)
    if input[K_ENTER][1]:
        return 1
    return 0



def isAuto(m):
    input = m.getInput(m.INPUT)
    if input[K_ENTER][2]:
        return 1
    return 0



def isCansel(m):
    input = m.getInput(m.INPUT)
    if input[K_CANSEL][1]:
        return 1
    return 0



def isSkip(m):
    input = m.getInput(m.INPUT)
    if input[K_SKIP][0]:
        return 1
    return 0



def isHide(m):
    input = m.getInput(m.INPUT)
    if input[K_HIDE][1]:
        return 1
    return 0



def anyKeyWait(m):
    while 1:
        m.peekMsg()
        m.updateInput(m.INPUT)
        input = m.getInput(m.INPUT)
        for i in range(1, len(input)):
            if input[i][1]:
                return 





# local variables:
# tab-width: 4
