# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))
MAX_AUTO_SPEED = 3000
MAX_MSG_SPEED = 120
DEF_MSG_SPEED = 30

def setCGViewFlag(no):
    KADV.setFlag(KADV.FLAG, no, 1)



def getCGViewFlag(no):
    return KADV.getFlag(KADV.FLAG, no)



def setCGView(EVENT):
    import scene
    no = scene.eventList[EVENT]
    setCGViewFlag(no)



def setReplayViewFlag(name):
    import replay
    for no in range(len(replay.replayInfo)):
        if (replay.replayInfo[no][replay.ELEMENT_MODULE] == name):
            break

    KADV.setFlag(KADV.FLAG, (500 + no), 1)



def getReplayViewFlag(no):
    return KADV.getFlag(KADV.FLAG, (500 + no))



def getSEVolume():
    return KADV.getFlag(KADV.FLAG, 1000)



def setSEVolume(v):
    KADV.setFlag(KADV.FLAG, 1000, v)



def getBGMVolume():
    return KADV.getFlag(KADV.FLAG, 1001)



def setBGMVolume(v):
    KADV.setFlag(KADV.FLAG, 1001, v)



def getVoiceVolume():
    return KADV.getFlag(KADV.FLAG, 1002)



def setVoiceVolume(v):
    KADV.setFlag(KADV.FLAG, 1002, v)



def isVoiceCut(no):
    return KADV.getFlag(KADV.FLAG, (900 + no))



def setVoiceCut(no, b):
    KADV.setFlag(KADV.FLAG, (900 + no), b)



def isEffectCut():
    return KADV.getFlag(KADV.FLAG, 1004)



def setEffectCut(b):
    KADV.setFlag(KADV.FLAG, 1004, b)



def getAutoSpeed():
    v1 = KADV.getFlag(KADV.FLAG, 1005)
    v2 = KADV.getFlag(KADV.FLAG, 1006)
    return (v1 + (v2 << 8))



def setAutoSpeed(v):
    v1 = (v & 255)
    v2 = ((v >> 8) & 255)
    KADV.setFlag(KADV.FLAG, 1005, v1)
    KADV.setFlag(KADV.FLAG, 1006, v2)



def getMsgSpeed():
    return KADV.getFlag(KADV.FLAG, 1007)



def setMsgSpeed(v):
    KADV.setFlag(KADV.FLAG, 1007, v)



def isVoiceSync():
    return KADV.getFlag(KADV.FLAG, 1008)



def setVoiceSync(b):
    KADV.setFlag(KADV.FLAG, 1008, b)



def reflectionBGM():
    pass


def reflectionSE():
    pass


def reflectionVoice():
    pass


def reflectionAll():
    reflectionBGM()
    reflectionSE()
    reflectionVoice()



def init():
    setSEVolume(255)
    setBGMVolume(220)
    setVoiceVolume(255)
    setEffectCut(0)
    setAutoSpeed(1000)
    setMsgSpeed(DEF_MSG_SPEED)


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
