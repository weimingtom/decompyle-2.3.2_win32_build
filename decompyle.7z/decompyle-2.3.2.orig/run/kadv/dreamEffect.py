# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))
import math
sins = ([0.0] * 100)
for i in xrange(len(sins)):
    sins[i] = math.sin(((((math.pi * 360.0) * i) / 100.0) / 180.0))


def run():
    import keyWait
    import vram
    import scene
    import ani
    import cfgvalue
    if (keyWait.isSkip() or cfgvalue.isEffectCut()):
        return 
    startTime = KADV.getTime()
    effectTime = 2000
    waveWidth = 200
    waveWait = 10
    KADV.setBGMFadeTime(KADV.SOUND, effectTime)
    KADV.stopBGM(KADV.SOUND)
    KADV.updateInput(KADV.INPUT)
    while 1:
        if (keyWait.isSkip() or cfgvalue.isEffectCut()):
            break
        passTime = (KADV.getTime() - startTime)
        if (passTime >= effectTime):
            break
        scene.draw()
        ani.msgwinDraw()
        a = ((255 * passTime) / effectTime)
        alpha = (255 - a)
        for y in xrange(300):
            x = sins[(((passTime / waveWait) + y) % len(sins))]
            x = int((((a * waveWidth) / 255) * x))
            KADV.drawImg(vram.TMP_PAGE, alpha, ((-400 + x),
             (-300 + (y * 2)),
             800,
             2), (0,
             (y * 2)))

        keyWait.sysCheckSwap()

    keyWait.sysCheckSwap()
    KADV.setBGMFadeTime(KADV.SOUND)


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
