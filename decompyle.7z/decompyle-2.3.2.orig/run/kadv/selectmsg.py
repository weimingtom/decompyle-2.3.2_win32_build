# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))
import string
f = open('kadv/data/select.txt')
lines = f.readlines()
f.close()
labels = {}
count = 0
for l in lines:
    str = string.split(l, '#')[0]
    str = string.split(str, ',')[0]
    str = string.strip(str)
    if (len(str) > 0):
        labels[str] = count
    count += 1


def getSelStr(id):
    str = lines[labels[id]]
    str = string.split(str, '#')[0]
    elements = string.split(str, ',')
    selectNum = (len(elements) - 1)
    str = []
    for i in range(selectNum):
        str.append(string.strip(elements[(1 + i)]))

    return str



def getSelected():
    import ani
    import key
    m_input = key.getPos(KADV)
    (mx, my,) = (m_input[0],
     m_input[1])
    sel_str = getSelStr(KADV.__exp__['msg_id'])
    selNum = len(sel_str)
    selected = -1
    for i in range(selNum):
        r = ani.getSelRect(selNum, i)
        if (r[0] < mx < (r[0] + r[2]) and r[1] < my < (r[1] + r[3])):
            return i

    return -1



def draw(selected):
    import msg
    import ani
    import text
    msg.draw(KADV.__exp__['history'][-1][0], KADV.__exp__['history'][-1][1])
    ani.nameDraw(KADV.__exp__['history'][-1][0], KADV.__exp__['history'][-1][1])
    sel_str = getSelStr(KADV.__exp__['msg_id'])
    ani.selcurDraw(len(sel_str), selected)
    text.selDraw(sel_str)



def seledDraw(selected):
    import msg
    import ani
    import text
    import vram
    ret = 0
    sel_str = getSelStr(KADV.__exp__['msg_id'])
    while (ret == 0):
        msg.draw(KADV.__exp__['history'][-1][0], KADV.__exp__['history'][-1][1])
        ret = ani.seledcurDraw(len(sel_str), selected)
        text.selDraw(sel_str)
        vram.swap(KADV)

    msg.draw(KADV.__exp__['history'][-1][0], KADV.__exp__['history'][-1][1])
    vram.swap(KADV)



def selectWait():
    import ani
    import keyWait
    import key
    import vram
    import scene
    selected = -1
    sel_str = getSelStr(KADV.__exp__['msg_id'])
    while (selected < 0):
        vram.swap(KADV)
        KADV.updateInput(KADV.INPUT)
        selected = getSelected()
        draw(selected)
        ret = keyWait.sysCheck(1)
        if (ret == 1):
            selected = -1
            continue
        if ((selected >= 0) and keyWait.isTrg()):
            ani.seledcurInit()
        else:
            selected = -1
            selNum = len(sel_str)
            keys = [key.K_1,
             key.K_2,
             key.K_3,
             key.K_4,
             key.K_5,
             key.K_6,
             key.K_7,
             key.K_8,
             key.K_9,
             key.K_0]
            input = key.get(KADV)
            for i in range(selNum):
                if input[keys[i]][1]:
                    selected = i
                    ani.seledcurInit()
                    break


    scene.playSE('\x91I\x91\xf0\x83J\x81[\x83\\\x83\x8b')
    seledDraw(selected)
    vram.swap(KADV)
    KADV.updateInput(KADV.INPUT)
    return selected


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
