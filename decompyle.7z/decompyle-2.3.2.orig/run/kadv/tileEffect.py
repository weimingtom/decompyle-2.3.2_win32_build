# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))

def fadeout():
    import scene
    import keyWait
    import msg
    import vram
    import cfgvalue
    if (keyWait.isSkip() or cfgvalue.isEffectCut()):
        return 
    startTime = KADV.getTime()
    KADV.updateInput(KADV.INPUT)
    while 1:
        if (keyWait.isSkip() or cfgvalue.isEffectCut()):
            break
        passTime = (KADV.getTime() - startTime)
        if (passTime >= 300):
            break
        else:
            msg.draw(KADV.__exp__['msg_id'], KADV.__exp__['msg_page'])
            alpha = ((255 * passTime) / 300)
            alpha <<= 24
            KADV.drawTile(alpha, (-400,
             -300,
             800,
             600))
            keyWait.sysCheckSwap()

    KADV.drawTile(-16777216, (-400,
     -300,
     800,
     600))
    keyWait.sysCheckSwap()
    import vram
    KADV.clear(vram.IMG_PAGE, -16777216, (0,
     0,
     800,
     600))
    KADV.__exp__['scene_id'] = None



def flush():
    import keyWait
    import vram
    import scene
    import ani
    import cfgvalue
    if (keyWait.isSkip() or cfgvalue.isEffectCut()):
        return 
    KADV.updateInput(KADV.INPUT)
    effectTime = 40
    startTime = KADV.getTime()
    while 1:
        if (keyWait.isSkip() or cfgvalue.isEffectCut()):
            break
        passTime = (KADV.getTime() - startTime)
        if (passTime >= effectTime):
            break
        KADV.drawTile(-1, (-400,
         -300,
         800,
         600))
        keyWait.sysCheckSwap()

    effectTime = 50
    startTime = KADV.getTime()
    while 1:
        if keyWait.isSkip():
            break
        passTime = (KADV.getTime() - startTime)
        if (passTime >= effectTime):
            break
        scene.draw()
        ani.msgwinDraw()
        keyWait.sysCheckSwap()

    effectTime = 40
    startTime = KADV.getTime()
    while 1:
        if keyWait.isSkip():
            break
        passTime = (KADV.getTime() - startTime)
        if (passTime >= effectTime):
            break
        KADV.drawTile(-1, (-400,
         -300,
         800,
         600))
        keyWait.sysCheckSwap()

    scene.draw()
    ani.msgwinDraw()
    keyWait.sysCheckSwap()



def shake(effectTime, width, space = 75):
    import keyWait
    import vram
    import scene
    import ani
    import whrandom
    import cfgvalue
    if (keyWait.isSkip() or cfgvalue.isEffectCut()):
        return 
    KADV.updateInput(KADV.INPUT)
    scene.draw()
    ani.msgwinDraw()
    KADV.moveImg(vram.TMP_PAGE, (0,
     0,
     800,
     600), 0, (0,
     0))
    startTime = KADV.getTime()
    nextTime = 0
    while 1:
        if (keyWait.isSkip() or cfgvalue.isEffectCut()):
            break
        passTime = (KADV.getTime() - startTime)
        if (passTime >= effectTime):
            break
        if (passTime < nextTime):
            keyWait.sysCheckSwap()
            continue
        x = whrandom.randint(-width, width)
        y = whrandom.randint(-width, width)
        KADV.drawImg(vram.TMP_PAGE, 255, ((-400 + x),
         (-300 + y),
         800,
         600), (0,
         0))
        keyWait.sysCheckSwap()
        nextTime += space

    scene.draw()
    ani.msgwinDraw()
    keyWait.sysCheckSwap()



def bigShake():
    shake(1000, 64)



def miniShake():
    shake(500, 32)


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
