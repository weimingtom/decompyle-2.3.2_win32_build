# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))
KADV.__exp__['debug'] = 0
import sys
sys.path.append('kadv/blocks')
import flow
CHECK_FLAG = 0

def FUNC(id, nextId, func = None):
    global CHECK_FLAG
    if (KADV.__exp__['msg_id'] == id):
        CHECK_FLAG = 1
        ret = None
        if (func != None):
            ret = func()
        if (ret == None):
            KADV.__exp__['msg_id'] = nextId
        else:
            KADV.__exp__['msg_id'] = ret
        KADV.__exp__['msg_page'] = 0



def MSG(id, nextId):
    FUNC(id, nextId, flow.msg_flow)



def TEXT(id, nextId):
    FUNC(id, nextId, flow.text_flow)



def SELECT(id, *nextIds):
    global CHECK_FLAG
    if (KADV.__exp__['msg_id'] == id):
        CHECK_FLAG = 1
        if (id == None):
            return -1
        sel = flow.sel_flow(len(nextIds))
        if (nextIds[sel] != None):
            KADV.__exp__['msg_id'] = nextIds[sel]
        return sel
    return -1



def MODULE(id, m):
    global CHECK_FLAG
    if (KADV.__exp__['msg_id'] == id):
        CHECK_FLAG = 1
        KADV.__exp__['module'] = m
        KADV.__exp__['msg_id'] = None
        KADV.__exp__['msg_page'] = 0
        return 1
    return 0



def mainLoop():
    global CHECK_FLAG
    try:
        KADV.__exp__['result'] = 'end'
        try:
            import moduleList
            while (KADV.__exp__['module'] != None):
                KADV.debugOut(('in:%s' % KADV.__exp__['module']))
                CHECK_FLAG = 0
                moduleList.modules[KADV.__exp__['module']].run()
                if (CHECK_FLAG == 0):
                    KADV.messageBox(('\xd7\xcd\xde\xd9(%s)\x82\xaa\x8c\xa9\x82\xc2\x82\xa9\x82\xe8\x82\xdc\x82\xb9\x82\xf1\x82\xc5\x82\xb5\x82\xbd\x81B' % KADV.__exp__['msg_id']))
                    KADV.__exp__['result'] = 'end'
                    return 

        except 'kadvBreakException', val:
            KADV.__exp__['result'] = val
    except Exception, e:
        KADV.debugOut(('except:%s' % e))



def start():
    import scene
    if (KADV.__exp__.has_key('scene_id') and (KADV.__exp__['scene_id'] != None)):
        sname = KADV.__exp__['scene_id']
        KADV.__exp__['scene_id'] = None
        scene.load(sname)
        KADV.__exp__['scene_id'] = sname
    if (not KADV.__exp__.has_key('history')):
        KADV.__exp__['history'] = []
    if (not KADV.__exp__.has_key('sel_his')):
        KADV.__exp__['sel_his'] = []
    import ani
    ani.init()
    mainLoop()
    import load
    f = open(('%s/0.dat' % load.getDataPath(KADV)), 'wb')
    f.write(KADV.getFlagData(KADV.FLAG))
    f.close()


KADV.setMatrix(KADV.MATRIX_0, (-1,
 0,
 0,
 0,
 0,
 1,
 0,
 0,
 0,
 0,
 1,
 0,
 0,
 0,
 0,
 1))

def getParam(name):
    if KADV.__exp__.has_key(name):
        return KADV.__exp__[name]
    else:
        return 0



def setParam(name, val):
    KADV.__exp__[name] = val



def addParam(name, val):
    setParam(name, (getParam(name) + val))



def setReplayView(name):
    import cfgvalue
    cfgvalue.setReplayViewFlag(name)


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
