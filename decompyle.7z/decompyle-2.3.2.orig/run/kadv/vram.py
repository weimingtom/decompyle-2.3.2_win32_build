# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))
ANI_PAGE = 1
IMG_PAGE = 2
TEXT_PAGE = 2
TEXT_UV = (0,
 600)
TMP_PAGE = 3

def swap(m):
    if 0:
        m.moveImg(TMP_PAGE, (0,
         0,
         800,
         600), 0, (0,
         0))
        m.drawImgWithMatrix(TMP_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0), KADV.MATRIX_0)
    m.swap()


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
