# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))

def textAnim():
    import msg
    import keyWait
    import ani
    import vram
    import cfgvalue
    pageText = msg.getPageData(KADV.__exp__['msg_id'], KADV.__exp__['msg_page'])[msg.ELEMENT_TEXT]
    addTime = 0
    while (len(pageText) > 2):
        c = pageText[:2]
        if (c == '\x81@'):
            addTime += cfgvalue.getMsgSpeed()
        elif (c == ' '):
            addTime += (cfgvalue.getMsgSpeed() / 2)
        elif (c == '\\n'):
            pass
        else:
            break
        pageText = pageText[2:]

    startTime = (KADV.getTime() - addTime)
    while 1:
        passTime = (KADV.getTime() - startTime)
        KADV.updateInput(KADV.INPUT)
        isFinish = msg.draw(KADV.__exp__['msg_id'], KADV.__exp__['msg_page'], passTime)
        ani.nameDraw(KADV.__exp__['msg_id'], KADV.__exp__['msg_page'])
        isSysInput = keyWait.sysCheck()
        vram.swap(KADV)
        if isSysInput:
            continue
        if (isFinish or keyWait.isMsgFinish()):
            break



KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
