# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))

def xchange(t):
    import cfgvalue
    if cfgvalue.isEffectCut():
        return 
    import scene
    import keyWait
    import vram
    import ani
    startTime = KADV.getTime()
    while 1:
        passTime = (KADV.getTime() - startTime)
        if (passTime >= t):
            break
        if keyWait.isSkip():
            break
        alpha = (255 - ((255 * passTime) / t))
        scene.draw()
        ani.msgwinDraw()
        KADV.drawImg(vram.TMP_PAGE, alpha, (-400,
         -300,
         800,
         600), (0,
         0))
        keyWait.sysCheckSwap()

    scene.draw()
    ani.msgwinDraw()
    keyWait.sysCheckSwap()


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
