# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s(%d)' % (__file__,
 KADV.getTime())))
FONT_SIZE = 24
LINE_MARGIN = 4
FONT_NAME = '\x82l\x82r \x83S\x83V\x83b\x83N'
LINE_CHAR_COUNT = 27

def load(text):
    import vram
    if (text == '\x81@'):
        KADV.clear(vram.TEXT_PAGE, 0, (vram.TEXT_UV[0],
         vram.TEXT_UV[1],
         800,
         200))
    else:
        KADV.loadText(vram.TEXT_PAGE, vram.TEXT_UV, text, FONT_SIZE, LINE_MARGIN, FONT_NAME)



def draw(color, text, count = 2147483647, wait = 0):
    import vram
    import ani
    ret = KADV.drawText(vram.TEXT_PAGE, vram.TEXT_UV, ani.getTextXY(), color, text, FONT_SIZE, LINE_MARGIN, count, wait)
    return ret



def selDraw(texts):
    import vram
    import ani
    count = 0
    nums = ['\x82P',
     '\x82Q',
     '\x82R',
     '\x82S',
     '\x82T',
     '\x82U',
     '\x82V',
     '\x82W',
     '\x82X',
     '\x82O']
    for text in texts:
        xy = ani.getSelTextXY(len(texts), count)
        KADV.textOut(((xy[0] + 400),
         (xy[1] + 300)), FONT_SIZE, 16777215, ('%s.%s' % (nums[count],
         text)))
        count += 1



KADV.debugOut(('end:%s(%d)' % (__file__,
 KADV.getTime())))

# local variables:
# tab-width: 4
