# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))
import string
f = open('kadv/data/effect.txt')
lines = f.readlines()
f.close()
labels = {}
count = 0
for l in lines:
    str = string.split(l, '#')[0]
    str = string.split(str, ',')[0]
    str = string.strip(str)
    if (len(str) > 0):
        labels[str] = count
    count += 1

EFFECT_ID = 0
EFFECT_TYPE = 1
EFFECT_SE = 2
EFFECT_ANI = 3

def out_effect():
    import cfgvalue
    if cfgvalue.isEffectCut():
        return 
    import msg
    effectType = msg.getPageData(KADV.__exp__['msg_id'], KADV.__exp__['msg_page'])[msg.ELEMENT_EFFECT]
    if (effectType == '0'):
        return 
    str = lines[labels[effectType]]
    str = string.split(str, '#')[0]
    elements = string.split(str, ',')
    effectType = string.strip(elements[EFFECT_TYPE])
    import tileEffect
    if (effectType == 'fadeout'):
        tileEffect.fadeout()



def in_effect():
    import cfgvalue
    if cfgvalue.isEffectCut():
        return 
    import msg
    effectType = msg.getPageData(KADV.__exp__['msg_id'], KADV.__exp__['msg_page'])[msg.ELEMENT_EFFECT]
    if (effectType == '0'):
        return 0
    str = lines[labels[effectType]]
    str = string.split(str, '#')[0]
    elements = string.split(str, ',')
    effectType = string.strip(elements[EFFECT_TYPE])
    import pixelEffect
    import dreamEffect
    import tileEffect
    if (effectType == 'none'):
        return 1
    elif (effectType[:2] == 'ef'):
        pixelEffect.run(effectType)
    if (not KADV.__exp__['is_replay']):
        if (effectType == 'dream'):
            dreamEffect.run()
            return 1
    return 0



def start_effect():
    import cfgvalue
    if cfgvalue.isEffectCut():
        import key
        if key.isSkip(KADV):
            return 
        import msg
        effectType = msg.getPageData(KADV.__exp__['msg_id'], KADV.__exp__['msg_page'])[msg.ELEMENT_EFFECT]
        if (effectType == '0'):
            return 
        str = lines[labels[effectType]]
        str = string.split(str, '#')[0]
        elements = string.split(str, ',')
        se = string.strip(elements[EFFECT_SE])
        if (se != '0'):
            import scene
            scene.playSE(se)
        return 
    import msg
    effectType = msg.getPageData(KADV.__exp__['msg_id'], KADV.__exp__['msg_page'])[msg.ELEMENT_EFFECT]
    if (effectType == '0'):
        KADV.__exp__['ani_id'] = 0
        return 
    str = lines[labels[effectType]]
    str = string.split(str, '#')[0]
    elements = string.split(str, ',')
    aniNo = string.strip(elements[EFFECT_ANI])
    aniNo = string.atoi(aniNo)
    if ((aniNo != None) and (aniNo != 0)):
        if (not KADV.__exp__.has_key('ani_id')):
            KADV.setAniop(KADV.ANIOP_0, KADV.ANI_1, aniNo)
        elif (KADV.__exp__['ani_id'] != aniNo):
            KADV.setAniop(KADV.ANIOP_0, KADV.ANI_1, aniNo)
    KADV.__exp__['ani_id'] = aniNo
    effectType = string.strip(elements[EFFECT_TYPE])
    import tileEffect
    if (effectType == 'flush'):
        tileEffect.flush()
    elif (effectType == 'shake'):
        tileEffect.bigShake()
    elif (effectType == 'minishake'):
        tileEffect.miniShake()
    se = string.strip(elements[EFFECT_SE])
    if (se != '0'):
        import scene
        scene.playSE(se)



def fadeOutWait(m):
    import vram
    m.moveImg(vram.TMP_PAGE, (0,
     0,
     800,
     600), 0, (0,
     0))
    startTime = m.getTime()
    while 1:
        passTime = (m.getTime() - startTime)
        if (passTime > 300):
            break
        alpha = ((255 * passTime) / 300)
        m.drawImg(vram.TMP_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        m.drawTile((alpha << 24), (-400,
         -300,
         800,
         600))
        vram.swap(m)

    m.drawTile(-16777216, (-400,
     -300,
     800,
     600))
    vram.swap(m)



def fadeInWait(m):
    import vram
    import scene
    startTime = m.getTime()
    while 1:
        passTime = (m.getTime() - startTime)
        if (passTime > 300):
            break
        alpha = (255 - ((255 * passTime) / 300))
        scene.draw()
        m.drawTile((alpha << 24), (-400,
         -300,
         800,
         600))
        vram.swap(m)

    scene.draw()
    vram.swap(m)


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
