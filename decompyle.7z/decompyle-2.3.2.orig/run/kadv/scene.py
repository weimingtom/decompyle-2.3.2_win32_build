# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))
import string
f = open('kadv/data/scene.txt')
lines = f.readlines()
f.close()
labels = {}
count = 0
for l in lines:
    str = string.split(l, '#')[0]
    str = string.split(str, ',')[0]
    str = string.strip(str)
    if (len(str) > 0):
        if (str[0] != '#'):
            labels[str] = count
    count += 1

bgList = {}
f = open('kadv/data/bg.lst')
count = 0
for name in f.readlines():
    bgList[string.strip(name)] = count
    count += 1

f.close()
eventList = {}
f = open('kadv/data/event.lst')
count = 0
for name in f.readlines():
    eventList[string.strip(name)] = count
    count += 1

f.close()
charList = {}
f = open('kadv/data/char.lst')
count = 0
for name in f.readlines():
    charList[string.strip(name)] = count
    count += 1

f.close()
bgmList = {}
f = open('kadv/data/bgm.lst')
count = 0
for name in f.readlines():
    bgmList[string.strip(name)] = count
    count += 1

f.close()
voiceList = {}
f = open('kadv/data/voice.lst')
count = 0
for name in f.readlines():
    voiceList[string.strip(name)] = count
    count += 1

f.close()
seList = {}
f = open('kadv/data/se.lst')
count = 0
for name in f.readlines():
    seList[string.strip(name)] = count
    count += 1

f.close()
KADV.loadSE(KADV.SOUND, 'kadv/data/se.bin')
BGM_ELEMENT = 1
BG_ELEMENT = 2
EVENT_ELEMENT = 3
CHAR_ELEMENT = 4

def getElements(id):
    if labels.has_key(id):
        str = lines[labels[id]]
        str = string.split(str, '#')[0]
        elements = string.split(str, ',')
        return map(string.strip, elements)
    else:
        KADV.debugOut(('\xbc\xb0\xdd(%s)\x82\xaa\x8c\xa9\x82\xc2\x82\xa9\x82\xe8\x82\xdc\x82\xb9\x82\xf1.\n%s' % (id,
         lines)))
        return (None,
         '0',
         '0',
         '0',
         '0')



def draw(alpha = 255):
    import vram
    KADV.drawImg(vram.IMG_PAGE, alpha, (-400,
     -300,
     800,
     600), (0,
     0))
    if KADV.isFullScreen():
        tileColor = -16777216
    else:
        tileColor = -2830136
    KADV.drawTile(tileColor, (-400,
     -300,
     1,
     600))
    KADV.drawTile(tileColor, (399,
     -300,
     1,
     600))
    if KADV.__exp__['debug']:
        KADV.drawTile(0x80000000, (-400,
         -300,
         200,
         16))
        KADV.textOut((0,
         0), 16, -1, ('MODULE: %s' % KADV.__exp__['module']))
    if KADV.__exp__.has_key('ani_id'):
        if ((KADV.__exp__['ani_id'] != None) and (KADV.__exp__['ani_id'] != 0)):
            KADV.drawAniop(KADV.ANIOP_0)
    if (KADV.__exp__['module'] == 'mini'):
        import ani
        ani.drawCounter()



def stopSound():
    KADV.stopBGM(KADV.SOUND)
    KADV.stopVoice(KADV.SOUND)
    KADV.stopSE(KADV.SOUND)



def playBGM(BGM, isLoop = 1):
    if ((BGM == None) or (BGM == '0')):
        KADV.debugOut('stop BGM')
        KADV.stopBGM(KADV.SOUND)
    else:
        KADV.debugOut(('play BGM: %s' % BGM))
        import cfgvalue
        no = bgmList[BGM]
        KADV.setBGMVolume(KADV.SOUND, cfgvalue.getBGMVolume())
        KADV.playBGM(KADV.SOUND, 'kadv/data/bgm.bin', no, isLoop)



def playVoice(VOICE):
    if (VOICE == '0'):
        return 
    import cfgvalue
    if (((VOICE[0] == 'A') or (VOICE[0] == 'Q')) and cfgvalue.isVoiceCut(0)):
        return 
    elif ((VOICE[0] == 'B') and cfgvalue.isVoiceCut(1)):
        return 
    elif ((VOICE[0] == 'C') and cfgvalue.isVoiceCut(2)):
        return 
    elif ((VOICE[0] == 'E') and cfgvalue.isVoiceCut(3)):
        return 
    elif (((VOICE[0] == 'I') or (VOICE[0] == 'J')) and cfgvalue.isVoiceCut(4)):
        return 
    elif (((VOICE[0] == 'D') or (VOICE[0] == 'P')) and cfgvalue.isVoiceCut(5)):
        return 
    elif ((VOICE[0] == 'G') and cfgvalue.isVoiceCut(6)):
        return 
    elif ((VOICE[0] == 'F') and cfgvalue.isVoiceCut(7)):
        return 
    elif ((VOICE[0] == 'H') and cfgvalue.isVoiceCut(8)):
        return 
    elif (((VOICE[0] == 'K') or ((VOICE[0] == 'L') or ((VOICE[0] == 'M') or (VOICE[0] == 'O')))) and cfgvalue.isVoiceCut(9)):
        return 
    if (not voiceList.has_key(VOICE)):
        KADV.debugOut(('no has voice: %s' % VOICE))
        return 
    if KADV.__exp__['debug']:
        KADV.debugOut(('play voice: %s' % VOICE))
    no = voiceList[VOICE]
    KADV.setVoiceVolume(KADV.SOUND, cfgvalue.getVoiceVolume())
    KADV.playVoice(KADV.SOUND, 'kadv/data/voice.bin', no)



def playSE(SE):
    if ((SE == None) or (SE == '0')):
        return 
    else:
        import cfgvalue
        no = seList[SE]
        KADV.setSEVolume(KADV.SOUND, cfgvalue.getSEVolume())
        KADV.playSE(KADV.SOUND, no)



def load(id, noBGM = 0):
    import vram
    import cfgvalue
    import ani
    retcode = 0
    if (id != KADV.__exp__['scene_id']):
        elements = getElements(id)
        BGM = elements[BGM_ELEMENT]
        BG = elements[BG_ELEMENT]
        EVENT = elements[EVENT_ELEMENT]
        CHAR = elements[CHAR_ELEMENT]
        if (KADV.__exp__['scene_id'] != None):
            elements = getElements(KADV.__exp__['scene_id'])
            OLD_BGM = elements[BGM_ELEMENT]
            OLD_BG = elements[BG_ELEMENT]
            OLD_EVENT = elements[EVENT_ELEMENT]
            OLD_CHAR = elements[CHAR_ELEMENT]
        else:
            OLD_BGM = None
            OLG_BG = None
            OLD_EVENT = None
            OLD_CHAR = None
        if (EVENT != '0'):
            if (EVENT != OLD_EVENT):
                no = eventList[EVENT]
                KADV.loadImg(vram.IMG_PAGE, (0,
                 0), 'kadv/data/event.bin', no)
                KADV.drawImg(vram.IMG_PAGE, 255, (-400,
                 -300,
                 800,
                 600), (0,
                 0))
                cfgvalue.setCGViewFlag(no)
                retcode = 1
        else:
            if (BG == '0'):
                KADV.clear(0, -16777216, (0,
                 0,
                 800,
                 600))
            else:
                KADV.loadImg(vram.IMG_PAGE, (0,
                 0), 'kadv/data/bg.bin', bgList[BG])
                KADV.drawImg(vram.IMG_PAGE, 255, (-400,
                 -300,
                 800,
                 600), (0,
                 0))
            if (CHAR != '0'):
                CHAR_BOUNDS = KADV.loadImg(vram.IMG_PAGE, (0,
                 0), 'kadv/data/char.bin', charList[CHAR])
                KADV.drawImg(vram.IMG_PAGE, 255, ((-CHAR_BOUNDS[2] / 2),
                 (300 - CHAR_BOUNDS[3]),
                 CHAR_BOUNDS[2],
                 CHAR_BOUNDS[3]), (0,
                 0))
            retcode = 1
        if (retcode != 0):
            ani.drawCalendar()
            KADV.moveImg(vram.IMG_PAGE, (0,
             0,
             800,
             600), 0, (0,
             0))
        if (noBGM == 0):
            playBGM(BGM)
    return retcode


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
