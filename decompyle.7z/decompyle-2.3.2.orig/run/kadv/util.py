# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))

def timeWait(t):
    import scene
    import keyWait
    import msg
    import vram
    import cfgvalue
    if (keyWait.isSkip() or cfgvalue.isEffectCut()):
        return 
    startTime = KADV.getTime()
    KADV.moveImg(vram.TMP_PAGE, (0,
     0,
     800,
     600), 0, (0,
     0))
    KADV.updateInput(KADV.INPUT)
    while 1:
        if (keyWait.isSkip() or cfgvalue.isEffectCut()):
            break
        passTime = (KADV.getTime() - startTime)
        if (passTime >= t):
            break
        else:
            KADV.drawImg(vram.TMP_PAGE, 255, (-400,
             -300,
             800,
             600), (0,
             0))
            keyWait.sysCheckSwap()

    KADV.drawImg(vram.TMP_PAGE, 255, (-400,
     -300,
     800,
     600), (0,
     0))
    keyWait.sysCheckSwap()



def bgmFade(t):
    import keyWait
    import cfgvalue
    import vram
    if (keyWait.isSkip() or cfgvalue.isEffectCut()):
        return 
    KADV.moveImg(vram.TMP_PAGE, (0,
     0,
     800,
     600), 0, (0,
     0))
    KADV.setBGMFadeTime(KADV.SOUND, t)
    KADV.stopBGM(KADV.SOUND)
    while KADV.isPlayBGM(KADV.SOUND):
        if (keyWait.isSkip() or cfgvalue.isEffectCut()):
            break
        KADV.drawImg(vram.TMP_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        keyWait.sysCheckSwap()

    KADV.drawImg(vram.TMP_PAGE, 255, (-400,
     -300,
     800,
     600), (0,
     0))
    keyWait.sysCheckSwap()
    KADV.setBGMFadeTime(KADV.SOUND)



def allFade(t):
    import keyWait
    import cfgvalue
    import vram
    if (keyWait.isSkip() or cfgvalue.isEffectCut()):
        return 
    KADV.moveImg(vram.TMP_PAGE, (0,
     0,
     800,
     600), 0, (0,
     0))
    KADV.setBGMFadeTime(KADV.SOUND, t)
    KADV.stopBGM(KADV.SOUND)
    startTime = KADV.getTime()
    while 1:
        if (keyWait.isSkip() or cfgvalue.isEffectCut()):
            break
        passTime = (KADV.getTime() - startTime)
        if (passTime >= t):
            break
        KADV.drawImg(vram.TMP_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        alpha = ((255 * passTime) / t)
        alpha <<= 24
        KADV.drawTile(alpha, (-400,
         -300,
         800,
         600))
        keyWait.sysCheckSwap()

    KADV.drawTile(-16777216, (-400,
     -300,
     800,
     600))
    KADV.__exp__['scene_id'] = None
    keyWait.sysCheckSwap()
    KADV.setBGMFadeTime(KADV.SOUND)



def dayChange(day):
    import ani
    import vram
    KADV.__exp__['day'] = day
    KADV.drawImg(vram.IMG_PAGE, 255, (-400,
     -300,
     800,
     600), (0,
     0))
    ani.drawCalendar()
    KADV.moveImg(vram.IMG_PAGE, (0,
     0,
     800,
     600), 0, (0,
     0))


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
