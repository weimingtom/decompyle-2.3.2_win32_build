# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))
import key
readSkipOnFlag = 0
autoNextOnFlag = 0
sPressedFlag = 0
aPressedFlag = 0

def buttonFlagInit():
    global autoNextOnFlag
    global readSkipOnFlag
    readSkipOnFlag = 0
    autoNextOnFlag = 0
    import sysmenu
    sysmenu.perfectSkip = 0



def isEnter():
    return key.isAuto(KADV)



def isTrg():
    return key.isTrg(KADV)



def isSkip():
    import sysmenu
    if sysmenu.perfectSkip:
        return 1
    return key.isSkip(KADV)



def isCansel():
    return key.isCansel(KADV)



def isMsgFinish():
    import msg
    num = msg.searchPage(KADV.__exp__['msg_id'], KADV.__exp__['msg_page'])
    if readSkipOnFlag:
        if (num != None):
            if KADV.isRead(KADV.FLAG, num):
                return 1
    if (isEnter() or (isSkip() or isCansel())):
        return 1
    if (num != None):
        elements = msg.getLineData(num)
        t = elements[msg.ELEMENT_TEXT]
        if ((t == None) or ((len(t) <= 0) or (t == '\x81@'))):
            return 1
    return 0



def isMsgNext(passTime):
    import msg
    import scene
    num = msg.searchPage(KADV.__exp__['msg_id'], KADV.__exp__['msg_page'])
    if readSkipOnFlag:
        if (num != None):
            if KADV.isRead(KADV.FLAG, num):
                return 1
    if (isEnter() or isSkip()):
        return 1
    if (num != None):
        elements = msg.getLineData(num)
        t = elements[msg.ELEMENT_TEXT]
        if ((t == None) or ((len(t) <= 0) or (t == '\x81@'))):
            return 1
    if autoNextOnFlag:
        import cfgvalue
        if (passTime > cfgvalue.getAutoSpeed()):
            return 1
    return 0



def isHide(isSel):
    import ani
    ret = 0
    if key.isHide(KADV):
        ret = 1
    else:
        r = ani.getHideBounds()
        m = key.getPos(KADV)
        if (r[0] < m[0] < (r[0] + r[2]) and r[1] < m[1] < (r[1] + r[3])):
            if key.isTrg(KADV):
                ret = 1
    if ret:
        import msg
        import scene
        import vram
        startTime = KADV.getTime()
        while 1:
            passTime = (KADV.getTime() - startTime)
            if (passTime >= 100):
                break
            alpha = ((255 * passTime) / 100)
            if isSel:
                (id, page,) = (KADV.__exp__['history'][-1][0],
                 KADV.__exp__['history'][-1][1])
            else:
                (id, page,) = (KADV.__exp__['msg_id'],
                 KADV.__exp__['msg_page'])
            msg.draw(id, page)
            scene.draw(alpha)
            vram.swap(KADV)

        scene.draw()
        vram.swap(KADV)
    return ret



def isLogButton():
    import ani
    import scene
    r = ani.getLogBounds()
    m = key.getPos(KADV)
    if (r[0] < m[0] < (r[0] + r[2]) and r[1] < m[1] < (r[1] + r[3])):
        ani.logButtonDraw()
        if key.isTrg(KADV):
            scene.playSE('\x8c\x88\x92\xe8')
            import log
            log.draw()
            return 1
    input = key.get(KADV)
    if (input[key.K_PUP][1] or input[key.K_PDOWN][1]):
        scene.playSE('\x8c\x88\x92\xe8')
        import log
        log.draw()
        return 1
    return 0



def isSkipButton(isDraw = 1):
    global sPressedFlag
    import ani
    import scene
    r = ani.getSkipBounds()
    m = key.getPos(KADV)
    if (r[0] < m[0] < (r[0] + r[2]) and r[1] < m[1] < (r[1] + r[3])):
        if isDraw:
            ani.skipButtonDraw()
        if readSkipOnFlag:
            if key.isTrg(KADV):
                scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
                sPressedFlag = 0
                return 1
            if (key.isInput(KADV) and (sPressedFlag == 0)):
                scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
                return 1
        elif key.isTrg(KADV):
            scene.playSE('\x8c\x88\x92\xe8')
            sPressedFlag = 1
            return 1
    k = key.get(KADV)
    if readSkipOnFlag:
        if k[key.K_S][1]:
            scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
            sPressedFlag = 0
            return 1
        if (k[key.K_S][0] and (sPressedFlag == 0)):
            scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
            return 1
        if (k[key.K_CANSEL][0] and (sPressedFlag == 0)):
            scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
            return 1
    elif k[key.K_S][1]:
        scene.playSE('\x8c\x88\x92\xe8')
        sPressedFlag = 1
        return 1
    if ((not key.isInput(KADV)) and (not k[key.K_S][0])):
        sPressedFlag = 0
    return 0



def isAutoButton(isDraw = 1):
    global aPressedFlag
    import ani
    import scene
    r = ani.getAutoBounds()
    m = key.getPos(KADV)
    if (r[0] < m[0] < (r[0] + r[2]) and r[1] < m[1] < (r[1] + r[3])):
        if isDraw:
            ani.autoButtonDraw()
        if autoNextOnFlag:
            if key.isTrg(KADV):
                scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
                aPressedFlag = 1
                return 1
            if (key.isInput(KADV) and (aPressedFlag == 0)):
                scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
                return 1
        elif key.isTrg(KADV):
            scene.playSE('\x8c\x88\x92\xe8')
            aPressedFlag = 1
            return 1
    k = key.get(KADV)
    if autoNextOnFlag:
        if k[key.K_A][1]:
            scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
            aPressedFlag = 1
            return 1
        if (k[key.K_A][0] and (aPressedFlag == 0)):
            scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
            return 1
    elif k[key.K_A][1]:
        scene.playSE('\x8c\x88\x92\xe8')
        aPressedFlag = 1
        return 1
    if ((not key.isInput(KADV)) and (not k[key.K_A][0])):
        aPressedFlag = 0
    return 0



def isSysButton():
    import ani
    import scene
    r = ani.getSysBounds()
    m = key.getPos(KADV)
    if (r[0] < m[0] < (r[0] + r[2]) and r[1] < m[1] < (r[1] + r[3])):
        ani.sysButtonDraw()
        if key.isTrg(KADV):
            scene.playSE('\x83\x81\x83j\x83\x85\x81[\x8c\xc4\x82\xd1\x8fo\x82\xb5')
            import sysmenu
            sysmenu.draw(1)
            return 1
    k = key.get(KADV)
    if k[key.K_CANSEL][1]:
        scene.playSE('\x83\x81\x83j\x83\x85\x81[\x8c\xc4\x82\xd1\x8fo\x82\xb5')
        import sysmenu
        if KADV.isPressMouse(KADV.INPUT):
            sysmenu.draw(0)
        else:
            sysmenu.draw(1)
        return 1
    return 0



def isInput():
    return key.isInput(KADV)



def getLogValue(base, baseMax, lineMax):
    import ani
    m = key.getPos(KADV)
    if (m[2] != 0):
        return (base - (m[2] / 40))
    bounds = ani.getLogScrollBounds()
    if bounds[0] < m[0] < (bounds[0] + bounds[2]):
        if bounds[1] < m[1] < (bounds[1] + bounds[3]):
            if isInput():
                alpha = ani.getLogScrollAlpha(m[1])
                return int((baseMax * alpha))
    bounds = ani.getLogUpBounds()
    if bounds[0] < m[0] < (bounds[0] + bounds[2]):
        if bounds[1] < m[1] < (bounds[1] + bounds[3]):
            if isInput():
                ani.logUpPressDraw()
            else:
                ani.logUpDraw()
            if isEnter():
                return (base - 1)
    bounds = ani.getLogDownBounds()
    if bounds[0] < m[0] < (bounds[0] + bounds[2]):
        if bounds[1] < m[1] < (bounds[1] + bounds[3]):
            if isInput():
                ani.logDownPressDraw()
            else:
                ani.logDownDraw()
            if isEnter():
                return (base + 1)
    input = key.get(KADV)
    if (input[key.K_UP][0] or input[key.K_PUP][0]):
        ani.logUpPressDraw()
    if (input[key.K_DOWN][0] or input[key.K_PDOWN][0]):
        ani.logDownPressDraw()
    if input[key.K_UP][2]:
        return (base - 1)
    if input[key.K_DOWN][2]:
        return (base + 1)
    if input[key.K_PUP][2]:
        return (base - lineMax)
    if input[key.K_PDOWN][2]:
        return (base + lineMax)
    return base



def sysCheck(isSel = 0):
    global autoNextOnFlag
    global readSkipOnFlag
    if isHide(isSel):
        if KADV.__exp__['debug']:
            keys = KADV.__exp__.keys()
            keys.sort()
            f = open('\x83p\x83\x89\x83\x81\x81[\x83^.txt', 'w')
            for key in keys:
                if (key == 'history'):
                    f.write(('%s: %s\n' % (key,
                     '\x8c\xbb\x8d\xdd\x8fo\x97\xcd\x82\xf0\x92\xe2\x8e~\x82\xb5\x82\xc4\x82\xa2\x82\xdc\x82\xb7\x81B')))
                    continue
                f.write(('%s: %s\n' % (key,
                 KADV.__exp__[key])))

            f.close()
        import key
        key.anyKeyWait(KADV)
        return 1
    if (not KADV.__exp__['is_replay']):
        if isLogButton():
            return 1
        if isSkipButton():
            readSkipOnFlag = (not readSkipOnFlag)
            return 1
    if isAutoButton():
        autoNextOnFlag = (not autoNextOnFlag)
        return 1
    if isSysButton():
        return 1
    import key
    import scene
    import vram
    k = key.get(KADV)
    if (not KADV.__exp__['is_replay']):
        if k[key.K_F1][1]:
            scene.playSE('\x8c\x88\x92\xe8')
            import save
            import ani
            sid = KADV.__exp__['scene_id']
            save.start(KADV, None)
            if (sid != None):
                scene.load(sid)
            KADV.__exp__['scene_id'] = sid
            ani.init()
            return 1
        if k[key.K_F2][1]:
            scene.playSE('\x8c\x88\x92\xe8')
            import load
            import ani
            sid = KADV.__exp__['scene_id']
            isBreak = load.start(KADV, None)
            if (isBreak == 0):
                if (sid != None):
                    scene.load(sid)
                KADV.__exp__['scene_id'] = sid
                ani.init()
                return 1
            else:
                raise 'kadvBreakException', 'kadv'
        if k[key.K_F3][1]:
            scene.playSE('\x8c\x88\x92\xe8')
            import sysmenu
            sysmenu.perfectSkip = 1
            scene.draw()
            vram.swap(KADV)
            raise 'kadvBreakException', 'kadv'
    if k[key.K_F4][1]:
        scene.playSE('\x8c\x88\x92\xe8')
        import config
        import ani
        config.start(KADV, None)
        ani.init()
        return 1
    if k[key.K_F5][1]:
        scene.playSE('\x8c\x88\x92\xe8')
        if KADV.__exp__['is_replay']:
            ret = KADV.yesnoBox('\x8am\x94F', '\x83\x8a\x83v\x83\x8c\x83C\x82\xf0\x8fI\x97\xb9\x82\xb5\x82\xdc\x82\xb7\x82\xa9\x81H')
            if ret:
                import scene
                scene.stopSound()
                raise 'kadvBreakException', 'title'
            return 1
        else:
            ret = KADV.yesnoBox('\x8am\x94F', '\x83^\x83C\x83g\x83\x8b\x82\xd6\x96\xdf\x82\xe8\x82\xdc\x82\xb7\x82\xa9\x81H')
            if ret:
                import scene
                scene.stopSound()
                raise 'kadvBreakException', 'title'
            return 1
    return 0



def sysCheckSwap():
    global autoNextOnFlag
    global readSkipOnFlag
    import vram
    KADV.updateInput(KADV.INPUT)
    vram.swap(KADV)
    if (not KADV.__exp__['is_replay']):
        if isSkipButton(0):
            readSkipOnFlag = (not readSkipOnFlag)
            return 1
    if isAutoButton(0):
        autoNextOnFlag = (not autoNextOnFlag)
        return 1
    return 0


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
