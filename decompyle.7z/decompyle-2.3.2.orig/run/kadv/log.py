# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))
import string
ELEMENT_NAME = 0
ELEMENT_COLOR = 1
ELEMENT_TEXT = 2
ELEMENT_VOICE = 3

def clear():
    KADV.__exp__['history'] = []
    KADV.__exp__['sel_his'] = []



def add(id, page):
    import msg
    lineNo = msg.searchPage(id, page)
    if (lineNo != None):
        KADV.setRead(KADV.FLAG, lineNo)
        pageData = msg.getLineData(lineNo)
        if (pageData[msg.ELEMENT_TEXT] == '\x81@'):
            return 
        KADV.__exp__['history'].append((id,
         page))



def addSel(text):
    KADV.__exp__['sel_his'].append(((len(KADV.__exp__['history']) - 1),
     text))



def makeLogData(his, selhis):
    d = []
    import msg
    import name
    hiscount = 0
    for h in his:
        pageData = msg.getPageData(h[0], h[1])
        if (pageData == None):
            KADV.messageBox(('(%s : %s)\x82\xaa\x8c\xa9\x82\xc2\x82\xa9\x82\xe8\x82\xdc\x82\xb9\x82\xf1\x82\xc5\x82\xb5\x82\xbd\x81B\n\xbe\xb0\xcc\xde\xc3\xde\xb0\xc0\x82\xc6\xd2\xaf\xbe\xb0\xbc\xde\xc3\xde\xb0\xc0\x82\xcc\xca\xde\xb0\xbc\xde\xae\xdd\x82\xaa\n\x88\xea\x92v\x82\xb5\x82\xc4\x82\xa2\x82\xe9\x82\xa9\x8am\x82\xa9\x82\xdf\x82\xc4\x82\xad\x82\xbe\x82\xb3\x82\xa2\x81B' % (h[0],
             h[1])))
            hiscount += 1
            continue
        color = msg.getPageColor(h[0], h[1])
        voice = pageData[msg.ELEMENT_VOICE]
        lines = string.split(msg.getProhibityStr(pageData[msg.ELEMENT_TEXT]), '\n')
        count = 0
        for t in lines:
            t = string.replace(t, chr(255), ' ')
            if (count == 0):
                i = name.getNameIndex(pageData[msg.ELEMENT_NAME])
                if (i == -1):
                    d.append((None,
                     color,
                     t,
                     voice))
                else:
                    d.append((pageData[msg.ELEMENT_NAME],
                     color,
                     t,
                     voice))
            else:
                d.append((None,
                 color,
                 t,
                 '0'))
            count += 1

        d.append((None,
         None,
         None,
         None))
        for sh in selhis:
            if (hiscount == sh[0]):
                d.append((None,
                 -256,
                 sh[1],
                 None))
                d.append((None,
                 None,
                 None,
                 None))

        hiscount += 1

    return d



def draw():
    import keyWait
    import scene
    import ani
    import key
    import vram
    d = makeLogData(KADV.__exp__['history'], KADV.__exp__['sel_his'])
    KADV.stopVoice(KADV.SOUND)
    xyh = ani.getLogTextBounds()
    nameX = (ani.getLogNameBounds()[0] + 400)
    fontSize = 14
    margin = 2
    lineMax = (xyh[3] / (fontSize + margin))
    max = len(d)
    base = (max - lineMax)
    if (base < 0):
        base = 0
    baseMax = base
    while 1:
        vram.swap(KADV)
        KADV.updateInput(KADV.INPUT)
        scene.draw()
        ani.logwinDraw()
        if baseMax:
            alpha = (float(base) / baseMax)
            ani.logScrollDraw(alpha)
        x = (xyh[0] + 400)
        y = (xyh[1] + 300)
        count = 0
        if (max != 0):
            for i in range(base, max):
                if (d[i][ELEMENT_TEXT] != None):
                    if (d[i][ELEMENT_NAME] != None):
                        KADV.textOut((nameX,
                         y), fontSize, d[i][ELEMENT_COLOR], d[i][ELEMENT_NAME])
                    KADV.textOut((x,
                     y), fontSize, d[i][ELEMENT_COLOR], d[i][ELEMENT_TEXT])
                    if ((d[i][ELEMENT_VOICE] != None) and (d[i][ELEMENT_VOICE] != '0')):
                        b = ani.getLogSpkBounds()
                        pos = key.getPos(KADV)
                        if (b[0] < pos[0] < (b[0] + b[2]) and (y - 300) < pos[1] < ((y - 300) + b[3])):
                            ani.logSpkSelDraw((y - 300))
                            if key.isTrg(KADV):
                                scene.playVoice(d[i][ELEMENT_VOICE])
                        else:
                            ani.logSpkDraw((y - 300))
                y += (fontSize + margin)
                count += 1
                if (count >= lineMax):
                    break

        if keyWait.isCansel():
            break
        b = ani.getLogHideBounds()
        pos = key.getPos(KADV)
        if (b[0] < pos[0] < (b[0] + b[2]) and b[1] < pos[1] < (b[1] + b[3])):
            ani.logHideDraw()
            if key.isTrg(KADV):
                break
        base = keyWait.getLogValue(base, baseMax, lineMax)
        if (base < 0):
            base = 0
        if (base > baseMax):
            base = baseMax

    scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
    KADV.stopVoice(KADV.SOUND)


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
