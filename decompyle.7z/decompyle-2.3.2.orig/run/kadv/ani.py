# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))
ANI_NAME = 1
BAR_NOSEL_NO = (10,
 KADV.ANIOP_26)
BAR_SEL_NO = (11,
 KADV.ANIOP_25)
BAR_SELED_NO = (14,
 KADV.ANIOP_24)
BOUNDS_SEL_ABLE_NO = (12,
 0)
BOUNDS_SEL_MSG_NO = (12,
 1)
BOUNDS_SEL_2_NO = (20,
 0)
BOUNDS_SEL_3_NO = (21,
 0)
BOUNDS_SEL_4_NO = (22,
 0)
BOUNDS_SEL_5_NO = (23,
 0)
MSG_WINDOW_NO = (50,
 KADV.ANIOP_31)
NAME_WINDOW_NO = (1,
 KADV.ANIOP_15)
NEXT_CURSOR_NO = (62,
 KADV.ANIOP_3)
ICON_LOG_NO = (51,
 KADV.ANIOP_30)
ICON_SKIP_NO = (52,
 KADV.ANIOP_29)
ICON_AUTO_NO = (53,
 KADV.ANIOP_28)
ICON_SYS_NO = (60,
 KADV.ANIOP_27)
ICON_SKIP_ON_NO = (63,
 KADV.ANIOP_17)
ICON_AUTO_ON_NO = (64,
 KADV.ANIOP_16)
BOUNDS_NAME_NO = (0,
 0)
BOUNDS_NAMEPLATE_NO = (2,
 0)
BOUNDS_TEXT_NO = (54,
 0)
BOUNDS_LOG_NO = (54,
 1)
BOUNDS_SKIP_NO = (54,
 2)
BOUNDS_AUTO_NO = (54,
 3)
BOUNDS_HIDE_NO = (54,
 4)
BOUNDS_SYS_NO = (54,
 5)
LOG_WINDOW_NO = (70,
 KADV.ANIOP_23)
LOG_SCROLL_NO = (78,
 KADV.ANIOP_22)
LOG_UP_NO = (80,
 KADV.ANIOP_21)
LOG_DOWN_NO = (81,
 KADV.ANIOP_20)
LOG_UP_PRESS_NO = (82,
 KADV.ANIOP_19)
LOG_DOWN_PRESS_NO = (83,
 KADV.ANIOP_18)
LOG_SPK_NO = (73,
 KADV.ANIOP_7)
LOG_SPK_SEL_NO = (74,
 KADV.ANIOP_6)
LOG_SPK_WAIT_NO = (75,
 KADV.ANIOP_5)
LOG_HIDE_NO = (76,
 KADV.ANIOP_4)
BOUNDS_LOG_TEXT_NO = (71,
 0)
BOUNDS_LOG_NAME_NO = (71,
 1)
BOUNDS_LOG_SCROLL_TOP_NO = (71,
 4)
BOUNDS_LOG_SCROLL_BOTTOM_NO = (71,
 5)
BOUNDS_LOG_UP_NO = (71,
 6)
BOUNDS_LOG_DOWN_NO = (71,
 7)
BOUNDS_LOG_SPK_NO = (71,
 2)
BOUNDS_LOG_HIDE_NO = (71,
 3)
SYSMENU_BASE_NO = (100,
 KADV.ANIOP_14)
BOUNDS_SYSMENU_BASE_NO = (110,
 0)
BOUNDS_SYSMENU_CANSEL_NO = (110,
 1)
BOUNDS_SYSMENU_SAVE_NO = (110,
 2)
BOUNDS_SYSMENU_LOAD_NO = (110,
 3)
BOUNDS_SYSMENU_SKIP_NO = (110,
 4)
BOUNDS_SYSMENU_CONFIG_NO = (110,
 5)
BOUNDS_SYSMENU_TITLE_NO = (110,
 6)
SYSMENU_CANSEL_NO = (101,
 KADV.ANIOP_13)
SYSMENU_SAVE_NO = (103,
 KADV.ANIOP_12)
SYSMENU_LOAD_NO = (104,
 KADV.ANIOP_11)
SYSMENU_SKIP_NO = (102,
 KADV.ANIOP_10)
SYSMENU_CONFIG_NO = (105,
 KADV.ANIOP_9)
SYSMENU_TITLE_NO = (106,
 KADV.ANIOP_8)

def init():
    if KADV.__exp__['is_replay']:
        KADV.loadAni(KADV.ANI_0, 'kadv/data/mreplay.abb')
    else:
        KADV.loadAni(KADV.ANI_0, 'kadv/data/main.abb')
    KADV.loadAni(KADV.ANI_1, 'kadv/data/item.abb')
    KADV.loadAni(KADV.ANI_2, 'kadv/data/game.abb')
    KADV.setAniop(MSG_WINDOW_NO[1], KADV.ANI_0, MSG_WINDOW_NO[0])
    KADV.setAniop(NAME_WINDOW_NO[1], KADV.ANI_0, NAME_WINDOW_NO[0])
    KADV.setAniop(ICON_LOG_NO[1], KADV.ANI_0, ICON_LOG_NO[0])
    KADV.setAniop(ICON_SKIP_NO[1], KADV.ANI_0, ICON_SKIP_NO[0])
    KADV.setAniop(ICON_AUTO_NO[1], KADV.ANI_0, ICON_AUTO_NO[0])
    KADV.setAniop(ICON_SYS_NO[1], KADV.ANI_0, ICON_SYS_NO[0])
    KADV.setAniop(ICON_SKIP_ON_NO[1], KADV.ANI_0, ICON_SKIP_ON_NO[0])
    KADV.setAniop(ICON_AUTO_ON_NO[1], KADV.ANI_0, ICON_AUTO_ON_NO[0])
    KADV.setAniop(BAR_NOSEL_NO[1], KADV.ANI_0, BAR_NOSEL_NO[0])
    KADV.setAniop(BAR_SEL_NO[1], KADV.ANI_0, BAR_SEL_NO[0])
    KADV.setAniop(BAR_SELED_NO[1], KADV.ANI_0, BAR_SELED_NO[0])
    KADV.setAniop(LOG_WINDOW_NO[1], KADV.ANI_0, LOG_WINDOW_NO[0])
    KADV.setAniop(LOG_SCROLL_NO[1], KADV.ANI_0, LOG_SCROLL_NO[0])
    KADV.setAniop(LOG_UP_NO[1], KADV.ANI_0, LOG_UP_NO[0])
    KADV.setAniop(LOG_DOWN_NO[1], KADV.ANI_0, LOG_DOWN_NO[0])
    KADV.setAniop(LOG_UP_PRESS_NO[1], KADV.ANI_0, LOG_UP_PRESS_NO[0])
    KADV.setAniop(LOG_DOWN_PRESS_NO[1], KADV.ANI_0, LOG_DOWN_PRESS_NO[0])
    KADV.setAniop(LOG_SPK_NO[1], KADV.ANI_0, LOG_SPK_NO[0])
    KADV.setAniop(LOG_SPK_SEL_NO[1], KADV.ANI_0, LOG_SPK_SEL_NO[0])
    KADV.setAniop(LOG_SPK_WAIT_NO[1], KADV.ANI_0, LOG_SPK_WAIT_NO[0])
    KADV.setAniop(LOG_HIDE_NO[1], KADV.ANI_0, LOG_HIDE_NO[0])
    KADV.setAniop(SYSMENU_BASE_NO[1], KADV.ANI_0, SYSMENU_BASE_NO[0])
    KADV.setAniop(SYSMENU_CANSEL_NO[1], KADV.ANI_0, SYSMENU_CANSEL_NO[0])
    KADV.setAniop(SYSMENU_SAVE_NO[1], KADV.ANI_0, SYSMENU_SAVE_NO[0])
    KADV.setAniop(SYSMENU_LOAD_NO[1], KADV.ANI_0, SYSMENU_LOAD_NO[0])
    KADV.setAniop(SYSMENU_SKIP_NO[1], KADV.ANI_0, SYSMENU_SKIP_NO[0])
    KADV.setAniop(SYSMENU_CONFIG_NO[1], KADV.ANI_0, SYSMENU_CONFIG_NO[0])
    KADV.setAniop(SYSMENU_TITLE_NO[1], KADV.ANI_0, SYSMENU_TITLE_NO[0])



def initNextCursor():
    KADV.setAniop(NEXT_CURSOR_NO[1], KADV.ANI_0, NEXT_CURSOR_NO[0])



def drawNextCursor():
    if (KADV.__exp__.has_key('windowHide') and KADV.__exp__['windowHide']):
        pass
    else:
        KADV.drawAniop(NEXT_CURSOR_NO[1])



def nameDraw(id, page):
    import name
    import msg
    pageData = msg.getPageData(id, page)
    no = name.getNameIndex(pageData[msg.ELEMENT_NAME])
    if (no == -1):
        return 
    KADV.drawAniop(NAME_WINDOW_NO[1])
    if ANI_NAME:
        pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_NAMEPLATE_NO[0], BOUNDS_NAMEPLATE_NO[1])
        p = KADV.getAniBounds(KADV.ANI_0, BOUNDS_NAME_NO[0], no)
        offset = ((pos[2] - p[2]) / 2)
        KADV.drawAni(KADV.ANI_0, 0, no, ((pos[0] + offset),
         pos[1]))
    else:
        pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_NAMEPLATE_NO[0], BOUNDS_NAMEPLATE_NO[1])
        offset = ((pos[2] - ((len(n) * pos[3]) / 2)) / 2)
        KADV.textOut((((pos[0] + 400) + offset),
         (pos[1] + 300)), pos[3], 16777215, n)



def msgwinDraw():
    if (KADV.__exp__.has_key('windowHide') and KADV.__exp__['windowHide']):
        pass
    else:
        KADV.drawAniop(MSG_WINDOW_NO[1])
        import keyWait
        if keyWait.readSkipOnFlag:
            KADV.drawAniop(ICON_SKIP_ON_NO[1])
        if keyWait.autoNextOnFlag:
            KADV.drawAniop(ICON_AUTO_ON_NO[1])



def getSelRect(selNum, num):
    rect = KADV.getAniBounds(KADV.ANI_0, BOUNDS_SEL_ABLE_NO[0], 0)
    if (selNum == 5):
        pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_SEL_5_NO[0], num)
    elif (selNum == 4):
        pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_SEL_4_NO[0], num)
    elif (selNum == 3):
        pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_SEL_3_NO[0], num)
    else:
        pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_SEL_2_NO[0], num)
    return ((rect[0] + pos[0]),
     (rect[1] + pos[1]),
     rect[2],
     rect[3])



def getSelXY(selNum, num):
    pos = getSelRect(selNum, num)
    return (pos[0],
     pos[1])



def getSelTextXY(selNum, num):
    pos = getSelRect(selNum, num)
    add = KADV.getAniBounds(KADV.ANI_0, BOUNDS_SEL_MSG_NO[0], BOUNDS_SEL_MSG_NO[1])
    return ((pos[0] + add[0]),
     (pos[1] + add[1]))



def selcurDraw(selNum, num):
    for i in range(selNum):
        if (i == num):
            KADV.drawAniop(BAR_SEL_NO[1], getSelXY(selNum, i))
        else:
            KADV.drawAniop(BAR_NOSEL_NO[1], getSelXY(selNum, i))




def seledcurInit():
    KADV.setAniop(BAR_SELED_NO[1], KADV.ANI_0, BAR_SELED_NO[0])



def seledcurDraw(selNum, num):
    for i in range(selNum):
        if (i == num):
            KADV.drawAniop(BAR_SELED_NO[1], getSelXY(selNum, i))
        else:
            KADV.drawAniop(BAR_NOSEL_NO[1], getSelXY(selNum, i))

    return KADV.isFinishAniop(BAR_SELED_NO[1])



def getTextXY():
    pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_TEXT_NO[0], BOUNDS_TEXT_NO[1])
    return (pos[0],
     pos[1])



def getHideBounds():
    return KADV.getAniBounds(KADV.ANI_0, BOUNDS_HIDE_NO[0], BOUNDS_HIDE_NO[1])



def getLogBounds():
    return KADV.getAniBounds(KADV.ANI_0, BOUNDS_LOG_NO[0], BOUNDS_LOG_NO[1])



def getSkipBounds():
    return KADV.getAniBounds(KADV.ANI_0, BOUNDS_SKIP_NO[0], BOUNDS_SKIP_NO[1])



def getSysBounds():
    return KADV.getAniBounds(KADV.ANI_0, BOUNDS_SYS_NO[0], BOUNDS_SYS_NO[1])



def getAutoBounds():
    return KADV.getAniBounds(KADV.ANI_0, BOUNDS_AUTO_NO[0], BOUNDS_AUTO_NO[1])



def logButtonDraw():
    if (KADV.__exp__.has_key('windowHide') and KADV.__exp__['windowHide']):
        pass
    else:
        KADV.drawAniop(ICON_LOG_NO[1])



def skipButtonDraw():
    if (KADV.__exp__.has_key('windowHide') and KADV.__exp__['windowHide']):
        pass
    else:
        KADV.drawAniop(ICON_SKIP_NO[1])



def autoButtonDraw():
    if (KADV.__exp__.has_key('windowHide') and KADV.__exp__['windowHide']):
        pass
    else:
        KADV.drawAniop(ICON_AUTO_NO[1])



def sysButtonDraw():
    if (KADV.__exp__.has_key('windowHide') and KADV.__exp__['windowHide']):
        pass
    else:
        KADV.drawAniop(ICON_SYS_NO[1])



def logwinDraw():
    KADV.drawAniop(LOG_WINDOW_NO[1])



def logScrollDraw(alpha):
    top = KADV.getAniBounds(KADV.ANI_0, BOUNDS_LOG_SCROLL_TOP_NO[0], BOUNDS_LOG_SCROLL_TOP_NO[1])
    bottom = KADV.getAniBounds(KADV.ANI_0, BOUNDS_LOG_SCROLL_BOTTOM_NO[0], BOUNDS_LOG_SCROLL_BOTTOM_NO[1])
    h = ((bottom[1] - top[1]) * alpha)
    pos = (top[0],
     int((top[1] + h)))
    KADV.drawAniop(LOG_SCROLL_NO[1], pos)



def logUpDraw():
    KADV.drawAniop(LOG_UP_NO[1])



def logDownDraw():
    KADV.drawAniop(LOG_DOWN_NO[1])



def logUpPressDraw():
    KADV.drawAniop(LOG_UP_PRESS_NO[1])



def logDownPressDraw():
    KADV.drawAniop(LOG_DOWN_PRESS_NO[1])



def getLogTextBounds():
    pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_LOG_TEXT_NO[0], BOUNDS_LOG_TEXT_NO[1])
    return pos



def getLogNameBounds():
    pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_LOG_NAME_NO[0], BOUNDS_LOG_NAME_NO[1])
    return (pos[0],
     pos[1])



def getLogScrollBounds():
    top = KADV.getAniBounds(KADV.ANI_0, BOUNDS_LOG_SCROLL_TOP_NO[0], BOUNDS_LOG_SCROLL_TOP_NO[1])
    bottom = KADV.getAniBounds(KADV.ANI_0, BOUNDS_LOG_SCROLL_BOTTOM_NO[0], BOUNDS_LOG_SCROLL_BOTTOM_NO[1])
    bar = KADV.getAniBounds(KADV.ANI_0, LOG_SCROLL_NO[0])
    return (top[0],
     top[1],
     bar[2],
     ((bottom[1] - top[1]) + bar[3]))



def getLogScrollAlpha(y):
    top = KADV.getAniBounds(KADV.ANI_0, BOUNDS_LOG_SCROLL_TOP_NO[0], BOUNDS_LOG_SCROLL_TOP_NO[1])
    bottom = KADV.getAniBounds(KADV.ANI_0, BOUNDS_LOG_SCROLL_BOTTOM_NO[0], BOUNDS_LOG_SCROLL_BOTTOM_NO[1])
    bar = KADV.getAniBounds(KADV.ANI_0, LOG_SCROLL_NO[0])
    h = (bottom[1] - top[1])
    y -= (bar[3] / 2)
    return (float((y - top[1])) / h)



def getLogUpBounds():
    return KADV.getAniBounds(KADV.ANI_0, BOUNDS_LOG_UP_NO[0], BOUNDS_LOG_UP_NO[1])



def getLogDownBounds():
    return KADV.getAniBounds(KADV.ANI_0, BOUNDS_LOG_DOWN_NO[0], BOUNDS_LOG_DOWN_NO[1])



def getLogSpkBounds():
    pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_LOG_SPK_NO[0], BOUNDS_LOG_SPK_NO[1])
    return pos



def logSpkDraw(y):
    pos = getLogSpkBounds()
    KADV.drawAniop(LOG_SPK_NO[1], (pos[0],
     y))



def logSpkSelDraw(y):
    pos = getLogSpkBounds()
    KADV.drawAniop(LOG_SPK_SEL_NO[1], (pos[0],
     y))



def logSpkWaitDraw(y):
    pos = getLogSpkBounds()
    KADV.drawAniop(LOG_SPK_WAIT_NO[1], (pos[0],
     y))
    return KADV.isFinishAniop(LOG_SPK_WAIT_NO[1])



def logHideDraw():
    KADV.drawAniop(LOG_HIDE_NO[1])



def getLogHideBounds():
    pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_LOG_HIDE_NO[0], BOUNDS_LOG_HIDE_NO[1])
    return pos


sysmenuPos = [0,
 0]

def sysmenuInit(m, isFix = 0):
    KADV.setAniop(SYSMENU_BASE_NO[1], KADV.ANI_0, SYSMENU_BASE_NO[0])
    bounds = KADV.getAniBounds(KADV.ANI_0, BOUNDS_SYSMENU_BASE_NO[0], BOUNDS_SYSMENU_BASE_NO[1])
    if (not isFix):
        import key
        pos = key.getPos(m)
        if ((pos[0] - bounds[2]) > -400):
            if ((pos[0] + bounds[2]) > 400):
                sysmenuPos[0] = (pos[0] - bounds[2])
            else:
                sysmenuPos[0] = pos[0]
        else:
            sysmenuPos[0] = pos[0]
        if ((pos[1] - bounds[3]) > -300):
            if ((pos[1] + bounds[3]) > 300):
                sysmenuPos[1] = (pos[1] - bounds[3])
            else:
                sysmenuPos[1] = pos[1]
        else:
            sysmenuPos[1] = pos[1]
    else:
        sysmenuPos[0] = (-bounds[2] / 2)
        sysmenuPos[1] = (-bounds[3] / 2)



def getSysmenuCanselBounds():
    pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_SYSMENU_CANSEL_NO[0], BOUNDS_SYSMENU_CANSEL_NO[1])
    return ((pos[0] + sysmenuPos[0]),
     (pos[1] + sysmenuPos[1]),
     pos[2],
     pos[3])



def getSysmenuSaveBounds():
    pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_SYSMENU_SAVE_NO[0], BOUNDS_SYSMENU_SAVE_NO[1])
    return ((pos[0] + sysmenuPos[0]),
     (pos[1] + sysmenuPos[1]),
     pos[2],
     pos[3])



def getSysmenuLoadBounds():
    pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_SYSMENU_LOAD_NO[0], BOUNDS_SYSMENU_LOAD_NO[1])
    return ((pos[0] + sysmenuPos[0]),
     (pos[1] + sysmenuPos[1]),
     pos[2],
     pos[3])



def getSysmenuSkipBounds():
    pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_SYSMENU_SKIP_NO[0], BOUNDS_SYSMENU_SKIP_NO[1])
    return ((pos[0] + sysmenuPos[0]),
     (pos[1] + sysmenuPos[1]),
     pos[2],
     pos[3])



def getSysmenuConfigBounds():
    pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_SYSMENU_CONFIG_NO[0], BOUNDS_SYSMENU_CONFIG_NO[1])
    return ((pos[0] + sysmenuPos[0]),
     (pos[1] + sysmenuPos[1]),
     pos[2],
     pos[3])



def getSysmenuTitleBounds():
    pos = KADV.getAniBounds(KADV.ANI_0, BOUNDS_SYSMENU_TITLE_NO[0], BOUNDS_SYSMENU_TITLE_NO[1])
    return ((pos[0] + sysmenuPos[0]),
     (pos[1] + sysmenuPos[1]),
     pos[2],
     pos[3])



def sysmenuDraw():
    KADV.drawAniop(SYSMENU_BASE_NO[1], sysmenuPos)
    return KADV.isFinishAniop(SYSMENU_BASE_NO[1])



def sysmenuCanselDraw():
    KADV.drawAniop(SYSMENU_CANSEL_NO[1], sysmenuPos)



def sysmenuSaveDraw():
    KADV.drawAniop(SYSMENU_SAVE_NO[1], sysmenuPos)



def sysmenuLoadDraw():
    KADV.drawAniop(SYSMENU_LOAD_NO[1], sysmenuPos)



def sysmenuSkipDraw():
    KADV.drawAniop(SYSMENU_SKIP_NO[1], sysmenuPos)



def sysmenuConfigDraw():
    KADV.drawAniop(SYSMENU_CONFIG_NO[1], sysmenuPos)



def sysmenuTitleDraw():
    KADV.drawAniop(SYSMENU_TITLE_NO[1], sysmenuPos)



def drawCalendar():
    if (KADV.__exp__.has_key('day') and (KADV.__exp__['day'] != None)):
        KADV.drawAni(KADV.ANI_0, 3, KADV.__exp__['day'])



def drawCounter():
    if (KADV.__exp__.has_key('\x88\xda\x93\xae\x8ec\x82\xe8') and ((KADV.__exp__['\x88\xda\x93\xae\x8ec\x82\xe8'] != None) and (KADV.__exp__['\x88\xda\x93\xae\x8ec\x82\xe8'] > 0))):
        KADV.drawAni(KADV.ANI_2, 0, (50 - KADV.__exp__['\x88\xda\x93\xae\x8ec\x82\xe8']))


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
