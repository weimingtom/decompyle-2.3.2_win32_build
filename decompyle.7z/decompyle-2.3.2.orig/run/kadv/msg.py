# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))
import string
import StringIO
import ozipRead
f = ozipRead.ozipRead('kadv/data/msg.bin')
buf = ''
for i in range(f.getArciveNum()):
    buf += f.read(i)

f.close()
f = StringIO.StringIO(buf)
lines = []
for str in f.readlines():
    str = string.split(str, '#')[0]
    str = string.strip(str)
    if (len(str) == 0):
        continue
    str = string.replace(str, '\\n', '\n')
    lines.append(str)

f.close()
KADV.debugOut(('total %d page' % len(lines)))
labels = {}
count = 0
for l in lines:
    str = string.split(l, '#')[0]
    str = string.split(str, ',')[0]
    str = string.strip(str)
    if (len(str) > 0):
        if (str[0] == ':'):
            labels[str[1:]] = count
    count += 1

ELEMENT_SCENE = 0
ELEMENT_EFFECT = 1
ELEMENT_VOICE = 2
ELEMENT_NAME = 3
ELEMENT_TEXT = 4

def searchPage(id, page):
    if (not labels.has_key(id)):
        KADV.debugOut(('\xd2\xaf\xbe\xb0\xbc\xde\xd7\xcd\xde\xd9 %s \x82\xaa\x8c\xa9\x82\xc2\x82\xa9\x82\xe8\x82\xdc\x82\xb9\x82\xf1\x82\xc5\x82\xb5\x82\xbd.' % id))
        return None
    lineBase = (labels[id] + 1)
    if ((lineBase + page) >= len(lines)):
        KADV.debugOut(('%s \x82\xcc\xcd\xdf\xb0\xbc\xde %d \x82\xcd\x81A\x8d\xc5\x91\xe5\x90\x94 %d \x82\xf0\x92\xb4\x82\xa6\x82\xc4\x82\xa2\x82\xdc\x82\xb7.' % (id,
         page,
         len(lines))))
        return None
    for i in xrange((page + 1)):
        if (lines[(lineBase + i)][0] == ':'):
            KADV.debugOut(('%s \x82\xcc\xcd\xdf\xb0\xbc\xde %d \x82\xaa\x8c\xa9\x82\xc2\x82\xa9\x82\xe8\x82\xdc\x82\xb9\x82\xf1\x82\xc5\x82\xb5\x82\xbd.' % (id,
             page)))
            return None

    return (lineBase + i)



def getLineData(lineNo):
    if (lineNo == None):
        return None
    elements = string.split(lines[lineNo], ',')
    return map(string.strip, elements)



def getPageData(id, page):
    return getLineData(searchPage(id, page))



def getPageColor(id, page):
    import name
    pageData = getPageData(id, page)
    c = pageData[ELEMENT_TEXT][:2]
    if ((c == '\x81u') or ((c == '\x81i') or (c == '\x81w'))):
        return name.getNameColor(pageData[ELEMENT_NAME])
    else:
        return -1



def getProhibityStr(str):
    import text
    str = KADV.prohibition(str, text.LINE_CHAR_COUNT)
    return str



def load(id, page):
    pageData = getPageData(id, page)
    if (pageData == None):
        return (1,
         0)
    if (pageData[ELEMENT_SCENE] != KADV.__exp__['scene_id']):
        if (len(KADV.__exp__['history']) > 0):
            import vram
            import keyWait
            if (KADV.__exp__['scene_id'] != None):
                draw(KADV.__exp__['history'][-1][0], KADV.__exp__['history'][-1][1])
                keyWait.sysCheck()
                KADV.moveImg(vram.TMP_PAGE, (0,
                 0,
                 800,
                 600), 0, (0,
                 0))
            else:
                KADV.clear(vram.TMP_PAGE, -16777216, (0,
                 0,
                 800,
                 600))
        else:
            import vram
            KADV.clear(vram.TMP_PAGE, -16777216, (0,
             0,
             800,
             600))
    import scene
    import text
    if (pageData[ELEMENT_EFFECT] == 'dream'):
        needFade = scene.load(pageData[ELEMENT_SCENE], 1)
    else:
        needFade = scene.load(pageData[ELEMENT_SCENE])
    text.load(getProhibityStr(pageData[ELEMENT_TEXT]))
    KADV.__exp__['scene_id'] = pageData[ELEMENT_SCENE]
    return (0,
     needFade)



def draw(id, page, passTime = 2147483647):
    import scene
    import ani
    import text
    import name
    pageData = getPageData(id, page)
    textColor = getPageColor(id, page)
    scene.draw()
    ani.msgwinDraw()
    import cfgvalue
    speed = cfgvalue.getMsgSpeed()
    if cfgvalue.isVoiceSync():
        if (pageData[ELEMENT_VOICE] != '0'):
            waitTime = KADV.getVoiceTime(KADV.SOUND)
        else:
            waitTime = (((len(pageData[ELEMENT_TEXT]) * cfgvalue.DEF_MSG_SPEED) * 3) / 2)
    else:
        waitTime = (len(pageData[ELEMENT_TEXT]) * speed)
    text.draw(textColor, getProhibityStr(pageData[ELEMENT_TEXT]), passTime, waitTime)
    return (passTime > waitTime)



def msgWait():
    import keyWait
    import ani
    import vram
    ani.initNextCursor()
    startTime = KADV.getTime()
    while 1:
        KADV.updateInput(KADV.INPUT)
        if (draw(KADV.__exp__['msg_id'], KADV.__exp__['msg_page']) == 0):
            startTime = KADV.getTime()
        if KADV.isPlayVoice(KADV.SOUND):
            startTime = KADV.getTime()
        ani.nameDraw(KADV.__exp__['msg_id'], KADV.__exp__['msg_page'])
        ret = keyWait.sysCheck()
        ani.drawNextCursor()
        vram.swap(KADV)
        if (ret == 1):
            continue
        if keyWait.isMsgNext((KADV.getTime() - startTime)):
            break



KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
