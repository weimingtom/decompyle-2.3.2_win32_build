# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s(%d)' % (__file__,
 KADV.getTime())))
import string
perfectSkip = 0

def draw(isFix):
    global perfectSkip
    import ani
    import scene
    import keyWait
    import vram
    ani.sysmenuInit(TITLE, isFix)
    while 1:
        vram.swap(KADV)
        KADV.updateInput(KADV.INPUT)
        scene.draw()
        isFinish = ani.sysmenuDraw()
        if keyWait.isCansel():
            scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
            KADV.updateInput(KADV.INPUT)
            return 
        if isFinish:
            import key
            import ani
            pos = key.getPos(KADV)
            k = key.get(KADV)
            b = ani.getSysmenuCanselBounds()
            if ((b[0] < pos[0]) and (pos[0] < (b[0] + b[2]))):
                if ((b[1] < pos[1]) and (pos[1] < (b[1] + b[3]))):
                    ani.sysmenuCanselDraw()
                    if key.isTrg(KADV):
                        scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
                        break
            if (not KADV.__exp__['is_replay']):
                b = ani.getSysmenuSaveBounds()
                if ((b[0] < pos[0]) and (pos[0] < (b[0] + b[2]))):
                    if ((b[1] < pos[1]) and (pos[1] < (b[1] + b[3]))):
                        ani.sysmenuSaveDraw()
                        if key.isTrg(KADV):
                            scene.playSE('\x8c\x88\x92\xe8')
                            import save
                            sid = KADV.__exp__['scene_id']
                            save.start(KADV, None)
                            ani.init()
                            if (sid != None):
                                scene.load(sid)
                            KADV.__exp__['scene_id'] = sid
                            break
                b = ani.getSysmenuLoadBounds()
                if ((b[0] < pos[0]) and (pos[0] < (b[0] + b[2]))):
                    if ((b[1] < pos[1]) and (pos[1] < (b[1] + b[3]))):
                        ani.sysmenuLoadDraw()
                        if key.isTrg(KADV):
                            scene.playSE('\x8c\x88\x92\xe8')
                            import load
                            sid = KADV.__exp__['scene_id']
                            isBreak = load.start(KADV, None)
                            if (isBreak == 0):
                                ani.init()
                                if (sid != None):
                                    scene.load(sid)
                                KADV.__exp__['scene_id'] = sid
                                break
                            else:
                                raise 'kadvBreakException', 'kadv'
                b = ani.getSysmenuSkipBounds()
                if ((b[0] < pos[0]) and (pos[0] < (b[0] + b[2]))):
                    if ((b[1] < pos[1]) and (pos[1] < (b[1] + b[3]))):
                        ani.sysmenuSkipDraw()
                        if key.isTrg(KADV):
                            scene.playSE('\x8c\x88\x92\xe8')
                            perfectSkip = 1
                            scene.draw()
                            vram.swap(KADV)
                            raise 'kadvBreakException', 'kadv'
            b = ani.getSysmenuConfigBounds()
            if ((b[0] < pos[0]) and (pos[0] < (b[0] + b[2]))):
                if ((b[1] < pos[1]) and (pos[1] < (b[1] + b[3]))):
                    ani.sysmenuConfigDraw()
                    if key.isTrg(KADV):
                        scene.playSE('\x8c\x88\x92\xe8')
                        import config
                        config.start(KADV, None)
                        ani.init()
                        break
            b = ani.getSysmenuTitleBounds()
            if ((b[0] < pos[0]) and (pos[0] < (b[0] + b[2]))):
                if ((b[1] < pos[1]) and (pos[1] < (b[1] + b[3]))):
                    ani.sysmenuTitleDraw()
                    if key.isTrg(KADV):
                        scene.playSE('\x8c\x88\x92\xe8')
                        if KADV.__exp__['is_replay']:
                            ret = KADV.yesnoBox('\x8am\x94F', '\x83\x8a\x83v\x83\x8c\x83C\x82\xf0\x8fI\x97\xb9\x82\xb5\x82\xdc\x82\xb7\x82\xa9\x81H')
                        else:
                            ret = KADV.yesnoBox('\x8am\x94F', '\x83^\x83C\x83g\x83\x8b\x82\xd6\x96\xdf\x82\xe8\x82\xdc\x82\xb7\x82\xa9\x81H')
                        if ret:
                            import scene
                            scene.stopSound()
                            raise 'kadvBreakException', 'title'
                        else:
                            KADV.updateInput(KADV.INPUT)
                            return 
                        break
            if k[key.K_1][1]:
                scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
                KADV.updateInput(KADV.INPUT)
                return 
            if (not KADV.__exp__['is_replay']):
                if k[key.K_2][1]:
                    scene.playSE('\x8c\x88\x92\xe8')
                    import save
                    sid = KADV.__exp__['scene_id']
                    save.start(KADV, None)
                    if (sid != None):
                        scene.load(sid)
                    KADV.__exp__['scene_id'] = sid
                    ani.init()
                    break
                if k[key.K_3][1]:
                    scene.playSE('\x8c\x88\x92\xe8')
                    import load
                    sid = KADV.__exp__['scene_id']
                    isBreak = load.start(KADV, None)
                    if (isBreak == 0):
                        if (sid != None):
                            scene.load(sid)
                        KADV.__exp__['scene_id'] = sid
                        ani.init()
                        break
                    else:
                        raise 'kadvBreakException', 'kadv'
                if k[key.K_4][1]:
                    scene.playSE('\x8c\x88\x92\xe8')
                    perfectSkip = 1
                    scene.draw()
                    vram.swap(KADV)
                    raise 'kadvBreakException', 'kadv'
                if k[key.K_5][1]:
                    scene.playSE('\x8c\x88\x92\xe8')
                    import config
                    config.start(KADV, None)
                    ani.init()
                    break
                if k[key.K_6][1]:
                    scene.playSE('\x8c\x88\x92\xe8')
                    ret = KADV.yesnoBox('\x8am\x94F', '\x83^\x83C\x83g\x83\x8b\x82\xd6\x96\xdf\x82\xe8\x82\xdc\x82\xb7\x82\xa9\x81H')
                    if ret:
                        raise 'kadvBreakException', 'title'
                    else:
                        KADV.updateInput(KADV.INPUT)
                        return 
                    break
            else:
                if k[key.K_2][1]:
                    scene.playSE('\x8c\x88\x92\xe8')
                    import config
                    config.start(KADV, None)
                    ani.init()
                    break
                if k[key.K_3][1]:
                    scene.playSE('\x8c\x88\x92\xe8')
                    ret = KADV.yesnoBox('\x8am\x94F', '\x83\x8a\x83v\x83\x8c\x83C\x82\xf0\x8fI\x97\xb9\x82\xb5\x82\xdc\x82\xb7\x82\xa9\x81H')
                    if ret:
                        raise 'kadvBreakException', 'title'
                    else:
                        KADV.updateInput(KADV.INPUT)
                        return 
                    break

    KADV.updateInput(KADV.INPUT)
    import effect
    effect.fadeInWait(KADV)


KADV.debugOut(('end:%s(%d)' % (__file__,
 KADV.getTime())))

# local variables:
# tab-width: 4
