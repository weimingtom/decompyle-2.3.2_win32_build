# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))
effects = ['ef1',
 'ef2',
 'ef3',
 'ef4',
 'ef5']
masks = []
for e in effects:
    f = open(('kadv/data/effect/%s.bmp' % e), 'rb')
    masks.append(f.read()[1080:])
    f.close()


def run(fname):
    import keyWait
    import vram
    import scene
    import ani
    import cfgvalue
    if (keyWait.isSkip() or cfgvalue.isEffectCut()):
        return 
    buf = KADV.clear(vram.TMP_PAGE, -16777216, (0,
     0,
     800,
     600))
    buf = KADV.getImg(vram.TMP_PAGE, (0,
     0,
     800,
     600))
    for e_num in range(len(effects)):
        if (effects[e_num] == fname):
            break

    startTime = KADV.getTime()
    effectTime = 1000
    KADV.updateInput(KADV.INPUT)
    while 1:
        if (keyWait.isSkip() or cfgvalue.isEffectCut()):
            break
        passTime = (KADV.getTime() - startTime)
        if (passTime >= effectTime):
            break
        KADV.pixelEffect(vram.TMP_PAGE, (0,
         0,
         800,
         600), buf, masks[e_num], passTime, effectTime, 1)
        scene.draw()
        KADV.drawImg(vram.TMP_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        keyWait.sysCheckSwap()

    scene.draw()
    keyWait.sysCheckSwap()


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
