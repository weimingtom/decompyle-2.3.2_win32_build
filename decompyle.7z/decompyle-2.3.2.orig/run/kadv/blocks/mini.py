# emacs-mode: -*- python-*-
KADV.debugOut(('%s: %dms' % (__file__,
 KADV.getTime())))
import kadv

def dayInit():
    kadv.setParam('day', 9)
    kadv.setParam('chapter', '\x82W\x8c\x8e\x82P\x82P\x93\xfa')



def init():
    kadv.setParam('\x88\xda\x93\xae\x8ec\x82\xe8', 50)
    kadv.setParam('\x97E\x91\xa2', 0)
    kadv.setParam('\x8a\xcf\x8c\x8e', 0)
    kadv.setParam('\x97[\x95P', 0)
    kadv.setParam('\x83T\x83L', 0)
    kadv.setParam('\x8b\x8f\x8a\xd4', 0)
    kadv.setParam('\x98L\x89\xba', 0)
    kadv.setParam('\x91\xe4\x8f\x8a', 0)
    kadv.setParam('\x93G\x88\xca\x92u', '\x91\xe4\x8f\x8a')
    kadv.setParam('\x93G\x98L\x89\xba\x8e\x9f', '\x8a\xcf\x8c\x8e')
    kadv.setParam('\x93G\x91\xd2\x8b@', 0)
    kadv.setParam('\x89\xb4\x88\xca\x92u', '\x98L\x89\xba')
    kadv.setParam('\x89\xb4\x91\xd2\x8b@', 0)
    kadv.setParam('\x94j\x89\xf3Lv', 0)
    return 'resetStay6'



def moveEnemy():
    if (kadv.getParam('\x93G\x88\xca\x92u') == kadv.getParam('\x89\xb4\x88\xca\x92u')):
        kadv.setParam('\x93G\x91\xd2\x8b@', 0)
        return 
    nowPos = kadv.getParam('\x93G\x88\xca\x92u')
    if (nowPos == '\x91\xe4\x8f\x8a'):
        if ((kadv.getParam('\x89\xb4\x88\xca\x92u') == '\x8b\x8f\x8a\xd4') and ((kadv.getParam('\x93G\x91\xd2\x8b@') == 0) and (kadv.getParam('\x89\xb4\x91\xd2\x8b@') == 0))):
            kadv.setParam('\x93G\x91\xd2\x8b@', 1)
        else:
            kadv.setParam('\x93G\x88\xca\x92u', '\x8b\x8f\x8a\xd4')
            kadv.setParam('\x93G\x91\xd2\x8b@', 0)
    elif (nowPos == '\x8b\x8f\x8a\xd4'):
        if ((kadv.getParam('\x89\xb4\x88\xca\x92u') == '\x98L\x89\xba') and ((kadv.getParam('\x93G\x91\xd2\x8b@') == 0) and (kadv.getParam('\x89\xb4\x91\xd2\x8b@') == 0))):
            kadv.setParam('\x93G\x91\xd2\x8b@', 1)
        else:
            kadv.setParam('\x93G\x88\xca\x92u', '\x98L\x89\xba')
            kadv.setParam('\x93G\x91\xd2\x8b@', 0)
    elif (nowPos == '\x97[\x95P'):
        if ((kadv.getParam('\x89\xb4\x88\xca\x92u') == '\x98L\x89\xba') and ((kadv.getParam('\x93G\x91\xd2\x8b@') == 0) and (kadv.getParam('\x89\xb4\x91\xd2\x8b@') == 0))):
            kadv.setParam('\x93G\x91\xd2\x8b@', 1)
        else:
            kadv.setParam('\x93G\x88\xca\x92u', '\x98L\x89\xba')
            kadv.setParam('\x93G\x91\xd2\x8b@', 0)
    elif (nowPos == '\x97E\x91\xa2'):
        if ((kadv.getParam('\x89\xb4\x88\xca\x92u') == '\x98L\x89\xba') and ((kadv.getParam('\x93G\x91\xd2\x8b@') == 0) and (kadv.getParam('\x89\xb4\x91\xd2\x8b@') == 0))):
            kadv.setParam('\x93G\x91\xd2\x8b@', 1)
        else:
            kadv.setParam('\x93G\x88\xca\x92u', '\x98L\x89\xba')
            kadv.setParam('\x93G\x91\xd2\x8b@', 0)
    elif (nowPos == '\x8b\x8f\x8a\xd4'):
        if ((kadv.getParam('\x89\xb4\x88\xca\x92u') == '\x98L\x89\xba') and ((kadv.getParam('\x93G\x91\xd2\x8b@') == 0) and (kadv.getParam('\x89\xb4\x91\xd2\x8b@') == 0))):
            kadv.setParam('\x93G\x91\xd2\x8b@', 1)
        else:
            kadv.setParam('\x93G\x88\xca\x92u', '\x98L\x89\xba')
            kadv.setParam('\x93G\x91\xd2\x8b@', 0)
    elif (nowPos == '\x97[\x95P'):
        kadv.setParam('\x93G\x98L\x89\xba\x8e\x9f', '\x8a\xcf\x8c\x8e')
        if ((kadv.getParam('\x89\xb4\x88\xca\x92u') == '\x98L\x89\xba') and ((kadv.getParam('\x93G\x91\xd2\x8b@') == 0) and (kadv.getParam('\x89\xb4\x91\xd2\x8b@') == 0))):
            kadv.setParam('\x93G\x91\xd2\x8b@', 1)
        else:
            kadv.setParam('\x93G\x88\xca\x92u', '\x98L\x89\xba')
            kadv.setParam('\x93G\x91\xd2\x8b@', 0)
    elif (nowPos == '\x8a\xcf\x8c\x8e'):
        kadv.setParam('\x93G\x98L\x89\xba\x8e\x9f', '\x97[\x95P')
        if ((kadv.getParam('\x89\xb4\x88\xca\x92u') == '\x98L\x89\xba') and ((kadv.getParam('\x93G\x91\xd2\x8b@') == 0) and (kadv.getParam('\x89\xb4\x91\xd2\x8b@') == 0))):
            kadv.setParam('\x93G\x91\xd2\x8b@', 1)
        else:
            kadv.setParam('\x93G\x88\xca\x92u', '\x98L\x89\xba')
            kadv.setParam('\x93G\x91\xd2\x8b@', 0)
    elif (nowPos == '\x98L\x89\xba'):
        if ((kadv.getParam('\x93G\x98L\x89\xba\x8e\x9f') == '\x8a\xcf\x8c\x8e') and ((kadv.getParam('\x89\xb4\x88\xca\x92u') == '\x8a\xcf\x8c\x8e') and (kadv.getParam('\x89\xb4\x91\xd2\x8b@') == 0))):
            if ((KADV.getTime() % 2) == 0):
                kadv.setParam('\x93G\x88\xca\x92u', '\x97E\x91\xa2')
            else:
                kadv.setParam('\x93G\x88\xca\x92u', '\x83T\x83L')
        elif ((kadv.getParam('\x89\xb4\x88\xca\x92u') == '\x97[\x95P') or (kadv.getParam('\x89\xb4\x88\xca\x92u') == '\x91\xe4\x8f\x8a')):
            kadv.setParam('\x93G\x88\xca\x92u', '\x8b\x8f\x8a\xd4')
        else:
            kadv.setParam('\x93G\x88\xca\x92u', kadv.getParam('\x93G\x98L\x89\xba\x8e\x9f'))
            kadv.setParam('\x93G\x91\xd2\x8b@', 0)



def repair():
    repairAble = []
    if kadv.getParam('\x8a\xcf\x8c\x8e'):
        kadv.setParam('\x8a\xcf\x8c\x8e', 0)
    elif kadv.getParam('\x97[\x95P'):
        kadv.setParam('\x97[\x95P', 0)
    elif kadv.getParam('\x83T\x83L'):
        kadv.setParam('\x83T\x83L', 0)
    elif kadv.getParam('\x97E\x91\xa2'):
        kadv.setParam('\x97E\x91\xa2', 0)
    elif kadv.getParam('\x98L\x89\xba'):
        kadv.setParam('\x98L\x89\xba', 0)
    elif kadv.getParam('\x8b\x8f\x8a\xd4'):
        kadv.setParam('\x8b\x8f\x8a\xd4', 0)
    elif kadv.getParam('\x91\xe4\x8f\x8a'):
        kadv.setParam('\x91\xe4\x8f\x8a', 0)
    elif (kadv.getParam('\x94j\x89\xf3Lv') > 0):
        kadv.addParam('\x94j\x89\xf3Lv', -1)
        kadv.setParam('\x8a\xcf\x8c\x8e', 0)
        kadv.setParam('\x97[\x95P', 1)
        kadv.setParam('\x83T\x83L', 1)
        kadv.setParam('\x97E\x91\xa2', 1)
        kadv.setParam('\x98L\x89\xba', 1)
        kadv.setParam('\x8b\x8f\x8a\xd4', 1)
        kadv.setParam('\x91\xe4\x8f\x8a', 1)
    room = kadv.getParam('\x89\xb4\x88\xca\x92u')
    if (room == '\x97E\x91\xa2'):
        val = ['\x8a\xcf\x8c\x8e',
         '\x97[\x95P',
         '\x83T\x83L',
         '\x8b\x8f\x8a\xd4',
         '\x91\xe4\x8f\x8a']
    elif (room == '\x8a\xcf\x8c\x8e'):
        val = ['\x97E\x91\xa2',
         '\x83T\x83L',
         '\x8b\x8f\x8a\xd4',
         '\x91\xe4\x8f\x8a']
    elif (room == '\x97[\x95P'):
        val = ['\x97E\x91\xa2',
         '\x83T\x83L',
         '\x8b\x8f\x8a\xd4',
         '\x91\xe4\x8f\x8a']
    elif (room == '\x83T\x83L'):
        val = ['\x97E\x91\xa2',
         '\x8a\xcf\x8c\x8e',
         '\x97[\x95P',
         '\x8b\x8f\x8a\xd4',
         '\x91\xe4\x8f\x8a']
    elif (room == '\x8b\x8f\x8a\xd4'):
        val = ['\x97E\x91\xa2',
         '\x8a\xcf\x8c\x8e',
         '\x97[\x95P',
         '\x83T\x83L']
    elif (room == '\x98L\x89\xba'):
        val = ['\x91\xe4\x8f\x8a']
    else:
        val = ['\x97E\x91\xa2',
         '\x8a\xcf\x8c\x8e',
         '\x97[\x95P',
         '\x83T\x83L',
         '\x98L\x89\xba']
    kadv.setParam('\x93G\x88\xca\x92u', val[(KADV.getTime() % len(val))])



def check():
    if (kadv.getParam('\x8a\xcf\x8c\x8e') == 0):
        return 0
    if (kadv.getParam('\x97[\x95P') == 0):
        return 0
    if (kadv.getParam('\x83T\x83L') == 0):
        return 0
    if (kadv.getParam('\x97E\x91\xa2') == 0):
        return 0
    if (kadv.getParam('\x98L\x89\xba') == 0):
        return 0
    if (kadv.getParam('\x8b\x8f\x8a\xd4') == 0):
        return 0
    if (kadv.getParam('\x91\xe4\x8f\x8a') == 0):
        return 0
    if (kadv.getParam('\x94j\x89\xf3Lv') < 2):
        kadv.addParam('\x94j\x89\xf3Lv', 1)
        kadv.setParam('\x8a\xcf\x8c\x8e', 0)
        kadv.setParam('\x97[\x95P', 0)
        kadv.setParam('\x83T\x83L', 0)
        kadv.setParam('\x97E\x91\xa2', 0)
        kadv.setParam('\x98L\x89\xba', 0)
        kadv.setParam('\x8b\x8f\x8a\xd4', 0)
        kadv.setParam('\x91\xe4\x8f\x8a', 0)
        return 1
    else:
        kadv.setParam('\x88\xda\x93\xae\x8ec\x82\xe8', 0)
        return 2



def stay1():
    kadv.setParam('\x89\xb4\x91\xd2\x8b@', 1)
    return 'checkEnemy1'



def checkEnemy1():
    kadv.addParam('\x88\xda\x93\xae\x8ec\x82\xe8', -1)
    if (kadv.getParam('\x88\xda\x93\xae\x8ec\x82\xe8') <= 0):
        return ('mini%s\x8fI\x97\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    kadv.setParam('\x89\xb4\x88\xca\x92u', '\x97E\x91\xa2')
    moveEnemy()
    if (kadv.getParam('\x93G\x88\xca\x92u') == kadv.getParam('\x89\xb4\x88\xca\x92u')):
        return ('mini%s\x8e\xb8\x94s' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if kadv.getParam(kadv.getParam('\x89\xb4\x88\xca\x92u')):
        return ('mini%s\x94j\x89\xf3\x8d\xcf\x82\xdd' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def openProtect1():
    kadv.setParam(kadv.getParam('\x89\xb4\x88\xca\x92u'), 1)
    c = check()
    if (c == 0):
        return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if (c == 2):
        return 'mini_clear'



def lvupJump1():
    return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def alreadyJump1():
    return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def repair1():
    repair()
    return ('mini\x90^%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def sndCheck1():
    if (kadv.getParam('\x93G\x88\xca\x92u') == '\x98L\x89\xba'):
        return ('mini%s\x82\xcc\x98L\x89\xba\x95\xa8\x89\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if ((kadv.getParam('\x93G\x88\xca\x92u') == '\x8a\xcf\x8c\x8e') or (kadv.getParam('\x93G\x88\xca\x92u') == '\x97[\x95P')):
        return ('mini%s\x82\xcc\x82Q\x8aK\x95\xa8\x89\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def resetStay1():
    kadv.setParam('\x89\xb4\x91\xd2\x8b@', 0)



def stay2():
    kadv.setParam('\x89\xb4\x91\xd2\x8b@', 1)
    return 'checkEnemy2'



def checkEnemy2():
    kadv.addParam('\x88\xda\x93\xae\x8ec\x82\xe8', -1)
    if (kadv.getParam('\x88\xda\x93\xae\x8ec\x82\xe8') <= 0):
        return ('mini%s\x8fI\x97\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    kadv.setParam('\x89\xb4\x88\xca\x92u', '\x8a\xcf\x8c\x8e')
    moveEnemy()
    if (kadv.getParam('\x93G\x88\xca\x92u') == kadv.getParam('\x89\xb4\x88\xca\x92u')):
        return ('mini%s\x8e\xb8\x94s' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if kadv.getParam(kadv.getParam('\x89\xb4\x88\xca\x92u')):
        return ('mini%s\x94j\x89\xf3\x8d\xcf\x82\xdd' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def openProtect2():
    kadv.setParam(kadv.getParam('\x89\xb4\x88\xca\x92u'), 1)
    c = check()
    if (c == 0):
        return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if (c == 2):
        return 'mini_clear'



def lvupJump2():
    return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def alreadyJump2():
    return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def repair2():
    repair()
    return ('mini\x90^%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def sndCheck2():
    if (kadv.getParam('\x93G\x88\xca\x92u') == '\x98L\x89\xba'):
        return ('mini%s\x82\xcc\x98L\x89\xba\x95\xa8\x89\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def resetStay2():
    kadv.setParam('\x89\xb4\x91\xd2\x8b@', 0)



def stay3():
    kadv.setParam('\x89\xb4\x91\xd2\x8b@', 1)
    return 'checkEnemy3'



def checkEnemy3():
    kadv.addParam('\x88\xda\x93\xae\x8ec\x82\xe8', -1)
    if (kadv.getParam('\x88\xda\x93\xae\x8ec\x82\xe8') <= 0):
        return ('mini%s\x8fI\x97\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    kadv.setParam('\x89\xb4\x88\xca\x92u', '\x97[\x95P')
    moveEnemy()
    if (kadv.getParam('\x93G\x88\xca\x92u') == kadv.getParam('\x89\xb4\x88\xca\x92u')):
        return ('mini%s\x8e\xb8\x94s' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if kadv.getParam(kadv.getParam('\x89\xb4\x88\xca\x92u')):
        return ('mini%s\x94j\x89\xf3\x8d\xcf\x82\xdd' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def openProtect3():
    kadv.setParam(kadv.getParam('\x89\xb4\x88\xca\x92u'), 1)
    c = check()
    if (c == 0):
        return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if (c == 2):
        return 'mini_clear'



def lvupJump3():
    return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def alreadyJump3():
    return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def repair3():
    repair()
    return ('mini\x90^%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def sndCheck3():
    if (kadv.getParam('\x93G\x88\xca\x92u') == '\x98L\x89\xba'):
        return ('mini%s\x82\xcc\x98L\x89\xba\x95\xa8\x89\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def resetStay3():
    kadv.setParam('\x89\xb4\x91\xd2\x8b@', 0)



def stay4():
    kadv.setParam('\x89\xb4\x91\xd2\x8b@', 1)
    return 'checkEnemy4'



def checkEnemy4():
    kadv.addParam('\x88\xda\x93\xae\x8ec\x82\xe8', -1)
    if (kadv.getParam('\x88\xda\x93\xae\x8ec\x82\xe8') <= 0):
        return ('mini%s\x8fI\x97\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    kadv.setParam('\x89\xb4\x88\xca\x92u', '\x83T\x83L')
    moveEnemy()
    if (kadv.getParam('\x93G\x88\xca\x92u') == kadv.getParam('\x89\xb4\x88\xca\x92u')):
        return ('mini%s\x8e\xb8\x94s' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if kadv.getParam(kadv.getParam('\x89\xb4\x88\xca\x92u')):
        return ('mini%s\x94j\x89\xf3\x8d\xcf\x82\xdd' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def openProtect4():
    kadv.setParam(kadv.getParam('\x89\xb4\x88\xca\x92u'), 1)
    c = check()
    if (c == 0):
        return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if (c == 2):
        return 'mini_clear'



def lvupJump4():
    return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def alreadyJump4():
    return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def repair4():
    repair()
    return ('mini\x90^%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def resetStay4():
    kadv.setParam('\x89\xb4\x91\xd2\x8b@', 0)



def stay5():
    kadv.setParam('\x89\xb4\x91\xd2\x8b@', 1)
    return 'checkEnemy5'



def checkEnemy5():
    kadv.addParam('\x88\xda\x93\xae\x8ec\x82\xe8', -1)
    if (kadv.getParam('\x88\xda\x93\xae\x8ec\x82\xe8') <= 0):
        return ('mini%s\x8fI\x97\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    kadv.setParam('\x89\xb4\x88\xca\x92u', '\x8b\x8f\x8a\xd4')
    moveEnemy()
    if (kadv.getParam('\x93G\x88\xca\x92u') == kadv.getParam('\x89\xb4\x88\xca\x92u')):
        return ('mini%s\x8e\xb8\x94s' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if kadv.getParam(kadv.getParam('\x89\xb4\x88\xca\x92u')):
        return ('mini%s\x94j\x89\xf3\x8d\xcf\x82\xdd' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def openProtect5():
    kadv.setParam(kadv.getParam('\x89\xb4\x88\xca\x92u'), 1)
    c = check()
    if (c == 0):
        return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if (c == 2):
        return 'mini_clear'



def lvupJump5():
    return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def alreadyJump5():
    return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def repair5():
    repair()
    return ('mini\x90^%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def sndCheck5():
    if (kadv.getParam('\x93G\x88\xca\x92u') == '\x91\xe4\x8f\x8a'):
        return ('mini%s\x82\xc5\x91\xe4\x8f\x8a\x95\xa8\x89\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if (kadv.getParam('\x93G\x88\xca\x92u') == '\x98L\x89\xba'):
        return ('mini%s\x82\xc5\x98L\x89\xba\x95\xa8\x89\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if ((kadv.getParam('\x93G\x88\xca\x92u') == '\x8a\xcf\x8c\x8e') or (kadv.getParam('\x93G\x88\xca\x92u') == '\x97[\x95P')):
        return ('mini%s\x82\xcc\x82Q\x8aK\x95\xa8\x89\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def resetStay5():
    kadv.setParam('\x89\xb4\x91\xd2\x8b@', 0)



def stay6():
    kadv.setParam('\x89\xb4\x91\xd2\x8b@', 1)
    return 'checkEnemy6'



def checkEnemy6():
    kadv.addParam('\x88\xda\x93\xae\x8ec\x82\xe8', -1)
    if (kadv.getParam('\x88\xda\x93\xae\x8ec\x82\xe8') <= 0):
        return ('mini%s\x8fI\x97\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    kadv.setParam('\x89\xb4\x88\xca\x92u', '\x98L\x89\xba')
    moveEnemy()
    if (kadv.getParam('\x93G\x88\xca\x92u') == kadv.getParam('\x89\xb4\x88\xca\x92u')):
        return ('mini%s\x8e\xb8\x94s' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if kadv.getParam(kadv.getParam('\x89\xb4\x88\xca\x92u')):
        return ('mini%s\x94j\x89\xf3\x8d\xcf\x82\xdd' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def openProtect6():
    kadv.setParam(kadv.getParam('\x89\xb4\x88\xca\x92u'), 1)
    c = check()
    if (c == 0):
        return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if (c == 2):
        return 'mini_clear'



def lvupJump6():
    return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def alreadyJump6():
    return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def repair6():
    repair()
    return ('mini\x90^%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def sndCheck6():
    if (kadv.getParam('\x93G\x88\xca\x92u') == '\x97E\x91\xa2'):
        return ('mini%s\x82\xc5\x97E\x91\xa2\x95\xa8\x89\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if (kadv.getParam('\x93G\x88\xca\x92u') == '\x8a\xcf\x8c\x8e'):
        return ('mini%s\x82\xc5\x8a\xcf\x8c\x8e\x95\xa8\x89\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if (kadv.getParam('\x93G\x88\xca\x92u') == '\x97[\x95P'):
        return ('mini%s\x82\xc5\x97[\x95P\x95\xa8\x89\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if (kadv.getParam('\x93G\x88\xca\x92u') == '\x8b\x8f\x8a\xd4'):
        return ('mini%s\x82\xc5\x8b\x8f\x8a\xd4\x95\xa8\x89\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def resetStay6():
    kadv.setParam('\x89\xb4\x91\xd2\x8b@', 0)



def stay7():
    kadv.setParam('\x89\xb4\x91\xd2\x8b@', 1)
    return 'checkEnemy7'



def checkEnemy7():
    kadv.addParam('\x88\xda\x93\xae\x8ec\x82\xe8', -1)
    if (kadv.getParam('\x88\xda\x93\xae\x8ec\x82\xe8') <= 0):
        return ('mini%s\x8fI\x97\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    kadv.setParam('\x89\xb4\x88\xca\x92u', '\x91\xe4\x8f\x8a')
    moveEnemy()
    if (kadv.getParam('\x93G\x88\xca\x92u') == kadv.getParam('\x89\xb4\x88\xca\x92u')):
        return ('mini%s\x8e\xb8\x94s' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if kadv.getParam(kadv.getParam('\x89\xb4\x88\xca\x92u')):
        return ('mini%s\x94j\x89\xf3\x8d\xcf\x82\xdd' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def openProtect7():
    kadv.setParam(kadv.getParam('\x89\xb4\x88\xca\x92u'), 1)
    c = check()
    if (c == 0):
        return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if (c == 2):
        return 'mini_clear'



def lvupJump7():
    return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def alreadyJump7():
    return ('mini%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def repair7():
    repair()
    return ('mini\x90^%s\x91I\x91\xf0' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def sndCheck7():
    if (kadv.getParam('\x93G\x88\xca\x92u') == '\x8b\x8f\x8a\xd4'):
        return ('mini%s\x82\xc5\x8b\x8f\x8a\xd4\x95\xa8\x89\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))
    if ((kadv.getParam('\x93G\x88\xca\x92u') == '\x8a\xcf\x8c\x8e') or (kadv.getParam('\x93G\x88\xca\x92u') == '\x97[\x95P')):
        return ('mini%s\x82\xcc\x82Q\x8aK\x95\xa8\x89\xb9' % kadv.getParam('\x89\xb4\x88\xca\x92u'))



def resetStay7():
    kadv.setParam('\x89\xb4\x91\xd2\x8b@', 0)



def setClear():
    kadv.addParam('\x97[\x95P\x83N\x83\x8a\x83A\x83t\x83\x89\x83O', 1)



def run():
    kadv.FUNC(None, 'dayInit')
    kadv.FUNC('dayInit', 'dayInit_after__mini', dayInit)
    kadv.MSG('dayInit_after__mini', 'mini_data')
    kadv.MSG('mini_data', 'init')
    kadv.FUNC('init', 'init_after__mini', init)
    kadv.MSG('init_after__mini', 'moveEnemy')
    kadv.FUNC('moveEnemy', 'moveEnemy_after__mini', moveEnemy)
    kadv.MSG('moveEnemy_after__mini', 'repair')
    kadv.FUNC('repair', 'repair_after__mini', repair)
    kadv.MSG('repair_after__mini', 'check')
    kadv.FUNC('check', 'check_after__mini', check)
    kadv.MSG('check_after__mini', 'mini\x97E\x91\xa2\x82Q')
    kadv.MSG('mini\x97E\x91\xa2\x82Q', 'stay1')
    kadv.FUNC('stay1', 'stay1_after__mini', stay1)
    kadv.MSG('stay1_after__mini', 'mini\x97E\x91\xa2')
    kadv.MSG('mini\x97E\x91\xa2', 'checkEnemy1')
    kadv.FUNC('checkEnemy1', 'checkEnemy1_after__mini', checkEnemy1)
    kadv.MSG('checkEnemy1_after__mini', 'openProtect1')
    kadv.FUNC('openProtect1', 'openProtect1_after__mini', openProtect1)
    kadv.MSG('openProtect1_after__mini', 'lvupJump1')
    kadv.FUNC('lvupJump1', 'lvupJump1_after__mini', lvupJump1)
    kadv.MSG('lvupJump1_after__mini', 'mini\x97E\x91\xa2\x94j\x89\xf3\x8d\xcf\x82\xdd')
    kadv.MSG('mini\x97E\x91\xa2\x94j\x89\xf3\x8d\xcf\x82\xdd', 'alreadyJump1')
    kadv.FUNC('alreadyJump1', 'alreadyJump1_after__mini', alreadyJump1)
    kadv.MSG('alreadyJump1_after__mini', 'mini\x97E\x91\xa2\x8e\xb8\x94s')
    kadv.MSG('mini\x97E\x91\xa2\x8e\xb8\x94s', 'repair1')
    kadv.FUNC('repair1', 'repair1_after__mini', repair1)
    kadv.MSG('repair1_after__mini', 'mini\x97E\x91\xa2\x8fI\x97\xb9')
    kadv.MSG('mini\x97E\x91\xa2\x8fI\x97\xb9', 'mini_overAll')
    kadv.MSG('mini\x97E\x91\xa2\x91I\x91\xf0', 'sndCheck1')
    kadv.FUNC('sndCheck1', 'sndCheck1_after__mini', sndCheck1)
    kadv.MSG('sndCheck1_after__mini', 'mini\x90^\x97E\x91\xa2\x91I\x91\xf0')
    kadv.MSG('mini\x97E\x91\xa2\x82\xcc\x82Q\x8aK\x95\xa8\x89\xb9', 'mini\x90^\x97E\x91\xa2\x91I\x91\xf0')
    kadv.MSG('mini\x97E\x91\xa2\x82\xcc\x98L\x89\xba\x95\xa8\x89\xb9', 'mini\x90^\x97E\x91\xa2\x91I\x91\xf0')
    kadv.MSG('mini\x90^\x97E\x91\xa2\x91I\x91\xf0', 'resetStay1')
    kadv.FUNC('resetStay1', 'resetStay1_after__mini', resetStay1)
    kadv.MSG('resetStay1_after__mini', '__/src/mini_src_096')
    kadv.SELECT('__/src/mini_src_096', 'mini\x98L\x89\xba', 'mini\x97E\x91\xa2\x82Q')
    kadv.MSG('mini\x8a\xcf\x8c\x8e\x82Q', 'stay2')
    kadv.FUNC('stay2', 'stay2_after__mini', stay2)
    kadv.MSG('stay2_after__mini', 'mini\x8a\xcf\x8c\x8e')
    kadv.MSG('mini\x8a\xcf\x8c\x8e', 'checkEnemy2')
    kadv.FUNC('checkEnemy2', 'checkEnemy2_after__mini', checkEnemy2)
    kadv.MSG('checkEnemy2_after__mini', 'openProtect2')
    kadv.FUNC('openProtect2', 'openProtect2_after__mini', openProtect2)
    kadv.MSG('openProtect2_after__mini', 'lvupJump2')
    kadv.FUNC('lvupJump2', 'lvupJump2_after__mini', lvupJump2)
    kadv.MSG('lvupJump2_after__mini', 'mini\x8a\xcf\x8c\x8e\x94j\x89\xf3\x8d\xcf\x82\xdd')
    kadv.MSG('mini\x8a\xcf\x8c\x8e\x94j\x89\xf3\x8d\xcf\x82\xdd', 'alreadyJump2')
    kadv.FUNC('alreadyJump2', 'alreadyJump2_after__mini', alreadyJump2)
    kadv.MSG('alreadyJump2_after__mini', 'mini\x8a\xcf\x8c\x8e\x8e\xb8\x94s')
    kadv.MSG('mini\x8a\xcf\x8c\x8e\x8e\xb8\x94s', 'repair2')
    kadv.FUNC('repair2', 'repair2_after__mini', repair2)
    kadv.MSG('repair2_after__mini', 'mini\x8a\xcf\x8c\x8e\x8fI\x97\xb9')
    kadv.MSG('mini\x8a\xcf\x8c\x8e\x8fI\x97\xb9', 'mini_overAll')
    kadv.MSG('mini\x8a\xcf\x8c\x8e\x91I\x91\xf0', 'sndCheck2')
    kadv.FUNC('sndCheck2', 'sndCheck2_after__mini', sndCheck2)
    kadv.MSG('sndCheck2_after__mini', 'mini\x90^\x8a\xcf\x8c\x8e\x91I\x91\xf0')
    kadv.MSG('mini\x8a\xcf\x8c\x8e\x82\xcc\x98L\x89\xba\x95\xa8\x89\xb9', 'mini\x90^\x8a\xcf\x8c\x8e\x91I\x91\xf0')
    kadv.MSG('mini\x90^\x8a\xcf\x8c\x8e\x91I\x91\xf0', 'resetStay2')
    kadv.FUNC('resetStay2', 'resetStay2_after__mini', resetStay2)
    kadv.MSG('resetStay2_after__mini', '__/src/mini_src_097')
    kadv.SELECT('__/src/mini_src_097', 'mini\x97[\x95P', 'mini\x98L\x89\xba', 'mini\x8a\xcf\x8c\x8e\x82Q')
    kadv.MSG('mini\x97[\x95P\x82Q', 'stay3')
    kadv.FUNC('stay3', 'stay3_after__mini', stay3)
    kadv.MSG('stay3_after__mini', 'mini\x97[\x95P')
    kadv.MSG('mini\x97[\x95P', 'checkEnemy3')
    kadv.FUNC('checkEnemy3', 'checkEnemy3_after__mini', checkEnemy3)
    kadv.MSG('checkEnemy3_after__mini', 'openProtect3')
    kadv.FUNC('openProtect3', 'openProtect3_after__mini', openProtect3)
    kadv.MSG('openProtect3_after__mini', 'lvupJump3')
    kadv.FUNC('lvupJump3', 'lvupJump3_after__mini', lvupJump3)
    kadv.MSG('lvupJump3_after__mini', 'mini\x97[\x95P\x94j\x89\xf3\x8d\xcf\x82\xdd')
    kadv.MSG('mini\x97[\x95P\x94j\x89\xf3\x8d\xcf\x82\xdd', 'alreadyJump3')
    kadv.FUNC('alreadyJump3', 'alreadyJump3_after__mini', alreadyJump3)
    kadv.MSG('alreadyJump3_after__mini', 'mini\x97[\x95P\x8e\xb8\x94s')
    kadv.MSG('mini\x97[\x95P\x8e\xb8\x94s', 'repair3')
    kadv.FUNC('repair3', 'repair3_after__mini', repair3)
    kadv.MSG('repair3_after__mini', 'mini\x97[\x95P\x8fI\x97\xb9')
    kadv.MSG('mini\x97[\x95P\x8fI\x97\xb9', 'mini_overAll')
    kadv.MSG('mini\x97[\x95P\x91I\x91\xf0', 'sndCheck3')
    kadv.FUNC('sndCheck3', 'sndCheck3_after__mini', sndCheck3)
    kadv.MSG('sndCheck3_after__mini', 'mini\x90^\x97[\x95P\x91I\x91\xf0')
    kadv.MSG('mini\x97[\x95P\x82\xcc\x98L\x89\xba\x95\xa8\x89\xb9', 'mini\x90^\x97[\x95P\x91I\x91\xf0')
    kadv.MSG('mini\x90^\x97[\x95P\x91I\x91\xf0', 'resetStay3')
    kadv.FUNC('resetStay3', 'resetStay3_after__mini', resetStay3)
    kadv.MSG('resetStay3_after__mini', '__/src/mini_src_098')
    kadv.SELECT('__/src/mini_src_098', 'mini\x8a\xcf\x8c\x8e', 'mini\x98L\x89\xba', 'mini\x97[\x95P\x82Q')
    kadv.MSG('mini\x83T\x83L\x82Q', 'stay4')
    kadv.FUNC('stay4', 'stay4_after__mini', stay4)
    kadv.MSG('stay4_after__mini', 'mini\x83T\x83L')
    kadv.MSG('mini\x83T\x83L', 'checkEnemy4')
    kadv.FUNC('checkEnemy4', 'checkEnemy4_after__mini', checkEnemy4)
    kadv.MSG('checkEnemy4_after__mini', 'openProtect4')
    kadv.FUNC('openProtect4', 'openProtect4_after__mini', openProtect4)
    kadv.MSG('openProtect4_after__mini', 'lvupJump4')
    kadv.FUNC('lvupJump4', 'lvupJump4_after__mini', lvupJump4)
    kadv.MSG('lvupJump4_after__mini', 'mini\x83T\x83L\x94j\x89\xf3\x8d\xcf\x82\xdd')
    kadv.MSG('mini\x83T\x83L\x94j\x89\xf3\x8d\xcf\x82\xdd', 'alreadyJump4')
    kadv.FUNC('alreadyJump4', 'alreadyJump4_after__mini', alreadyJump4)
    kadv.MSG('alreadyJump4_after__mini', 'mini\x83T\x83L\x8e\xb8\x94s')
    kadv.MSG('mini\x83T\x83L\x8e\xb8\x94s', 'repair4')
    kadv.FUNC('repair4', 'repair4_after__mini', repair4)
    kadv.MSG('repair4_after__mini', 'mini\x83T\x83L\x8fI\x97\xb9')
    kadv.MSG('mini\x83T\x83L\x8fI\x97\xb9', 'mini_overAll')
    kadv.MSG('mini\x83T\x83L\x91I\x91\xf0', 'mini\x90^\x83T\x83L\x91I\x91\xf0')
    kadv.MSG('mini\x90^\x83T\x83L\x91I\x91\xf0', 'resetStay4')
    kadv.FUNC('resetStay4', 'resetStay4_after__mini', resetStay4)
    kadv.MSG('resetStay4_after__mini', '__/src/mini_src_099')
    kadv.SELECT('__/src/mini_src_099', 'mini\x98L\x89\xba', 'mini\x83T\x83L\x82Q')
    kadv.MSG('mini\x8b\x8f\x8a\xd4\x82Q', 'stay5')
    kadv.FUNC('stay5', 'stay5_after__mini', stay5)
    kadv.MSG('stay5_after__mini', 'mini\x8b\x8f\x8a\xd4')
    kadv.MSG('mini\x8b\x8f\x8a\xd4', 'checkEnemy5')
    kadv.FUNC('checkEnemy5', 'checkEnemy5_after__mini', checkEnemy5)
    kadv.MSG('checkEnemy5_after__mini', 'openProtect5')
    kadv.FUNC('openProtect5', 'openProtect5_after__mini', openProtect5)
    kadv.MSG('openProtect5_after__mini', 'lvupJump5')
    kadv.FUNC('lvupJump5', 'lvupJump5_after__mini', lvupJump5)
    kadv.MSG('lvupJump5_after__mini', 'mini\x8b\x8f\x8a\xd4\x94j\x89\xf3\x8d\xcf\x82\xdd')
    kadv.MSG('mini\x8b\x8f\x8a\xd4\x94j\x89\xf3\x8d\xcf\x82\xdd', 'alreadyJump5')
    kadv.FUNC('alreadyJump5', 'alreadyJump5_after__mini', alreadyJump5)
    kadv.MSG('alreadyJump5_after__mini', 'mini\x8b\x8f\x8a\xd4\x8e\xb8\x94s')
    kadv.MSG('mini\x8b\x8f\x8a\xd4\x8e\xb8\x94s', 'repair5')
    kadv.FUNC('repair5', 'repair5_after__mini', repair5)
    kadv.MSG('repair5_after__mini', 'mini\x8b\x8f\x8a\xd4\x8fI\x97\xb9')
    kadv.MSG('mini\x8b\x8f\x8a\xd4\x8fI\x97\xb9', 'mini_overAll')
    kadv.MSG('mini\x8b\x8f\x8a\xd4\x91I\x91\xf0', 'sndCheck5')
    kadv.FUNC('sndCheck5', 'sndCheck5_after__mini', sndCheck5)
    kadv.MSG('sndCheck5_after__mini', 'mini\x90^\x8b\x8f\x8a\xd4\x91I\x91\xf0')
    kadv.MSG('mini\x8b\x8f\x8a\xd4\x82\xcc\x82Q\x8aK\x95\xa8\x89\xb9', 'mini\x90^\x8b\x8f\x8a\xd4\x91I\x91\xf0')
    kadv.MSG('mini\x8b\x8f\x8a\xd4\x82\xc5\x98L\x89\xba\x95\xa8\x89\xb9', 'mini\x90^\x8b\x8f\x8a\xd4\x91I\x91\xf0')
    kadv.MSG('mini\x8b\x8f\x8a\xd4\x82\xc5\x91\xe4\x8f\x8a\x95\xa8\x89\xb9', 'mini\x90^\x8b\x8f\x8a\xd4\x91I\x91\xf0')
    kadv.MSG('mini\x90^\x8b\x8f\x8a\xd4\x91I\x91\xf0', 'resetStay5')
    kadv.FUNC('resetStay5', 'resetStay5_after__mini', resetStay5)
    kadv.MSG('resetStay5_after__mini', '__/src/mini_src_100')
    kadv.SELECT('__/src/mini_src_100', 'mini\x91\xe4\x8f\x8a', 'mini\x98L\x89\xba', 'mini\x8b\x8f\x8a\xd4\x82Q')
    kadv.MSG('mini\x98L\x89\xba\x82Q', 'stay6')
    kadv.FUNC('stay6', 'stay6_after__mini', stay6)
    kadv.MSG('stay6_after__mini', 'mini\x98L\x89\xba')
    kadv.MSG('mini\x98L\x89\xba', 'checkEnemy6')
    kadv.FUNC('checkEnemy6', 'checkEnemy6_after__mini', checkEnemy6)
    kadv.MSG('checkEnemy6_after__mini', 'openProtect6')
    kadv.FUNC('openProtect6', 'openProtect6_after__mini', openProtect6)
    kadv.MSG('openProtect6_after__mini', 'lvupJump6')
    kadv.FUNC('lvupJump6', 'lvupJump6_after__mini', lvupJump6)
    kadv.MSG('lvupJump6_after__mini', 'mini\x98L\x89\xba\x94j\x89\xf3\x8d\xcf\x82\xdd')
    kadv.MSG('mini\x98L\x89\xba\x94j\x89\xf3\x8d\xcf\x82\xdd', 'alreadyJump6')
    kadv.FUNC('alreadyJump6', 'alreadyJump6_after__mini', alreadyJump6)
    kadv.MSG('alreadyJump6_after__mini', 'mini\x98L\x89\xba\x8e\xb8\x94s')
    kadv.MSG('mini\x98L\x89\xba\x8e\xb8\x94s', 'repair6')
    kadv.FUNC('repair6', 'repair6_after__mini', repair6)
    kadv.MSG('repair6_after__mini', 'mini\x98L\x89\xba\x8fI\x97\xb9')
    kadv.MSG('mini\x98L\x89\xba\x8fI\x97\xb9', 'mini_overAll')
    kadv.MSG('mini\x98L\x89\xba\x91I\x91\xf0', 'sndCheck6')
    kadv.FUNC('sndCheck6', 'sndCheck6_after__mini', sndCheck6)
    kadv.MSG('sndCheck6_after__mini', 'mini\x90^\x98L\x89\xba\x91I\x91\xf0')
    kadv.MSG('mini\x98L\x89\xba\x82\xc5\x97E\x91\xa2\x95\xa8\x89\xb9', 'mini\x90^\x98L\x89\xba\x91I\x91\xf0')
    kadv.MSG('mini\x98L\x89\xba\x82\xc5\x8a\xcf\x8c\x8e\x95\xa8\x89\xb9', 'mini\x90^\x98L\x89\xba\x91I\x91\xf0')
    kadv.MSG('mini\x98L\x89\xba\x82\xc5\x97[\x95P\x95\xa8\x89\xb9', 'mini\x90^\x98L\x89\xba\x91I\x91\xf0')
    kadv.MSG('mini\x98L\x89\xba\x82\xc5\x8b\x8f\x8a\xd4\x95\xa8\x89\xb9', 'mini\x90^\x98L\x89\xba\x91I\x91\xf0')
    kadv.MSG('mini\x90^\x98L\x89\xba\x91I\x91\xf0', 'resetStay6')
    kadv.FUNC('resetStay6', 'resetStay6_after__mini', resetStay6)
    kadv.MSG('resetStay6_after__mini', 'mini\x8aK\x91I\x91\xf0')
    kadv.MSG('mini\x8aK\x91I\x91\xf0', '__/src/mini_src_101')
    kadv.SELECT('__/src/mini_src_101', 'mini\x82P\x8aK', 'mini\x82Q\x8aK', 'mini\x98L\x89\xba\x82Q')
    kadv.MSG('mini\x82P\x8aK', '__/src/mini_src_102')
    kadv.SELECT('__/src/mini_src_102', 'mini\x8b\x8f\x8a\xd4', 'mini\x97E\x91\xa2', 'mini\x83T\x83L', 'mini\x8aK\x91I\x91\xf0')
    kadv.MSG('mini\x82Q\x8aK', '__/src/mini_src_103')
    kadv.SELECT('__/src/mini_src_103', 'mini\x8a\xcf\x8c\x8e', 'mini\x97[\x95P', 'mini\x8aK\x91I\x91\xf0')
    kadv.MSG('mini\x91\xe4\x8f\x8a\x82Q', 'stay7')
    kadv.FUNC('stay7', 'stay7_after__mini', stay7)
    kadv.MSG('stay7_after__mini', 'mini\x91\xe4\x8f\x8a')
    kadv.MSG('mini\x91\xe4\x8f\x8a', 'checkEnemy7')
    kadv.FUNC('checkEnemy7', 'checkEnemy7_after__mini', checkEnemy7)
    kadv.MSG('checkEnemy7_after__mini', 'openProtect7')
    kadv.FUNC('openProtect7', 'openProtect7_after__mini', openProtect7)
    kadv.MSG('openProtect7_after__mini', 'lvupJump7')
    kadv.FUNC('lvupJump7', 'lvupJump7_after__mini', lvupJump7)
    kadv.MSG('lvupJump7_after__mini', 'mini\x91\xe4\x8f\x8a\x94j\x89\xf3\x8d\xcf\x82\xdd')
    kadv.MSG('mini\x91\xe4\x8f\x8a\x94j\x89\xf3\x8d\xcf\x82\xdd', 'alreadyJump7')
    kadv.FUNC('alreadyJump7', 'alreadyJump7_after__mini', alreadyJump7)
    kadv.MSG('alreadyJump7_after__mini', 'mini\x91\xe4\x8f\x8a\x8e\xb8\x94s')
    kadv.MSG('mini\x91\xe4\x8f\x8a\x8e\xb8\x94s', 'repair7')
    kadv.FUNC('repair7', 'repair7_after__mini', repair7)
    kadv.MSG('repair7_after__mini', 'mini\x91\xe4\x8f\x8a\x8fI\x97\xb9')
    kadv.MSG('mini\x91\xe4\x8f\x8a\x8fI\x97\xb9', 'mini_overAll')
    kadv.MSG('mini\x91\xe4\x8f\x8a\x91I\x91\xf0', 'sndCheck7')
    kadv.FUNC('sndCheck7', 'sndCheck7_after__mini', sndCheck7)
    kadv.MSG('sndCheck7_after__mini', 'mini\x90^\x91\xe4\x8f\x8a\x91I\x91\xf0')
    kadv.MSG('mini\x91\xe4\x8f\x8a\x82\xcc\x82Q\x8aK\x95\xa8\x89\xb9', 'mini\x90^\x91\xe4\x8f\x8a\x91I\x91\xf0')
    kadv.MSG('mini\x91\xe4\x8f\x8a\x82\xc5\x8b\x8f\x8a\xd4\x95\xa8\x89\xb9', 'mini\x90^\x91\xe4\x8f\x8a\x91I\x91\xf0')
    kadv.MSG('mini\x90^\x91\xe4\x8f\x8a\x91I\x91\xf0', 'resetStay7')
    kadv.FUNC('resetStay7', 'resetStay7_after__mini', resetStay7)
    kadv.MSG('resetStay7_after__mini', '__/src/mini_src_104')
    kadv.SELECT('__/src/mini_src_104', 'mini\x8b\x8f\x8a\xd4', 'mini\x91\xe4\x8f\x8a\x82Q')
    kadv.MSG('mini_clear', 'setClear')
    kadv.FUNC('setClear', 'setClear_after__mini', setClear)
    kadv.MSG('setClear_after__mini', '_10_3_00__0')
    if kadv.MODULE('_10_3_00__0', '_10_3_00'):
        return 
    kadv.MSG('_10_3_00_after__1', 'mini_overAll')
    kadv.MSG('mini_overAll', '10_2_05_TIMEOVER')
    kadv.MSG('10_2_05_TIMEOVER', '_10_3_00__1')
    if kadv.MODULE('_10_3_00__1', '_10_3_00'):
        return 
    kadv.MSG('_10_3_00_after__2', None)



# local variables:
# tab-width: 4
