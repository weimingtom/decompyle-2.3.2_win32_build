# emacs-mode: -*- python-*-
KADV.debugOut(('%s: %dms' % (__file__,
 KADV.getTime())))
import kadv

def dayInit():
    kadv.setParam('day', None)
    kadv.setParam('chapter', '\x83v\x83\x8d\x83\x8d\x81[\x83O')



def wait0():
    import util
    util.timeWait(3000)



def wait2():
    import util
    util.timeWait(500)



def wait3():
    import util
    util.timeWait(2000)



def wait4():
    import util
    util.timeWait(2000)



def run():
    kadv.FUNC(None, 'dayInit')
    kadv.FUNC('dayInit', 'dayInit_after__prologue', dayInit)
    kadv.MSG('dayInit_after__prologue', 'prologue')
    kadv.MSG('prologue', 'wait0')
    kadv.FUNC('wait0', 'wait0_after__prologue', wait0)
    kadv.MSG('wait0_after__prologue', 'wait2')
    kadv.FUNC('wait2', 'wait2_after__prologue', wait2)
    kadv.MSG('wait2_after__prologue', 'wait3')
    kadv.FUNC('wait3', 'wait3_after__prologue', wait3)
    kadv.MSG('wait3_after__prologue', 'wait4')
    kadv.FUNC('wait4', 'wait4_after__prologue', wait4)
    kadv.MSG('wait4_after__prologue', '_01_0_00__0')
    if kadv.MODULE('_01_0_00__0', '_01_0_00'):
        return 
    kadv.MSG('_01_0_00_after__1', None)



# local variables:
# tab-width: 4
