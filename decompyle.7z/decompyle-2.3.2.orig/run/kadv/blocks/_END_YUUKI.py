# emacs-mode: -*- python-*-
KADV.debugOut(('%s: %dms' % (__file__,
 KADV.getTime())))
import kadv

def _END_YUUKI_dayInit():
    kadv.setParam('day', None)
    kadv.setParam('chapter', '\x81`\x97[\x95P\x81`')



def branch1():
    if (kadv.getParam('\x8dg\x94b\x92f\x94O\x83t\x83\x89\x83O') == 0):
        return 'END_YUUKI_F1_1'



def bgmFade1():
    import util
    util.bgmFade(2000)



def bgmFade2():
    import util
    util.bgmFade(4000)



def endroll1():
    import endroll
    endroll.start('\x97[\x95P')



def run():
    kadv.FUNC(None, '_END_YUUKI_dayInit')
    kadv.FUNC('_END_YUUKI_dayInit', '_END_YUUKI_dayInit_after___END_YUUKI', _END_YUUKI_dayInit)
    kadv.MSG('_END_YUUKI_dayInit_after___END_YUUKI', 'END_YUUKI')
    kadv.MSG('END_YUUKI', 'branch1')
    kadv.FUNC('branch1', 'branch1_after___END_YUUKI', branch1)
    kadv.MSG('branch1_after___END_YUUKI', 'END_YUUKI_F1_E')
    kadv.MSG('END_YUUKI_F1_1', 'END_YUUKI_F1_E')
    kadv.MSG('END_YUUKI_F1_E', 'bgmFade1')
    kadv.FUNC('bgmFade1', 'bgmFade1_after___END_YUUKI', bgmFade1)
    kadv.MSG('bgmFade1_after___END_YUUKI', 'bgmFade2')
    kadv.FUNC('bgmFade2', 'bgmFade2_after___END_YUUKI', bgmFade2)
    kadv.MSG('bgmFade2_after___END_YUUKI', 'endroll1')
    kadv.FUNC('endroll1', 'endroll1_after___END_YUUKI', endroll1)
    kadv.MSG('endroll1_after___END_YUUKI', None)



# local variables:
# tab-width: 4
