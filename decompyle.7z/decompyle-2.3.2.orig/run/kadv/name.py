# emacs-mode: -*- python-*-
KADV.debugOut(('begin:%s' % __file__))
import string
CSV_NAME = 0
CSV_COLOR = 1
ELEMENT_NO = 0
ELEMENT_COLOR = 1
f = open('kadv/data/name.txt')
names = {}
count = 0
for str in f.readlines():
    str = string.split(str, '#')[0]
    str = string.strip(str)
    if (len(str) == 0):
        continue
    str = string.split(str, ',')
    col = string.atol(string.strip(str[CSV_COLOR]), 16)
    if (col > 2147483647):
        col = (4294967296L - col)
        col = int(col)
        col = ~col
    else:
        col = int(col)
    names[string.strip(str[CSV_NAME])] = (count,
     col)
    count += 1

f.close()

def getNameColor(id):
    if names.has_key(id):
        return names[id][ELEMENT_COLOR]
    else:
        return -1



def getNameIndex(id):
    if names.has_key(id):
        return names[id][ELEMENT_NO]
    else:
        return -1


KADV.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
