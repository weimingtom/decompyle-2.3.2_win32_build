# emacs-mode: -*- python-*-
TITLE.debugOut(('begin:%s' % __file__))
import os
import stat
import time
MAKER_FOLDER = 'Patisserie'
SAVE_FOLDER = 'matsuyoigusa'
ONE_PAGE_FILES = 10
PAGE_NUM = 5
loadedNo = -1
viewPage = 0
dataInfo = ([None] * (ONE_PAGE_FILES * PAGE_NUM))

def loadScene():
    import scene
    KADV.__exp__['scene_id'] = None
    if KADV.__exp__.has_key('day'):
        dayBack = KADV.__exp__['day']
    else:
        dayBack = None
    KADV.__exp__['day'] = dataInfo[loadedNo][4]
    scene.load(dataInfo[loadedNo][2], 1)
    KADV.__exp__['scene_id'] = dataInfo[loadedNo][2]
    KADV.__exp__['day'] = dayBack



def getDataPath(m):
    maker_path = ('%s/%s' % (m.getAppdataPath(),
     MAKER_FOLDER))
    app_path = ('%s/%s' % (maker_path,
     SAVE_FOLDER))
    if (not os.path.exists(maker_path)):
        os.mkdir(maker_path)
    if (not os.path.exists(app_path)):
        os.mkdir(app_path)
    return app_path



def updatePage(m):
    for i in range((viewPage * ONE_PAGE_FILES), ((viewPage + 1) * ONE_PAGE_FILES)):
        fname = ('%s/%d.dat' % (getDataPath(m),
         (i + 1)))
        if os.path.exists(fname):
            tm = time.localtime(os.stat(fname)[stat.ST_MTIME])
            tmstr = time.strftime('%Y/%m/%d %H:%M:%S', tm)
            import marshal
            f = open(('%s/%d.dat' % (getDataPath(m),
             (i + 1))), 'rb')
            tmp = marshal.load(f)
            f.close()
            sid = 0
            if tmp.has_key('scene_id'):
                sid = tmp['scene_id']
            if tmp.has_key('day'):
                day = tmp['day']
            else:
                day = None
            if tmp.has_key('chapter'):
                dataInfo[i] = (tmstr,
                 tmp['chapter'],
                 sid,
                 fname,
                 day)
            else:
                dataInfo[i] = (tmstr,
                 '\x8c\xc3\x82\xa2\x83f\x81[\x83^',
                 sid,
                 fname,
                 day)
        else:
            dataInfo[i] = None




def updateDataInfo(m):
    global viewPage
    global loadedNo
    loadedNo = -1
    maxTm = 0
    for i in range(0, len(dataInfo)):
        fname = ('%s/%d.dat' % (getDataPath(m),
         (i + 1)))
        if os.path.exists(fname):
            tm = time.localtime(os.stat(fname)[stat.ST_MTIME])
            if (tm > maxTm):
                maxTm = tm
                loadedNo = i

    viewPage = (loadedNo // ONE_PAGE_FILES)
    if (viewPage < 0):
        viewPage = 0
    updatePage(m)
    if (loadedNo >= 0):
        loadScene()



def drawDataInfo(m, no):
    i = (no % ONE_PAGE_FILES)
    import loadAni
    xy = loadAni.getDataBounds(i)
    txy = loadAni.getTimeBounds()
    ixy = loadAni.getInfoBounds()
    m.textOut((((xy[0] + 400) + txy[0]),
     ((xy[1] + 300) + txy[1])), txy[3], -1, ('%02d.' % (no + 1)))
    if (dataInfo[no] != None):
        m.textOut(((((28 + xy[0]) + 400) + txy[0]),
         ((xy[1] + 300) + txy[1])), txy[3], -1, dataInfo[no][0])
        m.textOut(((((28 + xy[0]) + 400) + ixy[0]),
         ((xy[1] + 300) + ixy[1])), ixy[3], -1, dataInfo[no][1])
    else:
        m.textOut(((((28 + xy[0]) + 400) + txy[0]),
         ((xy[1] + 300) + txy[1])), txy[3], -1, '----/--/-- --:--:--')



def drawDataInfos(m, page):
    for i in range(0, ONE_PAGE_FILES):
        drawDataInfo(m, ((page * ONE_PAGE_FILES) + i))

    import loadAni
    xyh = loadAni.getPageBounds()
    m.textOut(((xyh[0] + 400),
     (xyh[1] + 300)), xyh[3], -1, ('%d/%d' % ((page + 1),
     PAGE_NUM)))



def loadInit(m, BGName):
    import vram
    BGTone = 192
    if (BGName == None):
        m.drawImg(vram.IMG_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        m.drawTile((BGTone << 24), (-400,
         -300,
         800,
         600))
        m.moveImg(vram.TMP_PAGE, (0,
         0,
         800,
         600), 0, (0,
         0))
    elif (BGName == 0):
        m.clear(vram.TMP_PAGE, -16777216, (0,
         0,
         800,
         600))
    else:
        m.loadImg(vram.TMP_PAGE, (0,
         0), BGName)
    startTime = m.getTime()
    while 1:
        passTime = (m.getTime() - startTime)
        if (passTime >= 300):
            m.drawImg(vram.TMP_PAGE, 255, (-400,
             -300,
             800,
             600), (0,
             0))
            m.swap()
            break
        else:
            alpha = (255 - ((255 * passTime) / 300))
            if (BGName == None):
                m.drawImg(vram.TMP_PAGE, 255, (-400,
                 -300,
                 800,
                 600), (0,
                 0))
                m.drawImg(vram.IMG_PAGE, alpha, (-400,
                 -300,
                 800,
                 600), (0,
                 0))
            else:
                m.drawImg(vram.TMP_PAGE, 255, (-400,
                 -300,
                 800,
                 600), (0,
                 0))
                m.drawTile((alpha << 24), (-400,
                 -300,
                 800,
                 600))
            m.swap()

    updateDataInfo(m)



def getDataNo(mod, page):
    global loadedNo
    loadedBack = loadedNo
    ret = -1
    import loadAni
    import key
    import scene
    m = key.getPos(mod)
    for i in range(ONE_PAGE_FILES):
        no = ((page * ONE_PAGE_FILES) + i)
        if (dataInfo[no] == None):
            continue
        r = loadAni.getDataBounds(i)
        if (r[0] < m[0] < (r[0] + r[2]) and r[1] < m[1] < (r[1] + r[3])):
            if key.isTrg(mod):
                if KADV.isPressMouse(KADV.INPUT):
                    loadedNo = no
            ret = no

    k = key.get(mod)
    if k[key.K_1][1]:
        loadedNo = ((page * ONE_PAGE_FILES) + 0)
    elif k[key.K_2][1]:
        loadedNo = ((page * ONE_PAGE_FILES) + 1)
    elif k[key.K_3][1]:
        loadedNo = ((page * ONE_PAGE_FILES) + 2)
    elif k[key.K_4][1]:
        loadedNo = ((page * ONE_PAGE_FILES) + 3)
    elif k[key.K_5][1]:
        loadedNo = ((page * ONE_PAGE_FILES) + 4)
    elif k[key.K_6][1]:
        loadedNo = ((page * ONE_PAGE_FILES) + 5)
    elif k[key.K_7][1]:
        loadedNo = ((page * ONE_PAGE_FILES) + 6)
    elif k[key.K_8][1]:
        loadedNo = ((page * ONE_PAGE_FILES) + 7)
    elif k[key.K_9][1]:
        loadedNo = ((page * ONE_PAGE_FILES) + 8)
    elif k[key.K_0][1]:
        loadedNo = ((page * ONE_PAGE_FILES) + 9)
    if (loadedNo != loadedBack):
        if (dataInfo[loadedNo] == None):
            loadedNo = loadedBack
        else:
            scene.playSE('\x8c\x88\x92\xe8')
            loadScene()
    return ret



def baseDraw(mod):
    import vram
    import loadAni
    mod.drawImg(vram.TMP_PAGE, 255, (-400,
     -300,
     800,
     600), (0,
     0))
    loadAni.loadBaseDraw()
    if (loadedNo >= 0):
        loadAni.minwinDraw()
        loadAni.dlgBaseDraw()
    drawDataInfos(mod, viewPage)



def checkYes(mod):
    import loadAni
    import key
    import scene
    m = key.getPos(mod)
    r = loadAni.getYesBounds()
    if (r[0] < m[0] < (r[0] + r[2]) and r[1] < m[1] < (r[1] + r[3])):
        loadAni.dlgYesSelDraw()
        if key.isTrg(mod):
            scene.playSE('\x91I\x91\xf0\x83J\x81[\x83\\\x83\x8b')
            loadAni.loadDlgYesWait(mod, baseDraw)
            return 1
    if key.isTrg(mod):
        if (not mod.isPressMouse(mod.INPUT)):
            if (loadedNo >= 0):
                scene.playSE('\x91I\x91\xf0\x83J\x81[\x83\\\x83\x8b')
                loadAni.loadDlgYesWait(mod, baseDraw)
                return 1
    return 0



def checkPageButton(mod):
    global viewPage
    import loadAni
    import key
    import scene
    m = key.getPos(mod)
    r = loadAni.getBackBounds()
    if (r[0] < m[0] < (r[0] + r[2]) and r[1] < m[1] < (r[1] + r[3])):
        loadAni.loadPageBackSelDraw()
        if key.isTrg(mod):
            scene.playSE('\x8c\x88\x92\xe8')
            loadAni.loadPageBackWait(mod, baseDraw)
            viewPage = (((viewPage + PAGE_NUM) - 1) % PAGE_NUM)
            updatePage(mod)
    else:
        r = loadAni.getNextBounds()
        if (r[0] < m[0] < (r[0] + r[2]) and r[1] < m[1] < (r[1] + r[3])):
            loadAni.loadPageNextSelDraw()
            if key.isTrg(mod):
                scene.playSE('\x8c\x88\x92\xe8')
                loadAni.loadPageNextWait(mod, baseDraw)
                viewPage = ((viewPage + 1) % PAGE_NUM)
                updatePage(mod)
    input = key.get(KADV)
    if input[key.K_PUP][2]:
        scene.playSE('\x8c\x88\x92\xe8')
        loadAni.loadPageBackWait(mod, baseDraw)
        viewPage = (((viewPage + PAGE_NUM) - 1) % PAGE_NUM)
        updatePage(mod)
    if input[key.K_PDOWN][2]:
        scene.playSE('\x8c\x88\x92\xe8')
        loadAni.loadPageNextWait(mod, baseDraw)
        viewPage = ((viewPage + 1) % PAGE_NUM)
        updatePage(mod)



def checkReturnButton(mod):
    import loadAni
    import key
    import scene
    m = key.getPos(mod)
    r = loadAni.getReturnBounds()
    if (r[0] < m[0] < (r[0] + r[2]) and r[1] < m[1] < (r[1] + r[3])):
        loadAni.loadReturnSelDraw()
        if key.isTrg(mod):
            scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
            loadAni.loadReturnWait(mod, baseDraw)
            return 1
    return 0



def start(m, BGName):
    import vram
    import key
    import loadAni
    import scene
    import loadAni
    loadAni.init()
    loadInit(m, BGName)
    m.updateInput(m.INPUT)
    while 1:
        dataNo = getDataNo(m, viewPage)
        m.drawImg(vram.TMP_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        loadAni.loadBaseDraw()
        checkPageButton(m)
        if checkReturnButton(m):
            break
        doLoad = 0
        if (loadedNo >= 0):
            if (viewPage == (loadedNo / ONE_PAGE_FILES)):
                loadAni.loadDataSeledDraw((loadedNo % ONE_PAGE_FILES))
            loadAni.minwinDraw()
            loadAni.dlgBaseDraw()
            doLoad = checkYes(m)
        if (dataNo >= 0):
            loadAni.loadDataSelDraw((dataNo % ONE_PAGE_FILES))
        drawDataInfos(m, viewPage)
        if KADV.__exp__['debug']:
            KADV.drawTile(0x80000000, (-400,
             -300,
             200,
             16))
            KADV.textOut((0,
             0), 16, -1, ('PATH: %s' % getDataPath(m)))
        m.swap()
        m.updateInput(m.INPUT)
        if doLoad:
            startTime = m.getTime()
            maxTime = 250
            while 1:
                passTime = (m.getTime() - startTime)
                if (passTime > maxTime):
                    break
                alpha = (float(passTime) / maxTime)
                m.clear(0, 0, (0,
                 0,
                 800,
                 600))
                loadAni.minwinDraw(alpha)
                m.swap()

            loadAni.minwinDraw(1)
            m.swap()
            import marshal
            f = open(dataInfo[loadedNo][3], 'rb')
            KADV.__exp__.clear()
            KADV.__exp__.update(marshal.load(f))
            f.close()
            import msg
            import scene
            id = KADV.__exp__['scene_id']
            scene.playBGM(scene.getElements(id)[scene.BGM_ELEMENT])
            if KADV.__exp__.has_key('ani_id'):
                if ((KADV.__exp__['ani_id'] != None) or (KADV.__exp__['ani_id'] == '0')):
                    KADV.setAniop(KADV.ANIOP_0, KADV.ANI_1, KADV.__exp__['ani_id'])
            return 1
        if key.isCansel(m):
            scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
            loadAni.loadReturnWait(m, baseDraw)
            break

    import effect
    effect.fadeOutWait(TITLE)
    return 0


TITLE.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
