# emacs-mode: -*- python-*-
TITLE.debugOut(('begin:%s' % __file__))
LOAD_BASE_NO = (10,
 TITLE.ANIOP_31)
LOAD_DATA_SEL_NO = (11,
 TITLE.ANIOP_30)
LOAD_DATA_SELED_NO = (12,
 TITLE.ANIOP_29)
LOAD_PAGE_BACK_SEL_NO = (13,
 TITLE.ANIOP_28)
LOAD_PAGE_NEXT_SEL_NO = (14,
 TITLE.ANIOP_27)
LOAD_PAGE_BACK_NO = (15,
 TITLE.ANIOP_26)
LOAD_PAGE_NEXT_NO = (16,
 TITLE.ANIOP_25)
LOAD_DLG_BASE_NO = (17,
 TITLE.ANIOP_24)
LOAD_DLG_SEL_NO = (18,
 TITLE.ANIOP_23)
LOAD_DLG_YES_NO = (19,
 TITLE.ANIOP_22)
LOAD_RETURN_SEL_NO = (20,
 TITLE.ANIOP_21)
LOAD_RETURN_NO = (21,
 TITLE.ANIOP_20)
SAVE_BASE_NO = (50,
 TITLE.ANIOP_19)
SAVE_DLG_BASE_NO = (51,
 TITLE.ANIOP_18)
SAVE_DLG_SEL_NO = (52,
 TITLE.ANIOP_17)
SAVE_DLG_YES_NO = (53,
 TITLE.ANIOP_16)
SAVE_BEFOR_NO = (54,
 TITLE.ANIOP_15)
SAVE_AFTER_NO = (55,
 TITLE.ANIOP_14)
BOUNDS_WIN_NO = (30,
 0)
BOUNDS_TIME_NO = (30,
 1)
BOUNDS_INFO_NO = (30,
 2)
BOUNDS_PAGE_NO = (30,
 3)
BOUNDS_BACK_NO = (31,
 0)
BOUNDS_NEXT_NO = (31,
 1)
BOUNDS_YES_NO = (31,
 2)
BOUNDS_RETURN_NO = (31,
 3)
BOUNDS_DATA_NO = (32,
 0)

def init():
    TITLE.loadAni(TITLE.ANI_0, 'load/slpts.abb')
    nos = [LOAD_BASE_NO,
     LOAD_DATA_SEL_NO,
     LOAD_DATA_SELED_NO,
     LOAD_PAGE_BACK_SEL_NO,
     LOAD_PAGE_NEXT_SEL_NO,
     LOAD_PAGE_BACK_NO,
     LOAD_PAGE_NEXT_NO,
     LOAD_DLG_BASE_NO,
     LOAD_DLG_SEL_NO,
     LOAD_DLG_YES_NO,
     LOAD_RETURN_SEL_NO,
     LOAD_RETURN_NO,
     SAVE_BASE_NO,
     SAVE_DLG_BASE_NO,
     SAVE_DLG_SEL_NO,
     SAVE_DLG_YES_NO,
     SAVE_BEFOR_NO,
     SAVE_AFTER_NO]
    for i in nos:
        TITLE.setAniop(i[1], TITLE.ANI_0, i[0])




def getTimeBounds():
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_TIME_NO[0], BOUNDS_TIME_NO[1])
    return pos



def getInfoBounds():
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_INFO_NO[0], BOUNDS_INFO_NO[1])
    return pos



def getBackBounds():
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_BACK_NO[0], BOUNDS_BACK_NO[1])
    return pos



def getNextBounds():
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_NEXT_NO[0], BOUNDS_NEXT_NO[1])
    return pos



def getPageBounds():
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_PAGE_NO[0], BOUNDS_PAGE_NO[1])
    return pos



def getDataBounds(no):
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_DATA_NO[0], no)
    return pos



def getYesBounds():
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_YES_NO[0], BOUNDS_YES_NO[1])
    return pos



def getReturnBounds():
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_RETURN_NO[0], BOUNDS_RETURN_NO[1])
    return pos



def loadBaseDraw():
    TITLE.drawAniop(LOAD_BASE_NO[1])
    return TITLE.isLoopAniop(LOAD_BASE_NO[1])



def loadDataSelDraw(no):
    pos = getDataBounds(no)
    TITLE.drawAniop(LOAD_DATA_SEL_NO[1], (pos[0],
     pos[1]))



def loadDataSeledDraw(no):
    pos = getDataBounds(no)
    TITLE.drawAniop(LOAD_DATA_SELED_NO[1], (pos[0],
     pos[1]))



def loadPageBackSelDraw():
    TITLE.drawAniop(LOAD_PAGE_BACK_SEL_NO[1])



def loadPageNextSelDraw():
    TITLE.drawAniop(LOAD_PAGE_NEXT_SEL_NO[1])



def loadReturnSelDraw():
    TITLE.drawAniop(LOAD_RETURN_SEL_NO[1])



def waitDraw(m, drawFunc, a):
    m.setAniop(a[1], TITLE.ANI_0, a[0])
    while 1:
        drawFunc(m)
        m.drawAniop(a[1])
        m.swap()
        if m.isFinishAniop(a[1]):
            break




def loadPageBackWait(m, drawFunc):
    waitDraw(m, drawFunc, LOAD_PAGE_BACK_NO)



def loadPageNextWait(m, drawFunc):
    waitDraw(m, drawFunc, LOAD_PAGE_NEXT_NO)



def loadReturnWait(m, drawFunc):
    waitDraw(m, drawFunc, LOAD_RETURN_NO)



def loadDlgYesWait(m, drawFunc):
    waitDraw(m, drawFunc, LOAD_DLG_YES_NO)



def minwinDraw(alpha = 0):
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_WIN_NO[0], BOUNDS_WIN_NO[1])
    sw = (800 - pos[2])
    aw = (float(pos[2]) / (800 - (sw * alpha)))
    sx = (-400 - pos[0])
    ax = (pos[0] + (sx * alpha))
    sh = (600 - pos[3])
    ah = (float(pos[3]) / (600 - (sh * alpha)))
    sy = (-300 - pos[1])
    ay = (pos[1] + (sy * alpha))
    import vram
    if (alpha >= 1):
        TITLE.drawImg(vram.IMG_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
    else:
        TITLE.drawImg(vram.IMG_PAGE, 255, (int(ax),
         int(ay),
         800,
         600), (0,
         0), (aw,
         ah))



def dlgBaseDraw():
    TITLE.drawAniop(LOAD_DLG_BASE_NO[1])



def dlgYesSelDraw():
    TITLE.drawAniop(LOAD_DLG_SEL_NO[1])



def saveBaseDraw():
    TITLE.drawAniop(SAVE_BASE_NO[1])
    return TITLE.isLoopAniop(SAVE_BASE_NO[1])



def saveDlgBaseDraw():
    TITLE.drawAniop(SAVE_DLG_BASE_NO[1])



def saveDlgYesSelDraw():
    TITLE.drawAniop(SAVE_DLG_SEL_NO[1])



def saveDlgYesWait(m, drawFunc):
    waitDraw(m, drawFunc, SAVE_DLG_YES_NO)



def saveBeforWait(m, drawFunc):
    waitDraw(m, drawFunc, SAVE_BEFOR_NO)



def saveAfterWait(m, drawFunc):
    waitDraw(m, drawFunc, SAVE_AFTER_NO)


TITLE.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
