# emacs-mode: -*- python-*-
REPLAY.debugOut(('begin:%s' % __file__))
import flow
import kadv

def mainLoop():
    import moduleList
    try:
        try:
            moduleList.modules[KADV.__exp__['module']].run()
        except 'kadvBreakException', val:
            KADV.__exp__['result'] = val
    except Exception, e:
        KADV.debugOut(('except:%s' % e))



def start():
    import log
    log.clear()
    KADV.__exp__['msg_id'] = None
    KADV.__exp__['msg_page'] = 0
    KADV.__exp__['scene_id'] = None
    KADV.__exp__['is_replay'] = 1
    import keyWait
    import sysmenu
    keyWait.readSkipOnFlag = 0
    keyWait.autoNextOnFlag = 0
    import ani
    ani.init()
    mainLoop()
    import effect
    effect.fadeOutWait(REPLAY)


REPLAY.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
