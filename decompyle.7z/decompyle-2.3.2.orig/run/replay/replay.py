# emacs-mode: -*- python-*-
REPLAY.debugOut(('begin:%s' % __file__))
import string
f = open('replay/replay.lst')
lines = f.readlines()
f.close()
ELEMENT_MODULE = 0
ELEMENT_TITLE = 1
ELEMENT_THUMB = 2
replayInfo = []
for line in lines:
    t = string.split(line, ',')
    if (len(t) == 3):
        t = map(string.strip, t)
        t = (t[0],
         t[1],
         string.atoi(t[2]))
        replayInfo.append(t)


def isVisibleReplay(num):
    import cfgvalue
    return cfgvalue.getReplayViewFlag(num)



def getThumbNum(page):
    import replayAni
    import scene
    thumbNum = replayAni.getThumbNum()
    totalNum = len(replayInfo)
    if (((page + 1) * thumbNum) > totalNum):
        return (totalNum % thumbNum)
    else:
        return thumbNum



def baseDraw(page):
    import replayAni
    import vram
    import scene
    thumbNum = replayAni.getThumbNum()
    totalNum = len(replayInfo)
    REPLAY.drawImg(vram.IMG_PAGE, 255, (-400,
     -300,
     800,
     600), (0,
     0))
    replayAni.cgBaseDraw()
    pos = replayAni.getPageBounds()
    REPLAY.textOut(((pos[0] + 400),
     (pos[1] + 300)), pos[3], -1, ('%d/%d' % ((page + 1),
     (((totalNum + thumbNum) - 1) / thumbNum))))
    base = (thumbNum * page)
    drawNum = getThumbNum(page)
    for i in range(drawNum):
        if (not isVisibleReplay((base + i))):
            replayAni.thumbBaseDraw(i)

    for i in range((i + 1), thumbNum):
        replayAni.thumbNoneDraw(i)




def onCheck(page):
    import replayAni
    import key
    thumbNum = getThumbNum(page)
    (mx, my, mz,) = key.getPos(REPLAY)
    base = (page * replayAni.getThumbNum())
    for i in range(thumbNum):
        if isVisibleReplay((base + i)):
            pos = replayAni.getThumbBounds(i)
            if (pos[0] < mx < (pos[0] + pos[2]) and pos[1] < my < (pos[1] + pos[3])):
                replayAni.cgThumbOnDraw(i)
                (x, y, w, h,) = replayAni.getText1Bounds()
                REPLAY.textOut(((x + 400),
                 (y + 300)), h, -1, ('%s' % replayInfo[(base + i)][ELEMENT_TITLE]))
                return (i + 1)

    pos = replayAni.getReturnBounds()
    if (pos[0] < mx < (pos[0] + pos[2]) and pos[1] < my < (pos[1] + pos[3])):
        replayAni.cgReturnOnDraw()
        return 100
    pos = replayAni.getNextBounds()
    if (pos[0] < mx < (pos[0] + pos[2]) and pos[1] < my < (pos[1] + pos[3])):
        replayAni.cgNextOnDraw()
        return 101
    pos = replayAni.getBackBounds()
    if (pos[0] < mx < (pos[0] + pos[2]) and pos[1] < my < (pos[1] + pos[3])):
        replayAni.cgBackOnDraw()
        return 102
    return 0



def loadPageThumb(page):
    import replayAni
    import vram
    base = (replayAni.getThumbNum() * page)
    for i in range(getThumbNum(page)):
        if isVisibleReplay((base + i)):
            pos = replayAni.getThumbPos(i)
            REPLAY.loadImg(vram.IMG_PAGE, ((pos[0] + 400),
             (pos[1] + 300)), 'cgview/s_event.bin', replayInfo[(base + i)][ELEMENT_THUMB])
            baseDraw(page)
            REPLAY.swap()

    i += 1
    if (i < (replayAni.getThumbNum() - 1)):
        for i in range(i, replayAni.getThumbNum()):
            pos = replayAni.getThumbBounds(i)
            REPLAY.clear(vram.IMG_PAGE, 0, ((pos[0] + 400),
             (pos[1] + 300),
             pos[2],
             pos[3]))

    REPLAY.swap()
    REPLAY.updateInput(REPLAY.INPUT)



def inEffect():
    import replayAni
    import vram
    REPLAY.loadImg(vram.IMG_PAGE, (0,
     0), 'replay/review.png')
    startTime = REPLAY.getTime()
    while (REPLAY.getTime() < (startTime + 500)):
        alpha = ((255 * (REPLAY.getTime() - startTime)) / 500)
        REPLAY.clear(0, 0, (0,
         0,
         800,
         600))
        REPLAY.drawImg(vram.IMG_PAGE, alpha, (-400,
         -300,
         800,
         600), (0,
         0))
        REPLAY.swap()

    while 1:
        REPLAY.drawImg(vram.IMG_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        if replayAni.cgBaseDraw():
            break
        REPLAY.swap()
        REPLAY.updateInput(REPLAY.INPUT)




def playEffect(page):
    import replayAni
    import vram
    startTime = REPLAY.getTime()
    while (REPLAY.getTime() < (startTime + 500)):
        alpha = ((255 * (REPLAY.getTime() - startTime)) / 500)
        REPLAY.drawImg(vram.IMG_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        baseDraw(page)
        REPLAY.drawTile((alpha << 24), (-400,
         -300,
         800,
         600))
        REPLAY.swap()




def start():
    import replayAni
    import vram
    import key
    import scene
    replayAni.init()
    scene.playBGM('18\x81E\x90\xc3\x82\xa9\x82\xc8\x96\xe9(introduce)')
    totalNum = len(replayInfo)
    thumbNum = replayAni.getThumbNum()
    pageMax = (((totalNum + thumbNum) - 1) / thumbNum)
    inEffect()
    page = 0
    loadPageThumb(page)
    while 1:
        baseDraw(page)
        isOn = onCheck(page)
        REPLAY.swap()
        REPLAY.updateInput(REPLAY.INPUT)
        if (isOn and key.isTrg(REPLAY)):
            if (isOn == 100):
                scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
                replayAni.cgReturnWait(baseDraw, page)
                break
            elif (isOn == 101):
                scene.playSE('\x8c\x88\x92\xe8')
                replayAni.cgNextWait(baseDraw, page)
                page = ((page + 1) % pageMax)
                loadPageThumb(page)
            elif (isOn == 102):
                scene.playSE('\x8c\x88\x92\xe8')
                replayAni.cgBackWait(baseDraw, page)
                page = (((page + pageMax) - 1) % pageMax)
                loadPageThumb(page)
            else:
                scene.playSE('\x91I\x91\xf0\x83J\x81[\x83\\\x83\x8b')
                replayAni.cgThumbWait(baseDraw, page, (isOn - 1))
                playEffect(page)
                KADV.stopBGM(KADV.SOUND)
                KADV.__exp__['module'] = replayInfo[(((page * thumbNum) + isOn) - 1)][ELEMENT_MODULE]
                import play
                play.start()
                replayAni.init()
                import scene
                scene.playBGM('18\x81E\x90\xc3\x82\xa9\x82\xc8\x96\xe9(introduce)')
                inEffect()
                loadPageThumb(page)
        if key.isCansel(REPLAY):
            scene.playSE('\x83L\x83\x83\x83\x93\x83Z\x83\x8b')
            replayAni.cgReturnWait(baseDraw, page)
            break
        input = key.get(KADV)
        if input[key.K_PUP][2]:
            scene.playSE('\x8c\x88\x92\xe8')
            replayAni.cgBackWait(baseDraw, page)
            page = (((page + pageMax) - 1) % pageMax)
            loadPageThumb(page)
        if input[key.K_PDOWN][2]:
            scene.playSE('\x8c\x88\x92\xe8')
            replayAni.cgNextWait(baseDraw, page)
            page = ((page + 1) % pageMax)
            loadPageThumb(page)
        for i in range(len(key.DIK)):
            if (i >= getThumbNum(page)):
                break
            if REPLAY.isPressKey(REPLAY.INPUT, key.DIK[i]):
                scene.playSE('\x91I\x91\xf0\x83J\x81[\x83\\\x83\x8b')
                replayAni.cgThumbWait(baseDraw, page, (isOn - 1))
                playEffect(page)
                KADV.__exp__['module'] = replayInfo[(isOn - 1)][ELEMENT_MODULE]
                import play
                play.start()
                replayAni.init()
                inEffect()
                break


    import effect
    effect.fadeOutWait(REPLAY)
    REPLAY.__exp__['result'] = 'title'
    KADV.stopBGM(KADV.SOUND)


REPLAY.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
