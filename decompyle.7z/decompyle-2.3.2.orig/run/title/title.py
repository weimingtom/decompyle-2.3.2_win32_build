# emacs-mode: -*- python-*-
TITLE.debugOut(('begin:%s' % __file__))
START_MODULE = 'prologue'
import sys
sys.path.append('load')
sys.path.append('replay')
sys.path.append('cgview')
sys.path.append('mplay')
sys.path.append('config')
sys.path.append('endroll')
skipMovie = 0

def op_logo():
    import key
    import ozipRead
    TITLE.loadAni(TITLE.ANI_0, 'title/mrogo.abb')
    TITLE.setAniop(TITLE.ANIOP_0, TITLE.ANI_0, 0)
    f = ozipRead.ozipRead('title/mrogo.vic')
    max = f.getArciveNum()
    f.close()
    r = (TITLE.getTime() % max)
    TITLE.playVoice(TITLE.SOUND, 'title/mrogo.vic', r)
    while 1:
        TITLE.drawAniop(TITLE.ANIOP_0)
        TITLE.swap()
        TITLE.updateInput(TITLE.INPUT)
        if TITLE.isFinishAniop(TITLE.ANIOP_0):
            break
        if key.isCansel(TITLE):
            break




def drawMenu():
    import key
    import titleAni
    import vram
    import scene
    selectNo = 0
    while 1:
        TITLE.drawImg(vram.IMG_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        isLoop = titleAni.menuBaseDraw()
        TITLE.swap()
        TITLE.updateInput(TITLE.INPUT)
        if isLoop:
            while 1:
                TITLE.drawImg(vram.IMG_PAGE, 255, (-400,
                 -300,
                 800,
                 600), (0,
                 0))
                titleAni.menuBaseDraw()
                selectNo = 0
                m = key.getPos(TITLE)
                p = titleAni.getMenuStartBounds()
                if (p[0] < m[0] < (p[0] + p[2]) and p[1] < m[1] < (p[1] + p[3])):
                    titleAni.menuStartDraw()
                    selectNo = 1
                p = titleAni.getMenuLoadBounds()
                if (p[0] < m[0] < (p[0] + p[2]) and p[1] < m[1] < (p[1] + p[3])):
                    titleAni.menuLoadDraw()
                    selectNo = 2
                p = titleAni.getMenuReplayBounds()
                if (p[0] < m[0] < (p[0] + p[2]) and p[1] < m[1] < (p[1] + p[3])):
                    titleAni.menuReplayDraw()
                    selectNo = 3
                p = titleAni.getMenuCGBounds()
                if (p[0] < m[0] < (p[0] + p[2]) and p[1] < m[1] < (p[1] + p[3])):
                    titleAni.menuCGDraw()
                    selectNo = 4
                p = titleAni.getMenuSoundBounds()
                if (p[0] < m[0] < (p[0] + p[2]) and p[1] < m[1] < (p[1] + p[3])):
                    titleAni.menuSoundDraw()
                    selectNo = 5
                p = titleAni.getMenuCFGBounds()
                if (p[0] < m[0] < (p[0] + p[2]) and p[1] < m[1] < (p[1] + p[3])):
                    titleAni.menuCFGDraw()
                    selectNo = 6
                p = titleAni.getMenuExitBounds()
                if (p[0] < m[0] < (p[0] + p[2]) and p[1] < m[1] < (p[1] + p[3])):
                    titleAni.menuExitDraw()
                    selectNo = 7
                TITLE.swap()
                TITLE.updateInput(TITLE.INPUT)
                if ((selectNo != 0) and key.isTrg(TITLE)):
                    break
                if key.isCansel(TITLE):
                    selectNo = 0
                    titleAni.init()
                    break
                k = key.get(TITLE)
                if k[key.K_1][1]:
                    selectNo = 1
                    break
                if k[key.K_2][1]:
                    selectNo = 2
                    break
                if k[key.K_3][1]:
                    selectNo = 4
                    break
                if k[key.K_4][1]:
                    selectNo = 3
                    break
                if k[key.K_5][1]:
                    selectNo = 5
                    break
                if k[key.K_6][1]:
                    selectNo = 6
                    break
                if k[key.K_7][1]:
                    selectNo = 7
                    break

            break

    if (selectNo != 0):
        scene.playSE('\x83X\x83^\x81[\x83g\x81i\x83^\x83C\x83g\x83\x8b\x89\xe6\x96\xca\x82\xc5\x82\xcc\x8c\x88\x92\xe8\x81j')
    return selectNo



def fadeTitle():
    import titleAni
    import vram
    startTime = TITLE.getTime()
    while 1:
        TITLE.drawImg(vram.IMG_PAGE, 255, (-400,
         -300,
         800,
         600), (0,
         0))
        titleAni.menuBaseDraw()
        passTime = (TITLE.getTime() - startTime)
        if (passTime >= 300):
            break
        else:
            alpha = ((255 * passTime) / 300)
            alpha <<= 24
            TITLE.drawTile(alpha, (-400,
             -300,
             800,
             600))
            TITLE.swap()

    TITLE.drawTile(-16777216, (-400,
     -300,
     800,
     600))
    TITLE.swap()



def drawTitle():
    import key
    import titleAni
    import vram
    import scene
    startTime = TITLE.getTime()
    titleAni.init()
    selectNo = 0
    while 1:
        scene.playBGM('01\x81E\x96\xb2\x8c\xa9\x90l\x8c`\x81QB')
        TITLE.clear(0, 0, (0,
         0,
         800,
         600))
        passTime = (TITLE.getTime() - startTime)
        if (passTime > 500):
            alpha = 255
        else:
            alpha = ((255 * passTime) / 500)
        TITLE.drawImg(vram.IMG_PAGE, alpha, (-400,
         -300,
         800,
         600), (0,
         0))
        if (TITLE.getTime() > (startTime + 500)):
            titleAni.menuKeywaitDraw()
        TITLE.swap()
        TITLE.updateInput(TITLE.INPUT)
        if TITLE.isPressAnyKey(TITLE.INPUT):
            import scene
            scene.playBGM('01\x81E\x96\xb2\x8c\xa9\x90l\x8c`\x81QB')
            selectNo = drawMenu()
            if (selectNo == 0):
                startTime = (TITLE.getTime() - 500)
            else:
                fadeTitle()
                if (selectNo == 2):
                    import ani
                    ani.init()
                    import load
                    isBreak = load.start(TITLE, 'load/loadbg.png')
                    if isBreak:
                        break
                elif (selectNo == 3):
                    break
                elif (selectNo == 4):
                    import cgview
                    cgview.start()
                elif (selectNo == 5):
                    import mplay
                    mplay.start()
                elif (selectNo == 6):
                    import config
                    config.start(TITLE, 'config/coview.png')
                else:
                    break
                TITLE.loadImg(vram.IMG_PAGE, (0,
                 0), 'title/title.png')
                titleAni.init()
                startTime = TITLE.getTime()

    return selectNo



def imports():
    import titleAni
    import title
    import replayAni
    import replay
    import play
    import ozipRead
    import mplayAni
    import mplay
    import save
    import loadAni
    import load
    import xchange
    import vram
    import util
    import tileEffect
    import textAnim
    import text
    import sysmenu
    import selectmsg
    import scene
    import pixelEffect
    import name
    import msg
    import log
    import keyWait
    import kadv
    import flow
    import effect
    import dreamEffect
    import cfgvalue
    import _END_YUUKI
    import _END_SAKI
    import _END_MITSUKI
    import _END_KUREHA
    import _END_HATSUMI
    import prologue
    import moduleList
    import mini
    import ani
    import endroll
    import config
    import cfgAni
    import cgviewAni
    import cgview
    import avi



def start():
    global skipMovie
    imports()
    import os
    import cfgvalue
    import load
    if os.path.exists(('%s/0.dat' % load.getDataPath(TITLE))):
        f = open(('%s/0.dat' % load.getDataPath(TITLE)), 'rb')
        d = f.read()
        KADV.setFlagData(KADV.FLAG, d)
        f.close()
    else:
        KADV.debugOut('tset')
        cfgvalue.init()
    cfgvalue.reflectionAll()
    if (skipMovie == 0):
        op_logo()
    skipMovie = 1
    import vram
    import titleAni
    TITLE.loadImg(vram.IMG_PAGE, (0,
     0), 'title/title.png')
    titleAni.init()
    debug = KADV.__exp__['debug']
    KADV.__exp__.clear()
    KADV.__exp__['debug'] = debug
    import log
    log.clear()
    KADV.__exp__['module'] = START_MODULE
    KADV.__exp__['msg_id'] = None
    KADV.__exp__['msg_page'] = 0
    KADV.__exp__['is_replay'] = 0
    selectNo = drawTitle()
    if (selectNo == 7):
        TITLE.__exp__['result'] = 'end'
    elif (selectNo == 2):
        TITLE.__exp__['result'] = 'kadv'
    elif (selectNo == 3):
        TITLE.__exp__['result'] = 'replay'
    else:
        TITLE.__exp__['result'] = 'kadv'
        KADV.__exp__['scene_id'] = None
    import keyWait
    keyWait.buttonFlagInit()


TITLE.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
