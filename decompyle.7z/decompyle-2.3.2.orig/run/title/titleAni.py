# emacs-mode: -*- python-*-
TITLE.debugOut(('begin:%s' % __file__))
MENU_BASE_NO = (10,
 TITLE.ANIOP_31)
MENU_START_NO = (11,
 TITLE.ANIOP_30)
MENU_LOAD_NO = (12,
 TITLE.ANIOP_29)
MENU_REPLAY_NO = (14,
 TITLE.ANIOP_28)
MENU_CG_NO = (13,
 TITLE.ANIOP_27)
MENU_SOUND_NO = (15,
 TITLE.ANIOP_26)
MENU_EXIT_NO = (17,
 TITLE.ANIOP_25)
MENU_CFG_NO = (16,
 TITLE.ANIOP_23)
MENU_KEYWAIT_NO = (30,
 TITLE.ANIOP_24)
BOUNDS_MENU_START_NO = (20,
 0)
BOUNDS_MENU_LOAD_NO = (20,
 1)
BOUNDS_MENU_REPLAY_NO = (20,
 3)
BOUNDS_MENU_CG_NO = (20,
 2)
BOUNDS_MENU_SOUND_NO = (20,
 4)
BOUNDS_MENU_CFG_NO = (20,
 5)
BOUNDS_MENU_EXIT_NO = (20,
 6)

def init():
    TITLE.loadAni(TITLE.ANI_0, 'title/tipts.abb')
    TITLE.setAniop(MENU_BASE_NO[1], TITLE.ANI_0, MENU_BASE_NO[0])
    TITLE.setAniop(MENU_START_NO[1], TITLE.ANI_0, MENU_START_NO[0])
    TITLE.setAniop(MENU_LOAD_NO[1], TITLE.ANI_0, MENU_LOAD_NO[0])
    TITLE.setAniop(MENU_REPLAY_NO[1], TITLE.ANI_0, MENU_REPLAY_NO[0])
    TITLE.setAniop(MENU_CG_NO[1], TITLE.ANI_0, MENU_CG_NO[0])
    TITLE.setAniop(MENU_SOUND_NO[1], TITLE.ANI_0, MENU_SOUND_NO[0])
    TITLE.setAniop(MENU_CFG_NO[1], TITLE.ANI_0, MENU_CFG_NO[0])
    TITLE.setAniop(MENU_EXIT_NO[1], TITLE.ANI_0, MENU_EXIT_NO[0])
    TITLE.setAniop(MENU_KEYWAIT_NO[1], TITLE.ANI_0, MENU_KEYWAIT_NO[0])



def getMenuStartBounds():
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_MENU_START_NO[0], BOUNDS_MENU_START_NO[1])
    return pos



def getMenuLoadBounds():
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_MENU_LOAD_NO[0], BOUNDS_MENU_LOAD_NO[1])
    return pos



def getMenuReplayBounds():
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_MENU_REPLAY_NO[0], BOUNDS_MENU_REPLAY_NO[1])
    return pos



def getMenuCGBounds():
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_MENU_CG_NO[0], BOUNDS_MENU_CG_NO[1])
    return pos



def getMenuSoundBounds():
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_MENU_SOUND_NO[0], BOUNDS_MENU_SOUND_NO[1])
    return pos



def getMenuCFGBounds():
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_MENU_CFG_NO[0], BOUNDS_MENU_CFG_NO[1])
    return pos



def getMenuExitBounds():
    pos = TITLE.getAniBounds(TITLE.ANI_0, BOUNDS_MENU_EXIT_NO[0], BOUNDS_MENU_EXIT_NO[1])
    return pos



def menuBaseDraw():
    TITLE.drawAniop(MENU_BASE_NO[1])
    return TITLE.isLoopAniop(MENU_BASE_NO[1])



def menuStartDraw():
    TITLE.drawAniop(MENU_START_NO[1])



def menuLoadDraw():
    TITLE.drawAniop(MENU_LOAD_NO[1])



def menuReplayDraw():
    TITLE.drawAniop(MENU_REPLAY_NO[1])



def menuCGDraw():
    TITLE.drawAniop(MENU_CG_NO[1])



def menuSoundDraw():
    TITLE.drawAniop(MENU_SOUND_NO[1])



def menuCFGDraw():
    TITLE.drawAniop(MENU_CFG_NO[1])



def menuExitDraw():
    TITLE.drawAniop(MENU_EXIT_NO[1])



def menuKeywaitDraw():
    TITLE.drawAniop(MENU_KEYWAIT_NO[1])


TITLE.debugOut(('end:%s' % __file__))

# local variables:
# tab-width: 4
